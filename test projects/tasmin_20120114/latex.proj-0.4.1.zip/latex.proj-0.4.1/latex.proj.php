<?php

//
// A "Standard Document" wrapper.  I could ALMOST make this work
// according to its OWN name, were it not that the document title might
// be longer and different...
//

include("common.php");

display_doc("Latex Project","latex.proj");

?>
