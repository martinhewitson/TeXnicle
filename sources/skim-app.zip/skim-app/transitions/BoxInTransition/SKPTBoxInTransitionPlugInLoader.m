//
//  SKPTBoxInTransitionPlugInLoader.m
//  BoxInTransition
//
//  Created by Christiaan on 10/6/09.
//  Copyright Christiaan Hofman 2009. All rights reserved.
//

#import "SKPTBoxInTransitionPlugInLoader.h"

@implementation SKPTBoxInTransitionPlugInLoader

-(BOOL)load:(void*)host
{
    // custom plug-in initialization code goes here
    return YES;
}

@end
