//
//  SKPTSplitOutTransitionPlugInLoader.m
//  SplitOutTransition
//
//  Created by Christiaan on 10/6/09.
//  Copyright Christiaan Hofman 2009. All rights reserved.
//

#import "SKPTSplitOutTransitionPlugInLoader.h"

@implementation SKPTSplitOutTransitionPlugInLoader

-(BOOL)load:(void*)host
{
    // custom plug-in initialization code goes here
    return YES;
}

@end
