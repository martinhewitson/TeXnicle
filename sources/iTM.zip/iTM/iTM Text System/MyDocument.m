// MyDocument.m

#import "MyDocument.h"
#import "iTMTextView.h"
#import "iTMTextStorage.h"
#import "iTMTeXSyntaxParser.h"

@implementation MyDocument

+ (void) initialize;
{
    [super initialize];
    [[NSUserDefaults standardUserDefaults] registerDefaults:
        [NSDictionary dictionaryWithObjectsAndKeys:
            [NSNumber numberWithBool: YES], iTMUDSmartInsertDeleteEnabledKey, nil]];
    return;
}
- (NSString *)windowNibName
{
    // Override returning the nib file name of the document
    // If you need to use a subclass of NSWindowController or if your document supports multiple NSWindowControllers, you should remove this method and override -makeWindowControllers instead.
    return @"MyDocument";
}

- (void)windowControllerDidLoadNib:(NSWindowController *) aController
{
    [super windowControllerDidLoadNib:aController];
    // Add any code here that need to be executed once the windowController has loaded the document's window.
    [textView setDelegate: self];
    if(!textStorage)
        textStorage = [[iTMTextStorage allocWithZone: [self zone]] init];
    [textStorage replaceSyntaxParser: [iTMTeXSyntaxParser syntaxParser]];
    [[textView layoutManager] replaceTextStorage: textStorage];
    {
        NSRange R = NSMakeRange(0, [textStorage length]);
        [textStorage invalidateAttributesInRange: R];
//            [[textView layoutManager] invalidateLayoutForCharacterRange: R isSoft: NO actualCharacterRange: nil];
    }
}

- (NSData *)dataRepresentationOfType:(NSString *)aType
{
    NSData * result = [[textView textStorage] encodedStringDataAllowLossyConversion: NO];
    if(!result)
    {
        if(NSAlertAlternateReturn == NSRunCriticalAlertPanel(
            NSLocalizedStringFromTableInBundle(@"Saving.", @"TeX",
                                                [NSBundle bundleForClass: [self class]], "Informational Panel Title"),
            NSLocalizedStringFromTableInBundle(@"Information may be lost while saving with encoding %@.", @"TeX",
                                                [NSBundle bundleForClass: [self class]], "unsaved"),
            NSLocalizedStringFromTableInBundle(@"Abort", @"TeX", [NSBundle bundleForClass: [self class]], "Abort"),
            NSLocalizedStringFromTableInBundle(@"Force", @"TeX", [NSBundle bundleForClass: [self class]], "Force"),
            nil,
            [NSString localizedNameOfStringEncoding: [textStorage dataStringEncoding]]))
        {
            result = [[textView textStorage] encodedStringDataAllowLossyConversion: YES];
        }
    }
    return result;
}

- (BOOL)loadDataRepresentation:(NSData *)docData ofType:(NSString *)aType
{
    // Insert code here to read your document from the given data.  You can also choose to override -loadFileWrapperRepresentation:ofType: or -readFromFile:ofType: instead.
    textStorage = [[iTMTextStorage allocWithZone: [self zone]]
                                initWithEncodedStringData: docData];
    return YES;
}

@end
