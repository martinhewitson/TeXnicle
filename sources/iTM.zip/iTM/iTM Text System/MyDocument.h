// MyDocument.h

#import <Cocoa/Cocoa.h>

@interface MyDocument : NSDocument
{
    id textView;
    id textStorage;
}
@end
