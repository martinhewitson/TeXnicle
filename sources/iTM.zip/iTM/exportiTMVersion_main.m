#import <Foundation/Foundation.h>
#include <stdlib.h>
int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    NSString * version = [[[NSBundle bundleWithPath: [[[[NSProcessInfo processInfo] environment] objectForKey: @"BUILT_PRODUCTS_DIR"] stringByAppendingPathComponent: @"iTeXMac.app"]] infoDictionary] objectForKey: @"CFBundleVersion"];
    printf([version UTF8String]);
    [pool release];
    return 0;
}
