/*
//  iTMXToolbarDelegate.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Jan 14 2002.
//  Copyright © 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMXToolbarDelegate.h"
#import "iTMProjectToolbarDelegate.h"
#import "iTMHelpManager.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMPDFWindowController
/*"Description forthcoming."*/
@implementation iTMPDFWindowController(iTMXToolbarDelegate)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  PDFToolbarDelegateClass
- (Class) PDFToolbarDelegateClass;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [iTMXPDFToolbarDelegate class];
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMXPDFToolbarDelegate
/*"Description forthcoming."*/
@implementation iTMXPDFToolbarDelegate
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toolbar:itemForItemIdentifier:willBeInsertedIntoToolbar:
- (NSToolbarItem *) toolbar: (NSToolbar *) aToolbar itemForItemIdentifier: (NSString *) anItemIdentifier willBeInsertedIntoToolbar: (BOOL) aFlag;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSToolbarItem * result = [[iTMProjectToolbarDelegate sharedInstance]
        toolbar: aToolbar itemForItemIdentifier: anItemIdentifier willBeInsertedIntoToolbar: aFlag];
    return result? result:
            [super toolbar: aToolbar itemForItemIdentifier: anItemIdentifier willBeInsertedIntoToolbar: aFlag];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toolbarDefaultItemIdentifiers:
- (NSArray *) toolbarDefaultItemIdentifiers: (NSToolbar*) aToolbar;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [NSArray arrayWithObjects:
                NSToolbarPrintItemIdentifier,
                NSToolbarSeparatorItemIdentifier,
                iTMToolbarTerminalItemIdentifier,
                iTMToolbarErrorsItemIdentifier,
                iTMToolbarFilesItemIdentifier,
                iTMToolbarProjectWindowItemIdentifier,
                iTMToolbarSourceItemIdentifier,
                NSToolbarSeparatorItemIdentifier,
                NSToolbarFlexibleSpaceItemIdentifier,
                iTMToolbarNavigationSetItemIdentifier,
                NSToolbarFlexibleSpaceItemIdentifier,
                iTMToolbarMagnificationSetItemIdentifier,
                NSToolbarFlexibleSpaceItemIdentifier,
                iTMToolbarHistorySetItemIdentifier,
                NSToolbarFlexibleSpaceItemIdentifier,
                NSToolbarSeparatorItemIdentifier,
                iTMToolbarShowHelpItemIdentifier,
                    nil];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toolbarAllowedItemIdentifiers:
- (NSArray *) toolbarAllowedItemIdentifiers: (NSToolbar*) aToolbar;
/*" Apple comment of the NSToolbar header: Required method.  Returns the list of all allowed items by identifier.  By default, the toolbar does not assume any items are allowed, even the separator.  So, every allowed item must be explicitly listed.  The set of allowed items is used to construct the customization palette.  The order of items does not necessarily guarantee the order of appearance in the palette.  At minimum, you should return the default item list. End of comment.*/
{
    return [NSArray arrayWithObjects:
                NSToolbarPrintItemIdentifier,
                NSToolbarFlexibleSpaceItemIdentifier,
                NSToolbarSpaceItemIdentifier,
                NSToolbarSeparatorItemIdentifier,
                iTMToolbarTerminalItemIdentifier,
                iTMToolbarErrorsItemIdentifier,
//                iTMToolbarFilesItemIdentifier,
                iTMToolbarProjectItemIdentifier,
//                iTMToolbarProjectWindowItemIdentifier,
                iTMToolbarSourceItemIdentifier,
                iTMToolbarShowHelpItemIdentifier,
                iTMToolbarPreviousSetItemIdentifier,
                iTMToolbarNextSetItemIdentifier,
                iTMToolbarPreviousMixedSetItemIdentifier,
                iTMToolbarNextMixedSetItemIdentifier,
                iTMToolbarMagnificationFieldItemIdentifier,
                iTMToolbarMagnificationSetItemIdentifier,
                iTMToolbarNavigationFieldItemIdentifier,
                iTMToolbarNavigationSetItemIdentifier,
                iTMToolbarBackButtonItemIdentifier,
                iTMToolbarForwardButtonItemIdentifier,
                iTMToolbarFirstButtonItemIdentifier,
                iTMToolbarLastButtonItemIdentifier,
                iTMToolbarPreviousButtonItemIdentifier,
                iTMToolbarNextButtonItemIdentifier,
                iTMToolbarPreviousPreviousButtonItemIdentifier,
                iTMToolbarNextNextButtonItemIdentifier,
                    nil];
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMTeXWindowController
/*"Description forthcoming."*/
@implementation iTMTeXWindowController(iTMXToolbarDelegate)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  PDFToolbarDelegateClass
- (Class) TeXToolbarDelegateClass;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [iTMXTeXToolbarDelegate class];
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMXTeXToolbarDelegate
/*"Description forthcoming."*/
@implementation iTMXTeXToolbarDelegate
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toolbar:itemForItemIdentifier:willBeInsertedIntoToolbar:
- (NSToolbarItem *) toolbar: (NSToolbar *) aToolbar itemForItemIdentifier: (NSString *) anItemIdentifier willBeInsertedIntoToolbar: (BOOL) aFlag;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSToolbarItem * result = [[iTMProjectToolbarDelegate sharedInstance]
        toolbar: aToolbar itemForItemIdentifier: anItemIdentifier willBeInsertedIntoToolbar: aFlag];
    return result? result:
            [super toolbar: aToolbar itemForItemIdentifier: anItemIdentifier willBeInsertedIntoToolbar: aFlag];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toolbarDefaultItemIdentifiers:
- (NSArray *) toolbarDefaultItemIdentifiers: (NSToolbar*) aToolbar;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [NSArray arrayWithObjects:
            NSToolbarPrintItemIdentifier,
            NSToolbarSeparatorItemIdentifier,
            iTMToolbarTerminalItemIdentifier,
            iTMToolbarErrorsItemIdentifier,
            iTMToolbarFilesItemIdentifier,
            iTMToolbarProjectWindowItemIdentifier,
            iTMToolbarOutputItemIdentifier,
            NSToolbarSeparatorItemIdentifier,
            NSToolbarFlexibleSpaceItemIdentifier,
            iTMToolbarTypesetItemIdentifier,
            iTMToolbarCompileItemIdentifier,
            iTMToolbarMakeTheBibliographyItemIdentifier,
            iTMToolbarMakeTheIndexItemIdentifier,
            NSToolbarFlexibleSpaceItemIdentifier,
            NSToolbarSeparatorItemIdentifier,
            iTMToolbarShowHelpItemIdentifier,
                    nil];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toolbarAllowedItemIdentifiers:
- (NSArray *) toolbarAllowedItemIdentifiers: (NSToolbar*) aToolbar;
/*" Apple comment of the NSToolbar header: Required method.  Returns the list of all allowed items by identifier.  By default, the toolbar does not assume any items are allowed, even the separator.  So, every allowed item must be explicitly listed.  The set of allowed items is used to construct the customization palette.  The order of items does not necessarily guarantee the order of appearance in the palette.  At minimum, you should return the default item list. End of comment.*/
{
    return [NSArray arrayWithObjects:
                NSToolbarPrintItemIdentifier,
                NSToolbarFlexibleSpaceItemIdentifier,
                NSToolbarSpaceItemIdentifier,
                NSToolbarSeparatorItemIdentifier,
                iTMToolbarTerminalItemIdentifier,
                iTMToolbarErrorsItemIdentifier,
                iTMToolbarFilesItemIdentifier,
                iTMToolbarProjectItemIdentifier,
                iTMToolbarProjectWindowItemIdentifier,
                iTMToolbarSourceItemIdentifier,
                iTMToolbarOutputItemIdentifier,
                iTMToolbarTypesetItemIdentifier,
                iTMToolbarCompileItemIdentifier,
                iTMToolbarMakeTheBibliographyItemIdentifier,
                iTMToolbarMakeTheIndexItemIdentifier,
                iTMToolbarShowHelpItemIdentifier,
                    nil];
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMXToolbarDelegate

