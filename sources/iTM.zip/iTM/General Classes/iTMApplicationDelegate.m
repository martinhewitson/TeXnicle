/*
//  iTMApplicationDelegate.m
//  iTeXMac
//
//  Created by dirk on Tue Jan 23 2001.
//  Modified by jlaurens@users.sourceforge.net on Tue Jun 26 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  original method by dirk Holmes
//  jlaurens@users.sourceforge.net (07/12/2001):
//    -applicationWillFinishLaunching: modified
//    -applicationOpenUntitledFile: added
//  To Do List: (format "- proposition(percentage actually done)")
*/

//
#import "NSObject_iTeXMac.h"
#import "NSUserDefaults_iTeXMac.h"
#import "NSControl_iTeXMac.h"
#import "NSMenu_iTeXMac.h"
#import "iTMApplicationDelegate.h"
#import "iTMDefaultsController.h"
#import "iTMTextFinder.h"
#import "iTMDocumentController.h"
#import "iTMProjectsManager.h"
#import "iTMEncodingController.h"
#import "iTMTextView.h"
#import "iTMTeXDocument.h"
#import "iTMRepDocument.h"
#import "iTMRepWindowController.h"
#import "iTMTeXWindowController.h"
#import "iTMSessionManager.h"
#import "iTMGenericProjectsManager.h"
#import "iTMTeTeXController.h"
#import "iTMStatusNotification.h"
#import "iTMTextWatcher.h"
#import "iTMPDFView.h"
#warning Test purpose only
#import "NDAppleScriptObject.h"
#import "iTMGURLKit.h"

NSString * const iTMMakeEmptyDocumentKey = @"iTMMakeEmptyDocument";
NSString * const iTMDontShowTipsKey = @"iTMDontShowTips";
NSString * const iTMCurrentVersionNumberKey = @"iTMCurrentVersionNumber";
NSString * const iTMlastLanguageKey = @"iTMLastLanguage";

/*" This class is registered as the delegate of the iTeXMac NSApplication object. We do various stuff here, e.g. registering factory defaults, etc.
"*/

@implementation iTMApplicationDelegate
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= currentVersion
+ (int) currentVersion;
/*"This is the build number.
Version History: jlaurens@users.sourceforge.net (07/12/2001)
- 1.3: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//    return 1;// 11/21/2002
//    return 2;// 11/29/2002
//    return 3;// 12/07/2002-1.2.4
//    return 4;// 01/06/2003-1.2.5
//    return 5;// 01/24/2003-1.2.6
//    return 6;// 01/24/2003-1.2.7
//    return 7;// 02/10/2003-1.2.8
//    return 8;// 02/18/2003-1.2.9
//    return 9;// 03/07/2003-1.2.10
//    return 10;// 03/21/2003-1.2.11
//    return 11;// 04/11/2003-1.2.12
//    return 12;// 05/02/2003-1.3.RC
//    return 13;// 05/16/2003-1.3.RC1
//    return 14;// 05/16/2003-1.3.RC2
    return 15;// 09/09/2003-1.3.GM
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initialize
+ (void) initialize;
/*"Registers some defaults: initialize iTMDefaultsController.
Version History: jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSUserDefaults standardUserDefaults] registerDefaults: [NSDictionary dictionaryWithObjectsAndKeys: 
                    [NSNumber numberWithBool: NO], iTMMakeEmptyDocumentKey,
                    [NSNumber numberWithBool: YES], iTMDontShowTipsKey,
                    [NSNumber numberWithInt: 0], iTMCurrentVersionNumberKey,
                    @"en", iTMlastLanguageKey,
                                nil]];
    [iTMSessionManager class];// to register defaults defaults
    [iTMEncodingController class];// to register defaults defaults
    [iTMTeXDocument class];// to register defaults defaults
    [iTMSrcSpecialURLHandle class];// initialize is needed as side effect
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= dealloc
- (void) dealloc;
/*"Registers some defaults: initialize iTMDefaultsController.
Version History: jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self setApplicationDockMenu: nil];
    [self setFirstPanel: nil];
    [self setInfoTextView: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= showPreferences:
- (void) showFindPanel: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[iTMTextFinder sharedTextFinder] showFindPanel: self];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationOpenUntitledFile:
- (BOOL) applicationOpenUntitledFile: (NSApplication *) theApplication;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
I really don't know why but this simple method could replace the previous one. Nevertheless, I prefer what I can understand...
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return ![[NSUserDefaults standardUserDefaults] boolForKey: iTMMakeEmptyDocumentKey];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationDockMenu:
- (NSMenu *) applicationDockMenu: (id) sender;
/*"Lazy initializer and message.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(!_ADM)
        [self setApplicationDockMenu: [[[iTMProjectsManager defaultManager] activeProjectsMenu] supermenu]];
    return _ADM;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setApplicationDockMenu:
- (void) setApplicationDockMenu: (NSMenu *) argument;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(![_ADM isEqual: argument])
    {
        if(argument && ![argument isKindOfClass: [NSMenu class]])
            [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSMenu argument expected: %@.",
                [self class], NSStringFromSelector(_cmd), argument];
        else
        {
            [_ADM release];
            _ADM = [argument retain];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= loadOutlets
- (void) loadOutlets;
/*"Lazy initializer.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[[[NSWindowController alloc] initWithWindowNibName: @"iTMFirstPanel" owner: self] autorelease] window];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= infoTextView
- (id) infoTextView;
/*"Lazy initializer.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(!_InfoTV)
    {
        [self loadOutlets];
    }
    return _InfoTV;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setInfoTextView:
- (void) setInfoTextView: (NSTextView *) argument;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [NSTextView class]])
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSTextView argument expected: %@.",
            [self class], NSStringFromSelector(_cmd), argument];
    else if(_InfoTV != argument)
    {
        [_InfoTV autorelease];
        _InfoTV = [argument retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= windowControllerWillLoadNib
- (void) windowControllerWillLoadNib: (NSWindowController *) aWC;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- 1.2: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [aWC setShouldCascadeWindows: NO];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= windowControllerWillLoadNib
- (void) windowControllerDidLoadNib: (NSWindowController *) aWC;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- 1.2: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [_FP setFrameAutosaveName: @"iTMFirstPanel"];
//NSLog(@"[aWC window]: %@", [aWC window]);
//NSLog(@"[[aWC window] frameAutosaveName]: %@", [[aWC window] frameAutosaveName]);
    if(!_InfoTV)
        NSLog(@"- [%@ %@] Problem with nib file: iTMFirstPanel", NSStringFromClass([self class]), NSStringFromSelector(_cmd));
    else
    {
        NSString * name = @"Release Notes";
        NSString * path = [[NSBundle mainBundle] pathForResource: name ofType: @"rtf"];
        NSAttributedString * AS = [path length]>0? [[[NSAttributedString allocWithZone: [self zone]]
            initWithPath: path documentAttributes: nil]
                autorelease]: nil;
        if(!AS)
            NSLog(@"No news at %@", name);
        NSString * S = [_InfoTV string];
        int L = [S length];
        NSRange R = NSMakeRange(0, L);
        [_InfoTV setSelectedRange: R];
        [_InfoTV insertText: ([AS length]>0? (NSString *)AS: @"No news today, my heart has gone away...")];
        [_InfoTV scrollRangeToVisible: NSMakeRange(0, 0)];
        [_InfoTV setEditable: NO];
        if([_InfoTV respondsToSelector: @selector(validateWindowContent)])
            [_InfoTV performSelector: @selector(validateWindowContent)];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toggleDontShowTips:
- (IBAction) toggleDontShowTips: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSUserDefaults standardUserDefaults] setBool: ([sender state] == NSOnState) forKey: iTMDontShowTipsKey];
    if([sender respondsToSelector: @selector(validateWindowContent)])
        [sender performSelector: @selector(validateWindowContent)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateToggleDontShowTips:
- (void) validateToggleDontShowTips: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [sender setState: ([[NSUserDefaults standardUserDefaults] boolForKey: iTMDontShowTipsKey]? NSOnState: NSOffState)];
    [sender setEnabled: NO];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= firstPanel
- (NSWindow *) firstPanel;
/*"Lazy initializer.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(!_FP)
    {
        [self loadOutlets];
    }
    return _FP;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setFirstPanel:
- (void) setFirstPanel: (NSWindow *) argument;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List: Nothing at first glance
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [NSWindow class]])
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSWindow argument expected: %@.",
            [self class], NSStringFromSelector(_cmd), argument];
    else if(_FP != argument)
    {
        [_FP autorelease];
        _FP = [argument retain];
    }
//NSLog(@"_FP = %@", _FP);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  customizeGenerics:
- (IBAction) customizeGenerics: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [iTMGenericProjectsManager customizeGenericProjects: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showPreferences:
- (IBAction) showPreferences: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[iTMDefaultsController sharedDefaultsController] showWindow: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showLaTeXHelp:
- (IBAction) showLaTeXHelp: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSWorkspace sharedWorkspace] openURL: [[[NSURL alloc] initWithString:
        [NSString stringWithFormat: @"help:openbook=%@",
            NSLocalizedStringFromTableInBundle(@"iTMLaTeXHelpBook", @"HelpBooks",
                [NSBundle bundleForClass: [self class]], "Name")]] autorelease]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showTeXCatalogueOnLine:
- (IBAction) showTeXCatalogueOnLine: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSWorkspace sharedWorkspace] openURL: [[[NSURL alloc] initWithString:
        [NSString stringWithFormat: @"help:openbook=%@",
            NSLocalizedStringFromTableInBundle(@"iTMTeXCatalogueOnLineBook", @"HelpBooks",
                [NSBundle bundleForClass: [self class]], "Name")]] autorelease]];
    return;
}
#if 0
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showHelp:
- (IBAction) showXHelp: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.2: 09/03/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSLog(@"-  Opening Help book: %@", [NSString stringWithFormat: @"help:openbook=%@",
            NSLocalizedStringFromTableInBundle(@"iTeXMac%20Help", @"HelpBooks",
                [NSBundle bundleForClass: [self class]], "Name")]);
    [[NSWorkspace sharedWorkspace] openURL: [[[NSURL alloc] initWithString:
        [NSString stringWithFormat: @"help:openbook=%@",
            NSLocalizedStringFromTableInBundle(@"iTeXMac%20Help", @"HelpBooks",
                [NSBundle bundleForClass: [self class]], "Name")]] autorelease]];
    return;
}
#endif
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showTeTeXHelp:
- (IBAction) showTeTeXHelp: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[iTMTeTeXController sharedTeTeXController] showWindow: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  editKeyBinding:
- (IBAction) editKeyBinding: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(![[NSWorkspace sharedWorkspace] launchApplication: @"iTeXMac(Key)"] &&
        (NSAlertDefaultReturn == NSRunAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Installation Problem",
                            @"General", [NSBundle bundleForClass: [self class]], "Panel Title"),
                NSLocalizedStringFromTableInBundle(@"No Key Binding Editor Available.",
                            @"General", [NSBundle bundleForClass: [self class]], "status info format, 1%@"),
                NSLocalizedStringFromTableInBundle(@"Update",
                            @"General", [NSBundle bundleForClass: [self class]], "Update"),
                NSLocalizedStringFromTableInBundle(@"Cancel",
                            @"General", [NSBundle bundleForClass: [self class]], "Cancel"), nil)))
    {
        [self checkForUpdate: self];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  checkForUpdate:
- (IBAction) checkForUpdate: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * helper = [[[[NSBundle mainBundle] sharedSupportPath] stringByAppendingPathComponent: @"iTeXMac(Updater)"] stringByAppendingPathExtension: @"app"];
    if(![[NSFileManager defaultManager] fileExistsAtPath: helper])
        NSRunAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Installation Problem",
                            @"General", [NSBundle bundleForClass: [self class]], "Panel Title"),
                NSLocalizedStringFromTableInBundle(@"No Updater Available.",
                            @"General", [NSBundle bundleForClass: [self class]], ""),
                NSLocalizedStringFromTableInBundle(@"OK",
                            @"General", [NSBundle bundleForClass: [self class]], "OK"),
                nil, nil);
    else
        [[NSWorkspace sharedWorkspace] launchApplication: helper];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  customizeEncodingMenu:
- (IBAction) customizeEncodingMenu: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * helper = [[[[NSBundle mainBundle] sharedSupportPath] stringByAppendingPathComponent: @"iTeXMac(Encodings)"] stringByAppendingPathExtension: @"app"];
    if(![[NSFileManager defaultManager] fileExistsAtPath: helper])
        NSRunAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Installation Problem",
                            @"General", [NSBundle bundleForClass: [self class]], "Panel Title"),
                NSLocalizedStringFromTableInBundle(@"No Encoding Menu Editor Available.",
                            @"General", [NSBundle bundleForClass: [self class]], ""),
                NSLocalizedStringFromTableInBundle(@"OK",
                            @"General", [NSBundle bundleForClass: [self class]], "OK"),
                nil, nil);
    else
        [[NSWorkspace sharedWorkspace] launchApplication: helper];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toggleSymbolDrawerShown:
- (IBAction) toggleSymbolDrawerShown: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateMenuItem:
- (BOOL) validateMenuItem: (id <NSMenuItem>) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (11/10/2001).
To do list:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    SEL action = [sender action];
    if(action == @selector(toggleSymbolDrawerShown:))
    {
        [sender setTitle: NSLocalizedStringFromTableInBundle(@"Open Symbols", @"TeX",
                [NSBundle bundleForClass: [self class]], "Menu Item Title (Drawer)")];
        return NO;
    }
    else
        return YES;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationWillFinishLaunching:
- (void) applicationWillFinishLaunching: (NSNotification *) aNotification;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
To Do: problem when there is no UI.
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
#if 1
    NSUserDefaults * SUD = [NSUserDefaults standardUserDefaults];
    int CVN = [SUD integerForKey: iTMCurrentVersionNumberKey];
    int CCV = [[self class] currentVersion];
    if(CVN < CCV)
    {
        [[NSUserDefaults standardUserDefaults] setInteger: CCV forKey: iTMCurrentVersionNumberKey];
        [self showReleaseNotes: self];
    }
    else
#endif
//NSLog(@"1");
    if(![[NSUserDefaults standardUserDefaults] boolForKey: iTMDontShowTipsKey])
    {
//NSLog(@"2");
        [self showReleaseNotes: self];
//NSLog(@"[self firstPanel]: %@", [self firstPanel]);
//NSLog(@"_InfoTV: %@", _InfoTV);
    }
//NSLog(@"3");
    [iTMTextWatcher class];
    #if 0
    NSLog(@"%@", [[NSScriptSuiteRegistry sharedScriptSuiteRegistry] suiteNames]);
    #endif
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showReleaseNotes:
- (IBAction) showReleaseNotes: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[self firstPanel] orderFront: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationDidFinishLaunching:
- (void) applicationDidFinishLaunching: (NSNotification *) aNotification;
/*"Updates the templates and macros menus.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
To Do: problem when there is no UI.
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [iTMTeTeXController sharedTeTeXController];// installs the tetex help menus as side effect
//    [self setFirstPanel: nil];
    [self postNotificationWithStatus: [NSString string]];
    [[NSNotificationCenter defaultCenter]
        postNotificationName: NSAppleEventManagerWillProcessFirstEventNotification
            object: nil];// see ND
    [[NSUserDefaults standardUserDefaults] setObject: [[NSSpellChecker sharedSpellChecker] language] forKey: iTMlastLanguageKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  firstPanelOK:
- (IBAction) firstPanelOK: (id) sender
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    #warning DEBUG Not HERE???
//    [[self firstPanel] saveFrameUsingName: [[self firstPanel] frameAutosaveName]];
    NSWindow * FP = [self firstPanel];
    [FP orderOut: self];
    [self setFirstPanel: nil];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationWillTerminate:
- (void) applicationWillTerminate: (NSNotification *) aNotification;
/*"Description forthcoming.
Proposed by jlaurens@users.sourceforge.net (07/12/2001)
To Do: problem when there is no UI.
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSSpellChecker sharedSpellChecker] setLanguage: [[NSUserDefaults standardUserDefaults] stringForKey: iTMlastLanguageKey]];
    return;
}
@end