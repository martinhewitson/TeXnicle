/*
//  iTMColorPanelAccessoryViewController.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Tue Oct 22 2002.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMColorPanelAccessoryViewController.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMColorPanelAccessoryViewController
/*"Description forthcoming."*/
@implementation iTMColorPanelAccessoryViewController
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  view
+ (NSView *) view;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Oct 22 2002
To Do List:
"*/
{
    iTMColorPanelAccessoryViewController * CPAVC = [[[iTMColorPanelAccessoryViewController alloc] init] autorelease];
    NSWindowController * WC = [[[NSWindowController alloc] initWithWindowNibName: @"iTMColorPanelAccessoryView" owner: CPAVC] autorelease];
    [WC window];
    return [CPAVC view];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Oct 22 2002
To Do List:
"*/
{
    [self setView: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setView
- (void) setView: (NSView *) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Oct 22 2002
To Do List:
"*/
{
    if(_View!=argument)
    {
        [_View release];
        _View = [argument retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  view
- (NSView *) view;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Oct 22 2002
To Do List:
"*/
{
    return _View;
}

@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMColorPanelAccessoryViewController
#import "iTMTextView.h"

@implementation iTMTextView(iTMChangeColor)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= changeColor:
- (void) changeColor: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.2: 06/19/2002
To Do List:
"*/
{
    NSTextField * TF = [[[NSColorPanel sharedColorPanel] accessoryView] viewWithTag: 1];
    if(TF)
    {
        NSColor * C;
        BOOL optionFlag = ([[NSApp currentEvent] modifierFlags] & NSAlternateKeyMask) > 0;
        
        switch([sender mode])
        {
            case NSGrayModeColorPanel:
                C = [[sender color] colorUsingColorSpaceName:
                        (optionFlag? NSDeviceWhiteColorSpace: NSCalibratedWhiteColorSpace)];
                [TF setStringValue: [NSString stringWithFormat: @"[gray]{%.3f}", [C whiteComponent]]];
                break;
            case NSRGBModeColorPanel:
                C = [[sender color] colorUsingColorSpaceName:
                        (optionFlag? NSDeviceRGBColorSpace: NSCalibratedRGBColorSpace)];
                [TF setStringValue: [NSString stringWithFormat: @"[rgb]{%.3f, %.3f, %.3f}",
                    [C redComponent], [C greenComponent], [C blueComponent]]];
                break;
            case NSCMYKModeColorPanel:
                C = [[sender color] colorUsingColorSpaceName: NSDeviceCMYKColorSpace];
                [TF setStringValue: [NSString stringWithFormat: @"[cmyk]{%.3f, %.3f, %.3f, %.3f}",
                    [C cyanComponent], [C magentaComponent], [C yellowComponent], [C blackComponent]]];
                break;
            case NSColorListModeColorPanel:
            case NSHSBModeColorPanel:
            case NSCustomPaletteModeColorPanel:
            case NSWheelModeColorPanel:
            default:
                [TF setStringValue: [NSString string]];
                break;
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= changeTeXColor:
- (void) changeTeXColor: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.2: 06/19/2002
To Do List:
"*/
{
    NSTextField * TF = [[[NSColorPanel sharedColorPanel] accessoryView] viewWithTag: 1];
    NSString * s = [TF stringValue];
    if([s length])
    {
        NSRange selectedRange = [self selectedRange];
        [self insertText: s];
        selectedRange.length = [s length];
        [self setSelectedRange: selectedRange];
        return;
    }
    NSBeep();
    return;
}
@end
