/*
//  iTMRenderDocument.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Thu Dec 13 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import <Cocoa/Cocoa.h>
#import "iTMTaskKit.h"

extern NSString * const iTMDVIDocumentType;
extern NSString * const iTMEPSDocumentType;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMRenderDocument

@interface iTMRenderDocument: NSDocument <iTMTaskInspector>
{
@private
    IBOutlet id outputTextView;
    IBOutlet id progressIndicator;
    IBOutlet id _TC;
    BOOL _IsVisible;
    BOOL _IsCancelling;
    BOOL _HasErrors;
}

/*! 
@method taskController
@abstract The owned task controller, if any.
@discussion See the iTMController description for details.
@result An iTMController instance.
*/
- (id) taskController;

/*! 
@method setTaskController:
@abstract The lowest level setter of the task controller.
@discussion The receiver owns its task controller, and should not be owned by this controller.
@param An iTMTaskController instance.
*/
- (void) setTaskController: (iTMTaskController *) argument;

/*! 
@method hasErrors
@abstract If the receiver has errors.
@discussion Description Forthcoming.
@result YorN.
*/
- (BOOL) hasErrors;

/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
/*"Overriden methods"*/
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMRenderDocument
