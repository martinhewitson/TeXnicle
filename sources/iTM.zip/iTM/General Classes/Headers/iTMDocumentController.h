/*
//  iTMDocumentController.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sat Sep 22 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import <Cocoa/Cocoa.h>

extern NSString * const iTMUDUsesPDFHelperKey;
extern NSString * const iTMUDUsesTeXHelperKey;
extern NSString * const iTMUDPDFHelperKey;
extern NSString * const iTMUDTeXHelperKey;
extern NSString * const iTMUDUsesXDVIKey;

@class NSView, NSPanel, NSPopUpButton, NSNotification, NSDocument, NSButton;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMDocumentController
@interface iTMDocumentController: NSDocumentController
{
@private
    IBOutlet NSView * openAccessoryView;
    IBOutlet NSPanel * newDocumentAssistantPanel;
    NSPopUpButton * _OSEP;
    NSPopUpButton * _OFTP;
    NSPopUpButton * _NFTP;
    NSButton * _ASEC;
    int _DocumentType;
    BOOL _OptionFlag;
    int _NumberOfTeXDocuments;
}
/*"Class methods"*/
/*"Setters and Getters"*/
- (NSPopUpButton *) newFileTypePopUp;
- (void) setNewFileTypePopUp: (NSPopUpButton *) OFTP;
- (NSPopUpButton *) openFileTypePopUp;
- (void) setOpenFileTypePopUp: (NSPopUpButton *) OFTP;
- (NSPopUpButton *) openStringEncodingPopUp;
- (void) setOpenStringEncodingPopUp: (NSPopUpButton *) OSEP;
- (NSPopUpButton *) autoStringEncodingCheck;
- (void) setAutoStringEncodingCheck: (NSButton *) argument;
- (id) ghostDocument;
- (BOOL) hasTeXDocuments;
/*"Main methods"*/
- (void) openFileTypeChosen: (id) sender;
- (void) openStringEncodingChosen: (id) sender;
- (void) toggleAutomaticStringEncoding: (id) sender;
- (void) newFileTypeChosen: (id) sender;
- (void) newDocumentOK: (id) sender;
- (void) newDocumentCancel: (id) sender;
- (void) shouldOpenTextFile: (NSNotification *) aNotification;
- (void) validateUserInterface;
/*"Overriden methods"*/
- (void) openDocument: (id) sender;
- (id) openDocumentWithContentsOfFile: (NSString *) fileName display: (BOOL) display useHelperIfNeeded: (BOOL) aFlag;
- (id) openUntitledDocumentOfType: (NSString *) aFileType display: (BOOL) aFlag;
- (id) openUntitledDocumentOfTypeTeXDisplay: (BOOL) aFlag;
- (void) dealloc;
- (BOOL) validateMenuItem: (id) anItem;
- (void) addDocument: (NSDocument *) document;
- (void) removeDocument: (NSDocument *) document;
- (void) closeAllDocumentsWithDelegate: (id) delegate didCloseAllSelector: (SEL) didAllCloseSelector contextInfo: (void *) contextInfo;
@end

@interface iTMDocumentController(Helpers)
- (BOOL) usesTeXHelper;
- (IBAction) choosePreferredTeXEditor: (id) sender;
- (IBAction) builtInPDFViewer: (id) sender;
- (IBAction) preferredPDFViewer: (id) sender;
- (IBAction) choosePreferredPDFViewer: (id) sender;
- (BOOL) usesPDFHelper;
@end

@interface iTMGhostDocument: NSDocument
@end

@interface NSWindowController(iTMDocumentController)
- (void) highlightAndScrollLineToVisible: (int) lineNumber;
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMDocumentController

