#import <Cocoa/Cocoa.h>


#if 0
@interface iTMXSpellChecker: NSSpellChecker
@end
@implementation iTMXSpellChecker
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  checkSpellingOfString:startingAt:language:wrap:inSpellDocumentWithTag:wordCount:
- (NSRange) checkSpellingOfString: (NSString *) stringToCheck startingAt: (int) startingOffset language: (NSString *) language wrap: (BOOL) wrapFlag inSpellDocumentWithTag: (int) tag wordCount: (int *) wordCount;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//NSLog(@"1- stringToCheck= %@, startingOffset: %i", stringToCheck, startingOffset);
    NSRange R = [super checkSpellingOfString: stringToCheck
                    startingAt: startingOffset
                        language: language
                            wrap: wrapFlag
                                inSpellDocumentWithTag: tag
                                    wordCount: wordCount];
//NSLog(@"[stringToCheck substringWithRange: %@]: %@", NSStringFromRange(R), [stringToCheck substringWithRange: R]);
    return R;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  checkSpellingOfString:startingAt:
- (NSRange) checkSpellingOfString: (NSString *) stringToCheck startingAt: (int) startingOffset;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
1.0.3 improved for check spelling as you type.
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//NSLog(@"2- stringToCheck= %@", stringToCheck);
    NSRange R = [super checkSpellingOfString: stringToCheck startingAt: startingOffset];
//NSLog(@"[stringToCheck substringWithRange: %@]: %@", NSStringFromRange(R), [stringToCheck substringWithRange: R]);
    return R;
}
@end
#endif
#warning this should live somwhere else
#import "NSCursor_iTeXMac.h"
@interface iTMXTextView: NSTextView
@end
@implementation iTMXTextView
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= resetCursorRects:
- (void) resetCursorRects;
/*"Extracted from apple sample code (TextLinks).
Version history: jlaurens@users.sourceforge.net
- 1.3: 06/19/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSAttributedString* attrString = [self textStorage];
    //	Figure what part of us is visible (we're typically inside a scrollview)
    NSPoint containerOrigin = [self textContainerOrigin];
    //	Figure the range of characters which is visible
    NSRect visRect = NSOffsetRect ([self visibleRect], -containerOrigin.x, -containerOrigin.y);
    NSRange visibleGlyphRange = [[self layoutManager] glyphRangeForBoundingRect: visRect inTextContainer: [self textContainer]];
    NSRange visibleCharRange = [[self layoutManager] characterRangeForGlyphRange: visibleGlyphRange actualGlyphRange: nil];
    //	Prime for the loop
    NSRange attrsRange = NSMakeRange (visibleCharRange.location, 0);
    //	Loop until we reach the end of the visible range of characters
    while (NSMaxRange(attrsRange) < NSMaxRange(visibleCharRange)) // find all visible URLs and set up cursor rects
    {
        //	Find the next link inside the range
        if ([attrString attribute: NSLinkAttributeName atIndex: NSMaxRange(attrsRange) effectiveRange: &attrsRange] != nil)
        {
            unsigned int rectCount, rectIndex;
            //	Find the rectangles where this range falls. (We could use -boundingRectForGlyphRange:...,
            //	but that gives a single rectangle, which might be overly large when a link runs
            //	through more than one line.)
            NSRectArray rects = [[self layoutManager] rectArrayForCharacterRange: attrsRange
                withinSelectedCharacterRange: NSMakeRange (NSNotFound, 0)
                inTextContainer: [self textContainer]
                rectCount: &rectCount];

            //	For each rectangle, find its visible portion and ask for the cursor to appear
            //	when they're over that rectangle.
            for (rectIndex = 0; rectIndex < rectCount; ++rectIndex)
            {
                [self addCursorRect: NSIntersectionRect (rects[rectIndex], [self visibleRect]) cursor: [NSCursor fingerCursor]];
            }
        }
    }
    return;
}
@end
#import "NSView_iTeXMac.h"
#import "iTMXAttributedString.h"
int main(int argc, const char *argv[])
{
//    [iTMXSpellChecker poseAsClass: [NSSpellChecker class]];
    [iTMXAttributedString poseAsClass: [NSAttributedString class]];
//    [iTMXView poseAsClass: [NSView class]];
    [iTMXTextView poseAsClass: [NSTextView class]];
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    NSLog(@"Welcome To %@ version %@", [[NSBundle mainBundle] objectForInfoDictionaryKey: @"CFBundleExecutable"], [[NSBundle mainBundle] objectForInfoDictionaryKey: @"CFBundleVersion"]);
    [pool release];
    return NSApplicationMain(argc, argv);
}
