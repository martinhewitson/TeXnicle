/*
//  iTMApplication.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Dec 03 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMApplication.h"
#import "iTMColorPanelAccessoryViewController.h"

@interface NSObject(iTMApplication)
- (void) displayFirstPage: (id) sender;
- (void) displayLastPage: (id) sender;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMApplication
/*"Description forthcoming."*/
@implementation iTMApplication
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  sendEvent:
- (void) sendEvent: (NSEvent *) anEvent;
/*"I am ashamed. This might be done elsewhere, but i do not know where or how...
This patch deals with command+arrow keystroke: different meanings while in text view or in pdf view.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    switch([anEvent type])
    {
        case NSKeyDown:
        {
            int mask = NSAlphaShiftKeyMask|NSShiftKeyMask|NSControlKeyMask|NSAlternateKeyMask|NSCommandKeyMask;
//            NSLog(@"[anEvent modifierFlags]: %u, %u, %u, %u", mask, [anEvent modifierFlags], mask & [anEvent modifierFlags], NSCommandKeyMask | NSAlternateKeyMask);
            if(([anEvent modifierFlags] & mask) == NSCommandKeyMask)
            {
                NSString * CIM = [anEvent charactersIgnoringModifiers];
                if([CIM length])
                {
                    switch([CIM characterAtIndex: 0])
                    {
                        case NSUpArrowFunctionKey:
                        {
                            NSResponder * TV = [self targetForAction: @selector(moveToBeginningOfDocument:)];
                            if(TV)
                            {
                                [TV moveToBeginningOfDocument: self];
                                return;
                            }
                        }
                        case NSDownArrowFunctionKey:
                        {
                            NSResponder * TV = [self targetForAction: @selector(moveToEndOfDocument:)];
                            if(TV)
                            {
                                [TV moveToEndOfDocument: self];
                                return;
                            }
                        }
                        case NSLeftArrowFunctionKey:
                        {
                            NSResponder * TV = [self targetForAction: @selector(moveToBeginningOfLine:)];
                            if(TV)
                            {
                                [TV moveToBeginningOfLine: self];
                                return;
                            }
                        }
                        case NSRightArrowFunctionKey:
                        {
                            NSResponder * TV = [self targetForAction: @selector(moveToEndOfLine:)];
                            if(TV)
                            {
                                [TV moveToEndOfLine: self];
                                return;
                            }
                        }
                    }
                }
            }
            else if(([anEvent modifierFlags] & mask) == (NSCommandKeyMask | NSAlternateKeyMask))
            {
                NSString * CIM = [anEvent charactersIgnoringModifiers];
                if([CIM length])
                {
                    switch([CIM characterAtIndex: 0])
                    {
                        case NSEndFunctionKey:
                        {
                            SEL A = @selector(displayLastPage:);
                            [[self targetForAction: A] performSelector: A withObject: self];
                            return;
                        }
                        case NSHomeFunctionKey:
                        {
                            SEL A = @selector(displayFirstPage:);
                            [[self targetForAction: A] performSelector: A withObject: self];
                            return;
                        }
                    }
                }
            }
            break;
        }
        #if 0
        #warning DEBUGGGGGGGGGG
        case NSLeftMouseDown:
        case NSLeftMouseUp:
        {
            NSLog(@"MouseDown");
            NSLog(@"type             %i", [anEvent type]);
            NSLog(@"window           %@", [anEvent window]);
            NSLog(@"windowNumber     %i", [anEvent windowNumber]);
            NSLog(@"locationInWindow %@", NSStringFromPoint([anEvent locationInWindow]));
            NSLog(@"clickCount       %i", [anEvent clickCount]);
            NSLog(@"buttonNumber     %i", [anEvent buttonNumber]);
            NSLog(@"pressure         %f", [anEvent pressure]);
        }
        #endif
        default:
            break;
    }
    [super sendEvent: anEvent];
    return;
}
#if 0
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showHelp:
- (IBAction) showHelp: (id) sender;
/*"If there is a localized book, it is opened. Otherwise the normal help book is opened via the inherited implementation of #{showHelp:}.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    unsigned modifierFlags = [[NSApp currentEvent] modifierFlags];
    BOOL option = (modifierFlags & NSAlternateKeyMask) && !(modifierFlags & NSCommandKeyMask);
    if(option)
    {
        NSBundle * B = [NSBundle bundleForClass: [self class]];
        NSString * key = @"CFBundleHelpBookName";
        NSString * book = [[B localizedInfoDictionary] objectForKey: key];
        if(!book)
            book = [[B linfoDictionary] objectForKey: key];
        NSLog(@"Opening help book: %@", book);
        if([[NSWorkspace sharedWorkspace] openURL: [[[NSURL alloc] initWithString:
                [NSString stringWithFormat: @"help:openbook=\"%@\"", book]] autorelease]])
            return;
    }
    [super showHelp: sender];
    return;
}
#endif
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  orderFrontColorPanel:
- (IBAction) orderFrontColorPanel: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.2: 03/10/2002
To Do List:
"*/
{
    static BOOL firstTime = YES;
    if(![[NSColorPanel sharedColorPanel] accessoryView] && firstTime)
    {
        firstTime = NO;
        NSView * AV = [iTMColorPanelAccessoryViewController view];
        [[AV viewWithTag: 1] setStringValue: @""];
        [[NSColorPanel sharedColorPanel] setAccessoryView: AV];
    }
    [super orderFrontColorPanel: sender];
    return;
}
@end

#import "iTMTeXDocument.h"

@implementation iTMApplication(iTMScripting)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  orderedTeXDocuments:
- (id) orderedTeXDocuments;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net (02/06/2002)
- 1.1: 06/01/2002
To Do List:
"*/
{
    NSEnumerator * E = [[self orderedDocuments] objectEnumerator];
    NSDocument * D;
    NSMutableArray * MA = [NSMutableArray array];
    while(D = [E nextObject])
    {
        if(([D isKindOfClass: [iTMTeXDocument class]]) && ([MA indexOfObject: D] == NSNotFound))
            [MA addObject: D];
    }
    return [[MA copy] autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  insertInOrderedTeXDocuments:atIndex:
- (void) insertInOrderedTeXDocuments: (NSDocument *) document atIndex: (int) index;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net (02/06/2002)
- 1.1: 06/01/2002
To Do List:
"*/
{
    if([document isKindOfClass: [iTMTeXDocument class]])
    {
        
        if([[self orderedTeXDocuments] indexOfObject: document] == NSNotFound)
            [[NSDocumentController sharedDocumentController] addDocument: document];
        
        if(index == 0)
        {
            [document makeWindowControllers];
            {
                NSEnumerator * E = [[document windowControllers] objectEnumerator];
                NSWindowController * WC;
                while(WC = [E nextObject])
                {
                    [[WC window] orderFront: self];
                }
            }
        }
    }
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMApplication

