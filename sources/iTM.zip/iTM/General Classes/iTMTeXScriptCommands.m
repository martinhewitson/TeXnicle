/*
//  iTMTeXScriptCommands.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Dec 03 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMTeXScriptCommands.h"
#import <Cocoa/Cocoa.h>
#import "NSDocumentController_iTeXMac.h"
#import "iTMProjectDocument.h"
#import "iTMProjectEngineer.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMTeXScriptCommands
/*"Description forthcoming."*/

NSString * const iTMApplFileNameKey = @"File";// the name of AppleScript argument

@implementation iTMTeXTypesetCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 05/01/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//NSLog(@"directParameter: %@", [self directParameter]);
//NSLog(@"evaluatedArguments: %@", [self evaluatedArguments]);
    NSString * path = [self directParameter];
    if(![path isKindOfClass: [NSString class]])
        path = [[self evaluatedArguments] objectForKey: @"File"];
    if([path isKindOfClass: [NSString class]])
    {
        path = [path stringByStandardizingPath];
        if([[NSFileManager defaultManager] isReadableFileAtPath: path])
            [[[NSDocumentController sharedDocumentController] projectForFileName: path] typeset: path];
        else
            NSLog(@"No readable file at path: %@", path);
    }
    else
    {
        NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
        NSLog(@"Missing direct parameter...");
    }
    return nil;
}
@end

@implementation iTMTeXCompileCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 05/01/2003
To Do List:
"*/
{
NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
NSLog(@"directParameter: %@", [self directParameter]);
NSLog(@"directParameter: 0x%x", [self directParameter]);
NSLog(@"directParameter: %@", [[self directParameter] class]);
NSLog(@"evaluatedReceivers: %@", [self evaluatedReceivers]);
NSLog(@"receiversSpecifier: %@", [self receiversSpecifier]);
    NSString * path = [self directParameter];
    if(![path isKindOfClass: [NSString class]])
        path = [[self evaluatedArguments] objectForKey: @"File"];
    if([path isKindOfClass: [NSString class]])
    {
        path = [path stringByStandardizingPath];
        if([[NSFileManager defaultManager] isReadableFileAtPath: path])
            [[[NSDocumentController sharedDocumentController] projectForFileName: path] compile: path];
        else
            NSLog(@"No readable file at path: %@", path);
    }
    else
    {
        NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
        NSLog(@"Missing path as direct parameter or File (kfil) argument...");
    }
    return nil;
}
@end

@implementation iTMTeXBibliographyCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 05/01/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[self directParameter] stringByStandardizingPath];
    if(![path isKindOfClass: [NSString class]])
        path = [[self evaluatedArguments] objectForKey: @"File"];
    if([[NSFileManager defaultManager] isReadableFileAtPath: path])
        [[[NSDocumentController sharedDocumentController] projectForFileName: path] makeTheBibliography: path];
    else
        NSLog(@"No readable file at path: %@", path);
    return nil;
}
@end

@implementation iTMTeXGlossaryCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 05/01/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[self directParameter] stringByStandardizingPath];
    if(![path isKindOfClass: [NSString class]])
        path = [[self evaluatedArguments] objectForKey: @"File"];
    if([[NSFileManager defaultManager] isReadableFileAtPath: path])
        [[[NSDocumentController sharedDocumentController] projectForFileName: path] makeTheGlossary: path];
    else
        NSLog(@"No readable file at path: %@", path);
    return nil;
}
@end

@implementation iTMTeXIndexCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 05/01/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[self directParameter] stringByStandardizingPath];
    if(![path isKindOfClass: [NSString class]])
        path = [[self evaluatedArguments] objectForKey: @"File"];
    if([[NSFileManager defaultManager] isReadableFileAtPath: path])
        [[[NSDocumentController sharedDocumentController] projectForFileName: path] makeTheIndex: path];
    else
        NSLog(@"No readable file at path: %@", path);
    return nil;
}
@end

@implementation iTMTeXSpecialCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 05/01/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[self directParameter] stringByStandardizingPath];
    if(![path isKindOfClass: [NSString class]])
        path = [[self evaluatedArguments] objectForKey: @"File"];
    if([[NSFileManager defaultManager] isReadableFileAtPath: path])
        [[[NSDocumentController sharedDocumentController] projectForFileName: path] special: path];
    else
        NSLog(@"No readable file at path: %@", path);
    return nil;
}
@end

@implementation iTMTeXCleanCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 05/01/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[self directParameter] stringByStandardizingPath];
    if(![path isKindOfClass: [NSString class]])
        path = [[self evaluatedArguments] objectForKey: @"File"];
    if([[NSFileManager defaultManager] isReadableFileAtPath: path])
        [[[NSDocumentController sharedDocumentController] projectForFileName: path] clean: path];
    else
        NSLog(@"No readable file at path: %@", path);
    return nil;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMTeXScriptCommands

