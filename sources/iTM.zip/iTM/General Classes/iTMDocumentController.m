/*
//  iTMDocumentController.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sat Sep 22 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import <Carbon/Carbon.h>
#import "NSMenu_iTeXMac.h"
#import "iTMPathUtilities.h"
#import "iTMDocumentController.h"
#import "iTMProjectsManager.h"
#import "iTMProjectDocument.h"
#import "iTMProjectDocument(Accessors).h"
#import "iTMTeXDocument.h"
#import "iTMRepDocument.h"
#import "iTMRenderDocument.h"
#import "iTMPDFDocument.h"
#import "iTMMacroDocument.h"
#import "iTMEncodingController.h"
#import "iTMSessionManager.h"
#import "iTMAutoSaveController.h"

NSString * const iTMProjectDocumentsKey = @"Projects";
NSString * const iTMTeXDocumentsKey = @"TeX Documents";
NSString * const iTMMetaPostDocumentsKey = @"MetaPost Documents";
NSString * const iTMRepresentationDocumentsKey = @"Image, PDF Documents";
NSString * const iTMAuxiliaryDocumentsKey = @"Auxiliary Files";
NSString * const iTMLogDocumentsKey = @"Log Files";
#define iTMTextDocumentsKey NSStringPboardType
NSString * const iTMMacrosDocumentsKey = @"iTeXMac Macros";

NSString * const iTMUDUsesPDFHelperKey = @"iTMUsesExternalPDFViewer";
NSString * const iTMUDPDFHelperKey = @"iTMExternalPDFViewer";
NSString * const iTMUDUsesTeXHelperKey = @"iTMUsesExternalTextEditor";
NSString * const iTMUDTeXHelperKey = @"iTMExternalTextEditor";
NSString * const iTMUDUsesXDVIKey = @"iTMUDUsesXDVI";

NSString * const iTMDocumentControllerWillCloseAllNotification = @"iTMDocumentControllerWillCloseAll";
NSString * const iTMDocumentControllerDidCloseAllNotification = @"iTMDocumentControllerDidCloseAll";

@interface __iTMDocumentController_PRIVATE_1: NSObject
@end
@interface __iTMDocumentController_PRIVATE_2: NSObject
@end

@implementation __iTMDocumentController_PRIVATE_1
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= panel:isValidFilename:
+ (BOOL) panel: (id) sender isValidFilename: (NSString *) filename;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
#warning this may break something!!!
    if([[NSFileManager defaultManager] fileExistsAtPath: filename])
    {
//	NSBeginAlertSheet(NSString *title, NSString *defaultButton, NSString *alternateButton, NSString *otherButton, NSWindow *docWindow, id modalDelegate, SEL didEndSelector, SEL didDismissSelector, void *contextInfo, NSString *msg, ...);
    }
    return [[NSFileManager defaultManager] isWritableFileAtPath: [filename stringByDeletingLastPathComponent]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= panel:shouldShowFilename:
+ (BOOL) panel: (id) sender shouldShowFilename: (NSString *) filename;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: deal with aliases and links
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//    filename = [[filename stringByStandardizingPath] stringByResolvingSymlinksAndFinderAliasesInPath];
    NSDictionary * attributes = [[NSFileManager defaultManager] fileAttributesAtPath: filename traverseLink: YES];
    NSString * fileType = [attributes fileType];
    return [[NSWorkspace sharedWorkspace] isFilePackageAtPath: filename]
                || ![fileType isEqualToString: NSFileTypeDirectory]
                    || [[NSFileManager defaultManager] isWritableFileAtPath: filename];
}
@end
@implementation __iTMDocumentController_PRIVATE_2
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= panel:shouldShowFilename:
+ (BOOL) panel: (id) sender shouldShowFilename: (NSString *) filename;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: deal with aliases and links
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    filename = [[filename stringByStandardizingPath] stringByResolvingSymlinksAndFinderAliasesInPath];
    {
        NSString * fileType = [[[NSFileManager defaultManager] fileAttributesAtPath: filename traverseLink: YES] fileType];
        if([[NSWorkspace sharedWorkspace] isFilePackageAtPath: filename] || [fileType isEqualToString: NSFileTypeRegular])
//            return [[filename pathExtension] isEqualToString: @"mTeXMac"] ||
        {
//NSLog
//NSLog(@"extension: %@ type: %@", [filename pathExtension], [self typeFromFileExtension: [filename pathExtension]]);
                NSArray * types = [[[[NSDocumentController sharedDocumentController] openFileTypePopUp] selectedItem] representedObject];
                NSString * extension = [filename pathExtension];
//NSLog(@"<<");
//NSLog(@"filename: %@", filename);
//NSLog(@"fileType: %@", [self typeFromFileExtension: extension]);
//NSLog(@"types: %@", types);
//NSLog(@"index: %i", [types indexOfObject: [self typeFromFileExtension: extension]]);
//NSLog(@">>");
               return ([types indexOfObject: [[NSDocumentController sharedDocumentController] typeFromFileExtension: extension]] != NSNotFound);
        }
        else
            return [fileType isEqualToString: NSFileTypeDirectory];
    }
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMDocumentController
/*"Adds management for project documents.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: the popUp choice should be in the user defaults...
"*/
@implementation iTMDocumentController
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initialize
+ (void) initialize;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSUserDefaults standardUserDefaults] registerDefaults: [NSDictionary dictionaryWithObjectsAndKeys: 
        [NSNumber numberWithBool: NO], iTMUDUsesPDFHelperKey,
        @"Acrobat Reader 5.0", iTMUDPDFHelperKey,
        [NSNumber numberWithBool: NO], iTMUDUsesTeXHelperKey,
        @"TextEdit", iTMUDTeXHelperKey,
            nil]];
    [iTMAutoSaveController description];
    #if 0
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"tex"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"sty"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"dtx"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"aux"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"lof"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"ind"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"toc"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"log"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"bib"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"bbl"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"blg"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"ilg"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"idx"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"mTeXMac"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"pTeXMac"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"jpg"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"tiff"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"pdf"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"dvi"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"ps"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"eps"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"1"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"2"]);
    NSLog(@"%@", [[self sharedDocumentController] typeFromFileExtension: @"3"]);
    #endif
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= dealloc
- (void) dealloc;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSDistributedNotificationCenter defaultCenter] removeObserver: self];
    [self setOpenStringEncodingPopUp: nil];
    [self setOpenFileTypePopUp: nil];
    [self setNewFileTypePopUp: nil];
    [self setAutoStringEncodingCheck: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= awakeFromNib
- (void) awakeFromNib;
/*"The first instance MUST be created in the main nib file.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([[self superclass] instancesRespondToSelector: _cmd])
        [super performSelector: _cmd];
    [[NSDistributedNotificationCenter defaultCenter] addObserver: self
        selector: @selector(shouldOpenTextFile:)
            name: @"iTMTextEditorShouldOpenTextFile"
                object: nil
                    suspensionBehavior: NSNotificationSuspensionBehaviorDeliverImmediately];
    [[NSDistributedNotificationCenter defaultCenter] addObserver: self
        selector: @selector(shouldUpdateDocuments:)
            name: @"iTeXMacShouldUpdateDocuments"
                object: nil
                    suspensionBehavior: NSNotificationSuspensionBehaviorDeliverImmediately];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= validateUserInterface
- (void) validateUserInterface;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSUserDefaults * SUD = [NSUserDefaults standardUserDefaults];
    [SUD setObject: [SUD objectForKey: iTMPreferredStringEncodingKey] forKey: iTMOpenStringEncodingKey];
    {
        [_ASEC setEnabled: YES];
        [_ASEC setState: [SUD boolForKey: iTMAutoCharacterEncodingKey]? NSOnState: NSOffState];
    }
    if(_OSEP)
    {
        int tag = [[NSUserDefaults standardUserDefaults] integerForKey: iTMOpenStringEncodingKey];
        [_OSEP removeAllItems];
        [_OSEP setMenu: [iTMEncodingController stringEncodingsMenuWithAction: NULL target: nil]];
        NS_DURING
        tag = [_OSEP indexOfItemWithTag: tag];
        [_OSEP selectItemAtIndex: tag];
//NSLog
//NSLog(@"index %u", tag);
        NS_HANDLER
        if([_OSEP numberOfItems]) [_OSEP selectItemAtIndex: 0];
        NS_ENDHANDLER
    }
    {
        [_OFTP removeAllItems];
        [_OFTP addItemWithTitle: NSLocalizedStringFromTableInBundle(iTMTeXDocumentsKey, @"General",
                    [NSBundle bundleForClass: [self class]], "Human readable")];
        [[_OFTP lastItem] setRepresentedObject: [NSArray arrayWithObjects:
                    [self typeFromFileExtension: @"tex"],
                    [self typeFromFileExtension: @"mp"], nil]];
        [_OFTP addItemWithTitle: NSLocalizedStringFromTableInBundle(iTMProjectDocumentsKey, @"General",
                    [NSBundle bundleForClass: [self class]], "Human readable")];
        [[_OFTP lastItem] setRepresentedObject: [NSArray arrayWithObject: [self typeFromFileExtension: @"pTeXMac"]]];
        [_OFTP addItemWithTitle: NSLocalizedStringFromTableInBundle(iTMRepresentationDocumentsKey, @"General",
                    [NSBundle bundleForClass: [self class]], "Human readable")];
        [[_OFTP lastItem] setRepresentedObject: [NSArray arrayWithObjects:
                    [self typeFromFileExtension: @"tif"],
                    [self typeFromFileExtension: @"pdf"],
                    [self typeFromFileExtension: @"dvi"],
                    [self typeFromFileExtension: @"ps"],
                    [self typeFromFileExtension: @"eps"], nil]];
        [_OFTP addItemWithTitle: NSLocalizedStringFromTableInBundle(iTMTextDocumentsKey, @"General",
                    [NSBundle bundleForClass: [self class]], "Human readable")];
        [[_OFTP lastItem] setRepresentedObject: [NSArray arrayWithObjects:
                    NSStringPboardType,
                    [self typeFromFileExtension: @"sty"],
                    [self typeFromFileExtension: @"dtx"],
                    [self typeFromFileExtension: @"aux"],
                    [self typeFromFileExtension: @"lof"],
                    [self typeFromFileExtension: @"ind"],
                    [self typeFromFileExtension: @"toc"],
                    [self typeFromFileExtension: @"log"],
                    [self typeFromFileExtension: @"bib"],
                    [self typeFromFileExtension: @"bbl"],
                    [self typeFromFileExtension: @"blg"],
                    [self typeFromFileExtension: @"ilg"],
                    [self typeFromFileExtension: @"idx"], nil]];
        [_OFTP addItemWithTitle: NSLocalizedStringFromTableInBundle(iTMMacrosDocumentsKey, @"General",
                    [NSBundle bundleForClass: [self class]], "Human readable")];
        [[_OFTP lastItem] setRepresentedObject: [NSArray arrayWithObject: [self typeFromFileExtension: @"mTeXMac"]]];
        #warning add defaults here ?
        [_OFTP selectItemAtIndex: 0];
    }
    {
        [_NFTP removeAllItems];
        [_NFTP addItemWithTitle: [self displayNameForType: [self typeFromFileExtension: @"tex"]]];
        [[_NFTP lastItem] setRepresentedObject: [self typeFromFileExtension: @"tex"]];
        [_NFTP addItemWithTitle: [self displayNameForType: [self typeFromFileExtension: @"mp"]]];
        [[_NFTP lastItem] setRepresentedObject: [self typeFromFileExtension: @"mp"]];
        [_NFTP addItemWithTitle: [self displayNameForType: NSStringPboardType]];
        [[_NFTP lastItem] setRepresentedObject: [self typeFromFileExtension: NSStringPboardType]];
        [_NFTP addItemWithTitle: [self displayNameForType: [self typeFromFileExtension: @"pTeXMac"]]];
        [[_NFTP lastItem] setRepresentedObject: [self typeFromFileExtension: @"pTeXMac"]];
        [_NFTP addItemWithTitle: [self displayNameForType: [self typeFromFileExtension: @"mTeXMac"]]];
        [[_NFTP lastItem] setRepresentedObject: [self typeFromFileExtension: @"mTeXMac"]];
        [_NFTP selectItemAtIndex: 0];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= shouldOpenTextFile:
- (void) shouldOpenTextFile: (NSNotification *) aNotification;
/*"This is the answer to the notification sent by the "e_Helper" tool.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: see the warning below
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSDictionary * dico = [aNotification userInfo];
    NSString * fileName = [dico objectForKey: @"fileName"];
    NSString * lineNumber = [dico objectForKey: @"lineNumber"];
    if([fileName isKindOfClass: [NSString class]])
    {
        iTMTeXDocument * doc = [self openDocumentWithContentsOfFile: [fileName stringByStandardizingPath] display: YES];
        if([lineNumber respondsToSelector: @selector(intValue)])
        {
            NSEnumerator * enumerator = [[doc windowControllers] objectEnumerator];
            id WC;
            while(WC = [enumerator nextObject])
                if([WC respondsToSelector: @selector(highlightAndScrollLineToVisible:)])
                    [WC highlightAndScrollLineToVisible: [lineNumber intValue]];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= shouldUpdateDocuments:
- (void) shouldUpdateDocuments: (NSNotification *) aNotification;
/*"This is the answer to the notification sent by the "iTeXMac_Update" tool.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: see the warning below
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSDictionary * D = [aNotification userInfo];
    NSArray * documents = [D objectForKey: @"documents"];
    int count = [documents respondsToSelector: @selector(count)]? [documents count]: 0;
    NSEnumerator * E = [documents respondsToSelector: @selector(objectEnumerator)]? [documents objectEnumerator]: nil;
    if(!E || !count)
        E = [[self documents] objectEnumerator];
    id fileName;
    while(fileName = [E nextObject])
    {
        if([fileName isKindOfClass: [NSString class]])
        {
            fileName = [fileName stringByStandardizingPath];
//NSLog(@"fileName: %@", fileName);
            NSDocument * doc = [self documentForFileName: fileName];
//NSLog(@"doc: %@", doc);
            if(doc)
                [doc revertDocumentToSaved: self];
            else
                doc = [self openDocumentWithContentsOfFile: fileName display: YES];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMGetter()
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openFileTypePopUp
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= newFileTypePopUp
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= autoStringEncodingCheck
#define iTMGetter(source, getter) - (id) getter;{return source;}
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
iTMGetter(_OFTP, openFileTypePopUp);
iTMGetter(_OSEP, openStringEncodingPopUp);
iTMGetter(_NFTP, newFileTypePopUp);
iTMGetter(_ASEC, autoStringEncodingCheck);
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMStrongSetter()
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setAutoStringEncodingCheck:
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setOpenFileTypePopUp:
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setNewFileTypePopUp:
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setOpenStringEncodingPopUp:
#define iTMStrongSetter(source, className, setter)\
- (void) setter: (id) argument;\
{\
    if(![source isEqual: argument])\
    {\
        if(argument && ![argument isKindOfClass: [className class]])\
            [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] bad argument class: %@.",\
                [self class], NSStringFromSelector(_cmd), argument];\
        else\
        {\
            [source release];\
            source = [argument retain];\
        }\
    }\
    return;\
}
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
iTMStrongSetter(_ASEC, NSButton, setAutoStringEncodingCheck);
iTMStrongSetter(_OFTP, NSPopUpButton, setOpenFileTypePopUp);
iTMStrongSetter(_NFTP, NSPopUpButton, setNewFileTypePopUp);
iTMStrongSetter(_OSEP, NSPopUpButton, setOpenStringEncodingPopUp);
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openFileTypeChosen:
- (void) openFileTypeChosen: (id) sender;
/*"Sent by the file type pull down button. Validates the panel visible columns.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: see the warning below
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    id panel = [sender window];
#warning next does not work, ask cocoa-dev, cocoa-dev asked, no answer yet, still no (4+ weeks, no more count)
    [panel validateVisibleColumns];
    {
        NSBrowser * browser = [[panel contentView] viewWithTag: NSFileHandlingPanelBrowser];
        [browser reloadColumn: [browser lastColumn]];
    }
    {
        id types = [[sender selectedItem] representedObject];
        BOOL flag = (([types indexOfObject: iTMTeXDocumentType] != NSNotFound) ||
            ([types indexOfObject: NSStringPboardType] != NSNotFound));
        [[self autoStringEncodingCheck] setEnabled: flag];
        [[self openStringEncodingPopUp] setEnabled: flag];
    }
//NSLog
//NSLog(@"%@", [[[self openFileTypePopUp] selectedItem] representedObject]);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  openStringEncodingChosen:
- (void) openStringEncodingChosen: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (11/10/2001).
To do list:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSLog(@"openStringEncodingChosen %d", [[sender selectedItem] tag]);
    [[NSUserDefaults standardUserDefaults] setInteger: [[sender selectedItem] tag] forKey: iTMOpenStringEncodingKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  toggleAutomaticStringEncoding:
- (void) toggleAutomaticStringEncoding: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (11/10/2001).
To do list:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSUserDefaults standardUserDefaults] setBool: ([sender state] != NSOffState) forKey: iTMAutoCharacterEncodingKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= newDocument:
- (void) newDocument: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    id newDoc = nil;
//NSLog(@"newDocument");
    [self validateUserInterface];
    if([NSApp runModalForWindow: newDocumentAssistantPanel] == NSOKButton)
    {
    	newDoc = [self openUntitledDocumentOfType: [[[self newFileTypePopUp] selectedItem] representedObject] display: YES];
        [newDoc saveDocument: self];
    }
//NSLog
//NSLog(@"openUntitledDocumentOfType: %@", [[[self newFileTypePopUp] selectedItem] representedObject]);
//NSLog
//NSLog(@"newDoc: %@", newDoc);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= newFileTypeChosen:
- (void) newFileTypeChosen: (id) sender;
/*"Sent by the file type pull down button. Validates the panel visible columns.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: see the warning below
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    _DocumentType = [[sender selectedCell] tag];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= newDocumentOK:
- (void) newDocumentOK: (id) sender;
/*"Sent by the file type pull down button. Validates the panel visible columns.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: see the warning below
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [NSApp stopModalWithCode: NSOKButton];
    [[sender window] orderOut: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= newDocumentCancel:
- (void) newDocumentCancel: (id) sender;
/*"Sent by the file type pull down button. Validates the panel visible columns.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: see the warning below
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [NSApp stopModalWithCode: NSCancelButton];
    [[sender window] orderOut: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openDocument:
- (void) openDocument: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSOpenPanel * OP = [NSOpenPanel openPanel];
    [OP setCanChooseFiles: YES];
    [OP setCanChooseDirectories: NO];
    [OP setTreatsFilePackagesAsDirectories: NO];
    [OP setAllowsMultipleSelection: YES];
    [OP setAccessoryView: openAccessoryView];
    [OP setDelegate: [__iTMDocumentController_PRIVATE_2 class]];
    [OP setResolvesAliases: YES];
    [self validateUserInterface];
    _OptionFlag = ([[NSApp currentEvent] modifierFlags] & NSAlternateKeyMask) > 0;
    if(NSOKButton == [self runModalOpenPanel: OP forTypes: [self fileExtensionsFromType: iTMTeXDocumentType]])
    {
        NSArray * filenames = [OP filenames];
        NSEnumerator * enumerator = [filenames objectEnumerator];
        NSString * fileName;
        while(fileName = [enumerator nextObject])
        {
            fileName = [fileName stringByResolvingSymlinksAndFinderAliasesInPath];
            NS_DURING
            [self openDocumentWithContentsOfFile: fileName display: YES];
            NS_HANDLER
            // catch the "NSWindow: -_newFirstResponderAfterResigining is not a valid message outside of a responder's implementation of -resignFirstResponder. exception"
            NSLog(@"Problem opening %@ due to %@", fileName, [localException reason]);
            NS_ENDHANDLER
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openUntitledDocumentOfType:display:
- (id) openUntitledDocumentOfType: (NSString *) aFileType display: (BOOL) aFlag;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSLog(@"openUntitledDocumentOfType... %@", aFileType);
    if([aFileType isEqualToString: iTMTeXDocumentType])
    {
        unsigned modifierFlags = [[NSApp currentEvent] modifierFlags];
        BOOL option = (modifierFlags & NSAlternateKeyMask) && !(modifierFlags & NSCommandKeyMask);
        BOOL usesTeXHelper = [self usesTeXHelper];
        if(option)
            usesTeXHelper = !usesTeXHelper;
        if(usesTeXHelper)
        {
            NSString * teXHelper = [[NSUserDefaults standardUserDefaults] stringForKey: iTMUDTeXHelperKey];
            if(([teXHelper length] > 0) &&
                            [[NSWorkspace sharedWorkspace] launchApplication: teXHelper])
                return nil;
        }
        else
            return [super openUntitledDocumentOfType: aFileType display: aFlag];
    }
    iTMProjectDocument * newDocument = [super openUntitledDocumentOfType: aFileType display: aFlag];
    if(aFlag && [newDocument isKindOfClass: [iTMProjectDocument class]])
    {
        [newDocument showProject: self];
    }
    return newDocument;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openUntitledDocumentOfTypeTeXDisplay:
- (id) openUntitledDocumentOfTypeTeXDisplay: (BOOL) aFlag;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSLog(@"openUntitledDocumentOfType...");
    return [self openUntitledDocumentOfType: iTMTeXDocumentType display: aFlag];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openUntitledDocumentOfTypeTeXDisplay:
- (id) openDocumentWithContentsOfFile: (NSString *) fileName display: (BOOL) display;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 2.0: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(!display)
        return [super openDocumentWithContentsOfFile: fileName display: display];
    NSParameterAssert([fileName isKindOfClass: [NSString class]]);
    NSString * fileType = [self typeFromFileExtension: [fileName pathExtension]];
    if([iTMTeXDocumentType isEqualToString: fileType])
    {
        NSString * folder = [fileName stringByDeletingLastPathComponent];
        if(![[NSFileManager defaultManager] isWritableFileAtPath: folder])
        {
            int answer = NSRunAlertPanel(
                                NSLocalizedStringFromTableInBundle(@"TeX problem", @"General",
                                                [NSBundle bundleForClass: [self class]], "Alert Panel Title"),
                                NSLocalizedStringFromTableInBundle(@"This file is stored at a write protected location:\n%@\nThis will prevent iTeXMac to properly process the file.", @"General",
                                                [NSBundle bundleForClass: [self class]], "Format with 1 %@"),
                                NSLocalizedStringFromTableInBundle(@"Save As...", @"General",
                                                [NSBundle bundleForClass: [self class]], "DF"),
                                NSLocalizedStringFromTableInBundle(@"Ignore", @"General",
                                                [NSBundle bundleForClass: [self class]], "DF"),
                                NSLocalizedStringFromTableInBundle(@"Cancel", @"General",
                                                [NSBundle bundleForClass: [self class]], "DF"),
                                folder);
            switch(answer)
            {
                case NSAlertOtherReturn:// cancel
                    return nil;
                break;
                case NSAlertErrorReturn:// error?
                case NSAlertAlternateReturn://ignore
                    return [super openDocumentWithContentsOfFile: fileName display: display];
                break;
//                case NSAlertDefaultReturn:
                default:// save as
                {
                    NSSavePanel * SP = [NSSavePanel savePanel];
                    [SP setPrompt: NSLocalizedStringFromTableInBundle(@"Save", @"General",
                                [NSBundle bundleForClass: [self class]], "DF.")];
                    [SP setTitle: NSLocalizedStringFromTableInBundle(@"TeX related problem", @"General",
                                [NSBundle bundleForClass: [self class]], "DF")];
                    [SP setRequiredFileType: [fileName pathExtension]];
                    [SP setTreatsFilePackagesAsDirectories: NO];
                    [SP setExtensionHidden: [[[NSFileManager defaultManager] fileAttributesAtPath: fileName traverseLink: NO] fileExtensionHidden]];
                    [SP setCanSelectHiddenExtension: YES];
                    [SP validateVisibleColumns];
                    [SP setDelegate: [__iTMDocumentController_PRIVATE_1 class]];
                    if(NSOKButton == [SP runModalForDirectory: [[NSUserDefaults standardUserDefaults] objectForKey: @"NSDefaultOpenDirectory"]
                                            file: [fileName lastPathComponent]])
                    {
                        NSString * newFileName = [SP filename];
                        if([[NSFileManager defaultManager] fileExistsAtPath: fileName])
                        {
                            NSBeep();
                            return nil;
                        }
                        if([[NSFileManager defaultManager] copyPath: fileName toPath: newFileName handler: nil])
                            fileName = newFileName;
                        else
                            NSRunCriticalAlertPanel(
                                NSLocalizedStringFromTableInBundle(@"Copying problem", @"General",
                                [NSBundle bundleForClass: [self class]], "Save as Panel Title"),
                                NSLocalizedStringFromTableInBundle(@"Could not copy from:\n%@\nto:\n%@\nProblem not solved.", @"General",
                                [NSBundle bundleForClass: [self class]], "Saving as problem. 2%@"),
                                nil, nil, nil, fileName, newFileName);
                        return [super openDocumentWithContentsOfFile: fileName display: display];
                    }
                    else
                        return nil;
                }
                break;
            }
        }
        else
            return [super openDocumentWithContentsOfFile: fileName display: display];
    }
    else
        return [super openDocumentWithContentsOfFile: fileName display: display];
}
#if 0
- (id)openDocumentWithContentsOfURL:(NSURL *)url display:(BOOL)display;
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    id D = [super openDocumentWithContentsOfURL:(NSURL *)url display:(BOOL)display];
//NSLog(@"D(url): %@", D);
    return D;
}
#endif
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openDocumentWithContentsOfFile:display:useHelperIfNeeded:
- (id) openDocumentWithContentsOfFile: (NSString *) fileName display: (BOOL) display useHelperIfNeeded: (BOOL) aFlag;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//NSLog(@"file name: %@", fileName);
    if(![fileName length])
        return nil;
#warning What about the write permission?
    unsigned modifierFlags = [[NSApp currentEvent] modifierFlags];
    BOOL option = (modifierFlags & NSAlternateKeyMask) && !(modifierFlags & NSCommandKeyMask) ?
                            YES: _OptionFlag;
    NSDocument * document = nil;
    NSString * type = [self typeFromFileExtension: [fileName pathExtension]];
//NSLog(@"type: %@", type);
    _OptionFlag = NO;// Critical (I do not remember why... hummm)
    if([type isEqualToString: NSPDFPboardType])
    {
        if(aFlag && (option? ![self usesPDFHelper]: [self usesPDFHelper]))
        {
            NSString * pdfHelper = [[NSUserDefaults standardUserDefaults] stringForKey: iTMUDPDFHelperKey];
            if(!(([pdfHelper length] > 0) &&
                            [[NSWorkspace sharedWorkspace] openFile: fileName withApplication: pdfHelper]))
                document = [self openDocumentWithContentsOfFile: fileName display: display];
            else
                // Critical: iTMGhostDocument is usefull when an external pdf viewer is used. see addDocument below.
                document = [self ghostDocument];
        }
        else
            document = [self openDocumentWithContentsOfFile: fileName display: display];
    }
    else if([type isEqualToString: iTMTeXDocumentType])
    {
        if(aFlag && (option? ![self usesTeXHelper]: [self usesTeXHelper]))
        {
            NSString * texHelper = [[NSUserDefaults standardUserDefaults] stringForKey: iTMUDTeXHelperKey];
            if(!(([texHelper length] > 0) &&
                            [[NSWorkspace sharedWorkspace] openFile: fileName withApplication: texHelper andDeactivate: YES]))
                document = [self openDocumentWithContentsOfFile: fileName display: display];
            else
                // critical: iTMGhostDocument is usefull when an external text editor is used. see addDocument below.
                document = [self ghostDocument];
        }
        else
            document = [self openDocumentWithContentsOfFile: fileName display: display];
    }
    else if([type isEqualToString: iTMDVIDocumentType])
    {
        NSString * input = [[fileName stringByDeletingPathExtension] stringByAppendingPathExtension: @"tex"];
        iTMProjectDocument * PD = [[iTMProjectsManager defaultManager] projectForFileName: input];
//NSLog(@"PD: %@", PD);
//NSLog(@"option: %@", (option? @"option": @"dont option"));
//NSLog(@"aFlag: %@", (aFlag? @"use helper": @"dont use helper"));
//NSLog(@"[PD usesXDVI]: %@", ([PD usesXDVI]? @"use xdvi": @"dont use xdvi"));
        return aFlag && (option? ![PD usesXDVI]: [PD usesXDVI])?
            [self ghostDocument]: [self openDocumentWithContentsOfFile: fileName display: display];
    }
    else
    {
//NSLog(@"opening %@ of type: %@(= %@)", fileName, type, iTMDVIDocumentType);
        document = [self openDocumentWithContentsOfFile: fileName display: display];
    }
    if([document isKindOfClass: [iTMProjectDocument class]])
    {
        if(![(iTMProjectDocument *)document isStrongGeneric] && display)
            [(iTMProjectDocument *)document showProject: self];
    }
    return document;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= addDocument:
- (void) addDocument: (NSDocument *) document;
/*"Description Forthcoming. Ghost documents are not added.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[iTMProjectsManager defaultManager] addDocument: document];
    [super addDocument: document];
    if([document isKindOfClass: [iTMGhostDocument class]])
        [self removeDocument: document];
    else if([document isKindOfClass: [iTMTeXDocument class]])
        ++_NumberOfTeXDocuments;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= removeDocument:
- (void) removeDocument: (NSDocument *) document;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[iTMProjectsManager defaultManager] removeDocument: document];
    [super removeDocument: document];
    if([document isKindOfClass: [iTMTeXDocument class]])
        --_NumberOfTeXDocuments;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= hasTeXDocuments
- (BOOL) hasTeXDocuments;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return _NumberOfTeXDocuments>0;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= noteNewRecentDocument:
- (void) noteNewRecentDocument: (NSDocument *) document;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([document isKindOfClass: [iTMGhostDocument class]])
        return;
    if([document isKindOfClass: [iTMProjectDocument class]] && [(iTMProjectDocument *)document isStrongGeneric])
        return;
    [super noteNewRecentDocument: document];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateMenuItem:
- (BOOL) validateMenuItem: (id) anItem;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    SEL action = [anItem action];
    if(action == @selector(openFileTypeChosen:))
        return YES;
    else if(action == @selector(newFileTypeChosen:))
        return YES;
    else if(action == @selector(openStringEncodingChosen:))
        return YES;
    else if(action == @selector(builtInPDFViewer:))
    {
        iTMProjectDocument * PD = [[iTMProjectsManager defaultManager] projectForFileName: [[self currentDocument] fileName]];
        [anItem setState: ([self usesPDFHelper] || [PD usesXDVI]? NSOffState: NSOnState)];
        return YES;
    }
    else if(action == @selector(XDviViewer:))
    {
        iTMProjectDocument * PD = [[iTMProjectsManager defaultManager] projectForFileName: [[self currentDocument] fileName]];
        [anItem setState: ([PD usesXDVI]? NSOnState: NSOffState)];
        return YES;
    }
    else if(action == @selector(preferredPDFViewer:))
    {
        NSString * title = [[[[NSUserDefaults standardUserDefaults] stringForKey: iTMUDPDFHelperKey]
                                    lastPathComponent] stringByDeletingPathExtension];
        [anItem setTitle: ([title length]? title: NSLocalizedStringFromTableInBundle(@"None", @"General",
                    [NSBundle bundleForClass: [self class]], "None"))];
        [anItem setState: ([self usesPDFHelper]? NSOnState: NSOffState)];
        return [title length] > 0;
    }
    else if(action == @selector(choosePreferredPDFViewer:))
        return YES;
    else if(action == @selector(builtInTeXEditor:))
    {
        [anItem setState: ([self usesTeXHelper]? NSOffState: NSOnState)];
        return YES;
    }
    else if(action == @selector(preferredTeXEditor:))
    {
        NSString * title = [[[[NSUserDefaults standardUserDefaults] stringForKey: iTMUDTeXHelperKey]
                                    lastPathComponent] stringByDeletingPathExtension];
        [anItem setTitle: ([title length]? title: NSLocalizedStringFromTableInBundle(@"None", @"General",
                    [NSBundle bundleForClass: [self class]], "None"))];
        [anItem setState: ([self usesTeXHelper]? NSOnState: NSOffState)];
        return [title length] > 0;
    }
    else if(action == @selector(choosePreferredTeXEditor:))
        return YES;
    else
        return [super validateMenuItem: anItem];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  closeAllDocumentsWithDelegate:didCloseAllSelector:contextInfo:
- (void) closeAllDocumentsWithDelegate: (id) delegate didCloseAllSelector: (SEL) didAllCloseSelector
contextInfo: (void *) contextInfo;
/*"Call back must have the following signature:
- (void) documentController: (id) DC didSaveAll: (BOOL) flag contextInfo: (void *) contextInfo;
Version History: jlaurens@users.sourceforge.net (12/07/2001)
- < 1.1: 03/10/2002
To Do List: to be improved...
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSNotificationCenter defaultCenter] postNotificationName: iTMDocumentControllerWillCloseAllNotification
        object: self];
    [super closeAllDocumentsWithDelegate: self
        didCloseAllSelector: @selector(_iTMPrivateDocumentController:didCloseAll:contextInfo:)
            contextInfo: [NSDictionary dictionaryWithObjectsAndKeys:
                                delegate, @"delegate",
                                NSStringFromSelector(didAllCloseSelector), @"selector",
                                (contextInfo? contextInfo: [NSNull null]), @"contextInfo",
                                                        nil]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _iTMPrivateDocumentController:didCloseAll:contextInfo:
- (void) _iTMPrivateDocumentController: (NSDocumentController *) docController didCloseAll:(BOOL) didCloseAll
contextInfo: (void *) contextInfo;
/*"Call back must have the following signature:
- (void) documentController: (if) DC didSaveAll: (BOOL) flag contextInfo: (void *) contextInfo;
Version History: jlaurens@users.sourceforge.net (01/02/2002)
- < 1.1: 03/10/2002
To Do List: to be improved..., post the notification in the end?
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(didCloseAll)
        [[NSNotificationCenter defaultCenter] postNotificationName: iTMDocumentControllerDidCloseAllNotification
            object: self];
    {
        id delegate = [(id)contextInfo objectForKey: @"delegate"];
        SEL action = NSSelectorFromString([(id)contextInfo objectForKey: @"selector"]);
        NSMethodSignature * itsMS = [delegate methodSignatureForSelector: action];
        id contInfo = [(id)contextInfo objectForKey: @"contextInfo"];
        if(itsMS)
        {
            NSInvocation * I = [NSInvocation invocationWithMethodSignature: itsMS];
            [I setSelector: action];
            [I setTarget: delegate];
            if([itsMS numberOfArguments]>2)
                [I setArgument: &self atIndex: 2];
            if([itsMS numberOfArguments]>3)
                [I setArgument: &didCloseAll atIndex: 3];
            if([itsMS numberOfArguments]>4)
                if([[NSNull null] isEqual: contInfo])
                    [I setArgument: nil atIndex: 4];
                else
                    [I setArgument: &contInfo atIndex: 4];
            [I invoke];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= ghostDocument
- (id) ghostDocument;
/*"Description forthcoming
Version History: jlaurens@users.sourceforge.net (12/07/2001)
- < 1.1: 03/10/2002
To Do List: to be improved...
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[[iTMGhostDocument alloc] init] autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= projectForFileName:
- (iTMProjectDocument *) projectForFileName: (NSString *) aFileName;
/*"Looks for a project concerning aFileName among the current open projects, regardless the extensions.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: look also in the projects stored.
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[iTMProjectsManager defaultManager] projectForFileName: aFileName];
}
@end

@implementation iTMDocumentController(Helpers)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  builtInPDFViewer:
- (IBAction) builtInPDFViewer: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[[iTMProjectsManager defaultManager] projectForFileName: [[self currentDocument] fileName]] setUsesXDVI: NO];
    [[NSUserDefaults standardUserDefaults] setObject: [NSNumber numberWithBool: NO] forKey: iTMUDUsesPDFHelperKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  preferredPDFViewer:
- (IBAction) preferredPDFViewer: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[[iTMProjectsManager defaultManager] projectForFileName: [[self currentDocument] fileName]] setUsesXDVI: NO];
    [[NSUserDefaults standardUserDefaults] setObject: [NSNumber numberWithBool: YES] forKey: iTMUDUsesPDFHelperKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  choosePreferredPDFViewer:
- (IBAction) choosePreferredPDFViewer: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSArray * ApplicationDirectories = NSSearchPathForDirectoriesInDomains(NSApplicationDirectory, NSLocalDomainMask, YES);
    if([ApplicationDirectories count])
    {
        NSOpenPanel * OP = [NSOpenPanel openPanel];
        [OP setAllowsMultipleSelection: NO];
        [OP setCanChooseFiles: NO];
        [OP setCanChooseDirectories: YES];
        [OP setResolvesAliases: YES];
        [OP setTreatsFilePackagesAsDirectories: NO];
        if(NSOKButton == [OP runModalForDirectory: [ApplicationDirectories objectAtIndex: 0]
                                    file: nil types: [NSArray arrayWithObject: @"app"]] && [[OP filenames] count])
        {
            [[NSUserDefaults standardUserDefaults] setObject: [[OP filenames] objectAtIndex: 0] forKey: iTMUDPDFHelperKey];
            [[NSUserDefaults standardUserDefaults]
            setObject: [NSNumber numberWithBool: YES] forKey: iTMUDUsesPDFHelperKey];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  usesPDFHelper
- (BOOL) usesPDFHelper;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[NSUserDefaults standardUserDefaults] boolForKey: iTMUDUsesPDFHelperKey];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  XDViViewer
- (void) XDviViewer: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    iTMProjectDocument * PD = [[iTMProjectsManager defaultManager] projectForFileName: [[self currentDocument] fileName]];
    [PD setUsesXDVI: ![PD usesXDVI]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  builtInTeXEditor:
- (IBAction) builtInTeXEditor: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSUserDefaults standardUserDefaults] setObject: [NSNumber numberWithBool: NO] forKey: iTMUDUsesTeXHelperKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  preferredTeXEditor:
- (IBAction) preferredTeXEditor: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSUserDefaults standardUserDefaults] setObject: [NSNumber numberWithBool: YES] forKey: iTMUDUsesTeXHelperKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  choosePreferredTeXEditor:
- (IBAction) choosePreferredTeXEditor: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSArray * ApplicationDirectories = NSSearchPathForDirectoriesInDomains(NSApplicationDirectory, NSLocalDomainMask, YES);
    if([ApplicationDirectories count])
    {
        NSOpenPanel * OP = [NSOpenPanel openPanel];
        [OP setAllowsMultipleSelection: NO];
        [OP setCanChooseFiles: NO];
        [OP setCanChooseDirectories: YES];
        [OP setResolvesAliases: YES];
        [OP setTreatsFilePackagesAsDirectories: NO];
        if(NSOKButton == [OP runModalForDirectory: [ApplicationDirectories objectAtIndex: 0]
                                    file: nil types: [NSArray arrayWithObject: @"app"]] && [[OP filenames] count])
        {
            [[NSUserDefaults standardUserDefaults] setObject: [[OP filenames] objectAtIndex: 0] forKey: iTMUDTeXHelperKey];
            [[NSUserDefaults standardUserDefaults]
            setObject: [NSNumber numberWithBool: YES] forKey: iTMUDUsesTeXHelperKey];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  usesTeXHelper
- (BOOL) usesTeXHelper;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[NSUserDefaults standardUserDefaults] boolForKey: iTMUDUsesTeXHelperKey];
}
@end

@implementation iTMGhostDocument
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMDocumentController

