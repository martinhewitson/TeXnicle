/*
//  iTMRenderDocument.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Thu Dec 13 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

//#import "iTMGeneralProject.h"
//#import "iTMProjectEngineer.h"
#import "iTMRenderDocument.h"
#import "NSDocumentController_iTeXMac.h"
#import "iTMTaskKit.h"
#import "iTMPathServer.h"
#import "iTMPathUtilities.h"

NSString * const iTMDVIDocumentType = @"iTMDVIPboardType";
NSString * const iTMEPSDocumentType = @"iTMEPSPboardType";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMRenderDocument
/*"Description forthcoming."*/
@implementation iTMRenderDocument
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 06/13/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[self taskController] removeInspector: self];
    [self setTaskController: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  windowControllerDidLoadNib:
- (void) windowControllerDidLoadNib: (NSWindowController *) WC;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 06/13/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [super windowControllerDidLoadNib: WC];
    [outputTextView setString: @""];
    [outputTextView setEditable: NO];
    [progressIndicator startAnimation: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  windowNibName
- (NSString *) windowNibName;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 06/13/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSStringFromClass([self class]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  makeWindowControllers
- (void) makeWindowControllers;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 06/13/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(_IsVisible) [super makeWindowControllers];
    return;;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  readFromFile:ofType:
- (BOOL) readFromFile: (NSString *) aFileName ofType: (NSString *) type;
/*" Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 06/13/2003
To Do List: better implementation...
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(![aFileName length])
        return NO;
    _IsCancelling = NO;
    _HasErrors = NO;
    NSString * PE = [[aFileName pathExtension] lowercaseString];
    NSString * output = [[aFileName stringByDeletingPathExtension] stringByAppendingPathExtension: @"pdf"];
    NSDate * inDate = [[[NSFileManager defaultManager] fileAttributesAtPath: [aFileName stringByResolvingSymlinksAndFinderAliasesInPath] traverseLink: NO] fileModificationDate];
    NSDate * outDate = [[[NSFileManager defaultManager] fileAttributesAtPath: output traverseLink: NO] fileModificationDate];
//NSLog(@"inDate: %@", inDate);
//NSLog(@"outDate: %@", outDate);
//NSLog(@"[outDate compare: inDate]: %i", [outDate compare: inDate]);
    if(!outDate || ([outDate compare: inDate] == NSOrderedAscending))
    {
        NSLog(@"rendering file: %@", aFileName);
        iTMTaskWrapper * TW = [[[iTMTaskWrapper alloc] init] autorelease];
        [TW replaceCurrentDirectoryPath: [aFileName stringByDeletingLastPathComponent]];
//NSLog(@"[iTMPathServer PATHForDomain: iTMTeXMFBinariesDomain]: %@", [iTMPathServer PATHForDomain: iTMTeXMFBinariesDomain]);
//NSLog(@"[iTMPathServer PATHForDomain: iTMGhostScriptDomain]: %@", [iTMPathServer PATHForDomain: iTMGhostScriptDomain]);
        [TW appendPATHComponent: [iTMPathServer PATHForDomain: iTMGhostScriptDomain]];
        [TW appendPATHComponent: [iTMPathServer PATHForDomain: iTMTeXMFBinariesDomain]];
        [TW appendPATHComponent: [[NSBundle mainBundle] executablePath]];
        [TW setEnvironmentString: [[aFileName lastPathComponent] stringByDeletingPathExtension] forKey: @"iTMInput"];
        [TW setEnvironmentString: [aFileName pathExtension] forKey: @"iTMInputExtension"];
        NSString * LP = [NSString string];
        if([PE isEqual: @"ps"])
            LP = @"ps2pdf.command";
        else if([PE isEqual: @"eps"])
            LP = @"epstopdf.command";
        else if([PE isEqual: @"dvi"])
            LP = @"dvipdf.command";
        else
        {
            NSLog(@"-[%@ %@] 0x%x Don't know how to render: %@(%@)", [self class], NSStringFromSelector(_cmd), self, [self fileName], PE);
            return NO;
        }
        LP = [[NSBundle mainBundle] pathForAuxiliaryExecutable: [@"Shell Scripts" stringByAppendingPathComponent: LP]];
        if([LP length])
        {
//NSLog(@"-[%@ %@] lauching task at path: %@", [self class], NSStringFromSelector(_cmd), LP);
            [TW setLaunchPath: LP];
            [[[[iTMTaskController allocWithZone: [self zone]] init] autorelease] addInspector: self];
            [[self taskController] addTaskWrapper: TW];
            [[self taskController] start];
            _IsVisible = YES;
        }
        else
        {
            NSLog(@"-[%@ %@] 0x%x Can't render: %@", [self class], NSStringFromSelector(_cmd), self, [self fileName]);
            _IsVisible = NO;
        }
    }
    else
    {
        NSLog(@"Using already rendered file: %@", output);
        [[NSDocumentController sharedDocumentController] openDocumentWithContentsOfFile: output display: YES useHelperIfNeeded: YES];
        [NSTimer scheduledTimerWithTimeInterval: 0 target: [self class] selector: @selector(_closeDocumentTimed:) userInfo: self repeats: NO];
        _IsVisible = NO;
    }
//NSLog(@"-[%@ %@] 0x%x (Render END)", [self class], NSStringFromSelector(_cmd), self);
    return YES;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _closeDocumentTimed:
+ (void) _closeDocumentTimed: (NSTimer *) timer;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 06/13/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(![[timer userInfo] hasErrors]) [[timer userInfo] close];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  logInput:
- (void) logInput: (NSString *) argument;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  logOutput:
- (void) logOutput: (NSString *) argument;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if([argument length])// otherwise raise
    {
        [outputTextView setEditable: YES];
        [outputTextView insertText: [[[NSAttributedString alloc] initWithString: argument attributes: [NSDictionary dictionaryWithObject: [NSColor blackColor] forKey: NSForegroundColorAttributeName]] autorelease]];
        [outputTextView setEditable: NO];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  logError:
- (void) logError: (NSString *) argument;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if([argument length])// otherwise raise
    {
        [outputTextView setEditable: YES];
        [outputTextView insertText: [[[NSAttributedString alloc] initWithString: argument attributes: [NSDictionary dictionaryWithObject: [NSColor redColor] forKey: NSForegroundColorAttributeName]] autorelease]];
        _HasErrors = YES;
        [outputTextView setEditable: NO];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  cleanLog
- (void) cleanLog;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  hasErrors
- (BOOL) hasErrors;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return _HasErrors;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  taskController
- (id) taskController;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return _TC;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setTaskController:
- (void) setTaskController: (iTMTaskController *) argument;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [iTMTaskController class]])
        [NSException raise: NSInvalidArgumentException format:
            @"-[%@ %@] iTMTaskController argument expected: got %@.",
                [self class], NSStringFromSelector(_cmd), argument];
    else if(_TC != argument)
    {
        [_TC autorelease];
        _TC = [argument retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= taskWillLaunch
- (void) taskWillLaunch;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= taskDidTerminate
- (void) taskDidTerminate;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[self fileName] stringByDeletingPathExtension];
    if([path length])
        [[NSDocumentController sharedDocumentController]
            openDocumentWithContentsOfFile: [path stringByAppendingPathExtension: @"pdf"]
                display: YES useHelperIfNeeded: YES];
    [NSTimer scheduledTimerWithTimeInterval: 0 target: [self class] selector: @selector(_closeDocumentTimed:) userInfo: self repeats: NO];
    [[self taskController] removeInspector: self];
    [progressIndicator stopAnimation: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= cancel:
- (void) cancel: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(!_IsCancelling)
    {
        _IsCancelling = YES;
        [self logError: @"Cancelling...\n"];
        [(iTMTaskController *)[self taskController] stop];
        [[self taskController] flush];
        iTMTaskWrapper * TW = [[[iTMTaskWrapper allocWithZone: [self zone]] init] autorelease];
        [TW replaceCurrentDirectoryPath: [[self fileName] stringByDeletingLastPathComponent]];
        [TW appendPATHComponent: [iTMPathServer PATHForDomain: iTMGhostScriptDomain]];
        [TW appendPATHComponent: [iTMPathServer PATHForDomain: iTMTeXMFBinariesDomain]];
        [TW appendPATHComponent: [[NSBundle mainBundle] executablePath]];
        [TW setEnvironmentString: [[[self fileName] lastPathComponent] stringByDeletingPathExtension] forKey: @"iTMInput"];
        [TW setEnvironmentString: [[self fileName] pathExtension] forKey: @"iTMInputExtension"];
        [TW setLaunchPath: [[NSBundle mainBundle] pathForAuxiliaryExecutable: [@"Shell Scripts" stringByAppendingPathComponent: @"cleaner.command"]]];
        [[self taskController] addTaskWrapper: TW];
        [[self taskController] start];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= closeDocument:
- (void) closeDocument: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/11/01)
- for 1.3: Mon Jun 02 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [self close];
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMRenderDocument

