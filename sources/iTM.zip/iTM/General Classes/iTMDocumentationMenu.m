/*
//  iTMDocumentationMenu.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Tue Sep 09 2003.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMDocumentationMenu.h"
#import "NSBundle_iTeXMac.h"
#import "iTMPathUtilities.h"
#import "iTMStatusNotification.h"

NSString * const iTMDocumentationRelativePath = @"iTeXMac Documentation";
NSString * const iTMDocumentationPathKey = @"iTMDocumentationPath";

@interface NSMenu(iTMDocumentationMenu)
+ (void) _menu: (NSMenu *) menu listDocumentationAtPath: (NSString *) path alreadyListed: (NSMutableArray *) alreadyListed;
+ (void) _menu: (NSMenu *) menu listDocumentationFilesAtPath: (NSString *) path alreadyListed: (NSMutableArray *) alreadyListed;
+ (void) _menu: (NSMenu *) menu listDocumentationFoldersAtPath: (NSString *) path alreadyListed: (NSMutableArray *) alreadyListed;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMDocumentationMenu
/*"Description forthcoming."*/
@implementation iTMDocumentationMenu
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initialize
+ (void) initialize;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Sep 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSUserDefaults standardUserDefaults]
        registerDefaults: [NSDictionary dictionaryWithObject:
            [[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent]
                                                    stringByAppendingPathComponent: iTMDocumentationRelativePath]
        forKey: iTMDocumentationPathKey]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithTitle:
- (id) initWithTitle: (NSString *) aTitle;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Sep 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(self = [super initWithTitle: aTitle])
    {
        NSMutableArray * MRA = [NSMutableArray array];
        NSMenuItem * MI;
        while(MI = [[self itemArray] lastObject])
            [self removeItem: MI];
        [NSMenu _menu: self
            listDocumentationAtPath: [[NSUserDefaults standardUserDefaults] stringForKey: iTMDocumentationPathKey] alreadyListed: MRA];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithCoder:
- (id) initWithCoder: (NSCoder *) aDecoder;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Sep 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(self = [super initWithCoder: aDecoder])
    {
        NSMutableArray * MRA = [NSMutableArray array];
        NSMenuItem * MI;
        while(MI = [[self itemArray] lastObject])
            [self removeItem: MI];
        [NSMenu _menu: self listDocumentationAtPath: [[NSUserDefaults standardUserDefaults] stringForKey: iTMDocumentationPathKey] alreadyListed: MRA];
    }
    return self;
}
@end

@implementation NSMenu(iTMDocumentationMenu)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _menu:listDocumentationAtPath:alreadyListed:
+ (void) _menu: (NSMenu *) menu listDocumentationAtPath: (NSString *) path alreadyListed: (NSMutableArray *) alreadyListed;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Sep 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * resolvedPath = [path stringByResolvingSymlinksAndFinderAliasesInPath];
//NSLog(@"resolvedPath: %@", resolvedPath);
    if([[resolvedPath lastPathComponent] isEqualToString: @"CVS"] || [[resolvedPath lastPathComponent] isEqualToString: @"RCS"])
        [alreadyListed addObject: path];
    else if(![alreadyListed containsObject: resolvedPath])
    {
        [alreadyListed addObject: resolvedPath];
        [self _menu: menu listDocumentationFilesAtPath: resolvedPath alreadyListed: alreadyListed];
        [self _menu: menu listDocumentationFoldersAtPath: resolvedPath alreadyListed: alreadyListed];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _menu:listDocumentationFilesAtPath:alreadyListed:
+ (void) _menu: (NSMenu *) menu listDocumentationFilesAtPath: (NSString *) path alreadyListed: (NSMutableArray *) alreadyListed;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Sep 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSFileManager * DFM = [NSFileManager defaultManager];
    BOOL isDirectory = NO;
    path = [path stringByResolvingSymlinksAndFinderAliasesInPath];
    if([DFM fileExistsAtPath: path isDirectory: &isDirectory] && isDirectory)
    {
        NSEnumerator * E = [[DFM directoryContentsAtPath: path] objectEnumerator];
        NSString * P;
        while(P = [E nextObject])
        {
            NSString * fullP = [[path stringByAppendingPathComponent: P] stringByResolvingSymlinksAndFinderAliasesInPath];
            if(![alreadyListed containsObject: fullP])
            {
                if(![DFM fileExistsAtPath: fullP isDirectory: &isDirectory])
                    [alreadyListed addObject: fullP];
                else if(!isDirectory || [[NSWorkspace sharedWorkspace] isFilePackageAtPath: fullP])
                {
                    NSString * LPC = [fullP lastPathComponent];
                    if(![LPC hasPrefix: @"."])
                    {
                        NSMenuItem * MI = [menu addItemWithTitle:
                                    ([[DFM fileAttributesAtPath: fullP traverseLink: YES] fileExtensionHidden]?
                                                [LPC stringByDeletingPathExtension]: LPC)
                            action: @selector(showDocumentation:) keyEquivalent: @""];
                        [MI setTarget: self];
                        [MI setRepresentedObject: fullP];
                    }
                    [alreadyListed addObject: fullP];
                }
            }
        }
    }
    else
    {
        NSLog(@"Non empty directory expected at path: %@", path);    
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _menu:listDocumentationFoldersAtPath:alreadyListed:
+ (void) _menu: (NSMenu *) menu listDocumentationFoldersAtPath: (NSString *) path alreadyListed: (NSMutableArray *) alreadyListed;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Sep 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSFileManager * DFM = [NSFileManager defaultManager];
    BOOL isDirectory = NO;
    path = [path stringByResolvingSymlinksAndFinderAliasesInPath];
    if([DFM fileExistsAtPath: path isDirectory: &isDirectory] && isDirectory)
    {
        NSEnumerator * E = [[DFM directoryContentsAtPath: path] objectEnumerator];
        NSString * P;
        while(P = [E nextObject])
        {
            NSString * fullP = [[path stringByAppendingPathComponent: P] stringByResolvingSymlinksAndFinderAliasesInPath];
            if(![alreadyListed containsObject: fullP])
            {
                if(![DFM fileExistsAtPath: fullP isDirectory: &isDirectory])
                    [alreadyListed addObject: fullP];
                else if(isDirectory)
                {
//NSLog(@"directory");
                    NSString * LPC = [fullP lastPathComponent];
                    if(![LPC hasPrefix: @"."])
                    {
                        LPC = ([[DFM fileAttributesAtPath: fullP traverseLink: YES] fileExtensionHidden]?
                                                    [LPC stringByDeletingPathExtension]: LPC);
                        id submenu = [[[NSMenu allocWithZone: [NSMenu menuZone]] initWithTitle: LPC] autorelease];
                        [self _menu: submenu listDocumentationAtPath: fullP alreadyListed: alreadyListed];
                        if([submenu numberOfItems])
                        {
                            NSMenuItem * MI = [menu addItemWithTitle: LPC action: NULL keyEquivalent: @""];
                            [MI setSubmenu: submenu];
                            [MI setRepresentedObject: fullP];
                        }
                    // [alreadyListed addObject: fullP];// already done
                    }
                }
            }
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showDocumentation:
+ (void) showDocumentation: (id <NSMenuItem>) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Tue Sep 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [sender representedObject];
    if(![[NSWorkspace sharedWorkspace] openFile: path])
    {
        NSBeep();
        NSString * status = [NSString stringWithFormat:
            NSLocalizedStringFromTableInBundle(@"Could not open: %@.", @"Basic", [NSBundle iTMKitBundle], "status format with 1 %@"), path];
        [self postNotificationWithStatus: status];
    }
    return;
}

@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMDocumentationMenu

