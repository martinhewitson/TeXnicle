/*
//  iTMSessionManager.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Fri Nov 30 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import "iTMSessionManager.h"
#import "iTMResourcesController.h"
#import "iTMProjectDocument.h"
#import "NSMenu_iTeXMac.h"
#import "NSBundle_iTeXMac.h"

NSString * const iTMUDRememberSessionsKey = @"iTM Session: Remember";
NSString * const iTMUDLastSessionNameKey = @"iTM Session: Last Name";
NSString * const iTMUDSmartSaveSessionKey = @"iTM Session: Smart Save";

@interface NSDocument(iTMSessionManager)
- (int) currentPhysicalPage;
- (void) setCurrentPhysicalPage: (int) argument;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMSessionManager
/*"Description forthcoming."*/
@implementation iTMSessionManager
static id _iTMSessionManager;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initialize
+ (void) initialize;
/*"Registers some defaults: initialize iTMDefaultsController.
Version History: jlaurens@users.sourceforge.net (07/12/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * lastSessionName = NSLocalizedStringFromTableInBundle(@"Current", @"Sessions",
                [NSBundle bundleForClass: [self class]], "Default Session Name (extension less)");
    while([[lastSessionName pathExtension] length])
        lastSessionName = [lastSessionName stringByDeletingPathExtension];
    lastSessionName = [lastSessionName stringByAppendingPathExtension: @"sTeXMac"];
    [[NSUserDefaults standardUserDefaults] registerDefaults: [NSDictionary dictionaryWithObjectsAndKeys: 
                    [NSNumber numberWithBool: NO], iTMUDRememberSessionsKey,
                    [NSNumber numberWithBool: NO], iTMUDSmartSaveSessionKey,
                    lastSessionName, iTMUDLastSessionNameKey,
                    [NSNumber numberWithBool: YES], @"iTeXMac Shows Logs",
                        nil]];
    [[NSNotificationCenter defaultCenter] addObserver: self
        selector: @selector(applicationDidFinishLaunching:)
            name: NSApplicationDidFinishLaunchingNotification
                object: NSApp];
    [[NSNotificationCenter defaultCenter] addObserver: [self class]
        selector: @selector(applicationWillTerminate:)
            name: NSApplicationWillTerminateNotification
                object: NSApp];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= sharedSessionManager
+ (id) sharedSessionManager;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return _iTMSessionManager? _iTMSessionManager:
                        (_iTMSessionManager = [[self allocWithZone: [NSApp zone]] init]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationDidFinishLaunching:
+ (void) applicationDidFinishLaunching: (NSNotification *) aNotification;
/*"Release the shared controller.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSNotificationCenter defaultCenter] removeObserver: self name: [aNotification name] object: nil];
    {
        NSMenu * mainMenu = [NSApp mainMenu];
        NSMenuItem * MI;
        if(MI = [mainMenu deepItemWithAction: @selector(sessionMenuItem:)])
        {
            NSMenu * submenu = [[NSMenu alloc] initWithTitle: @"Sessions"];
            [[submenu addItemWithTitle: NSLocalizedStringFromTableInBundle(@"Open...", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Open Session Menu Item Title")
                action: @selector(openSession:)
                    keyEquivalent: [NSString string]]
                        setTarget: [self sharedSessionManager]];
            [[submenu addItemWithTitle: NSLocalizedStringFromTableInBundle(@"Save...", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Save Session Menu Item Title")
                action: @selector(saveSession:)
                    keyEquivalent: [NSString string]]
                        setTarget: [self sharedSessionManager]];
            [[submenu addItemWithTitle: NSLocalizedStringFromTableInBundle(@"Change...", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Change Session Menu Item Title")
                action: @selector(changeSession:)
                    keyEquivalent: [NSString string]]
                        setTarget: [self sharedSessionManager]];
            [[submenu addItemWithTitle: NSLocalizedStringFromTableInBundle(@"Remove...", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Remove Session Menu Item Title")
                action: @selector(removeSession:)
                    keyEquivalent: [NSString string]]
                        setTarget: [self sharedSessionManager]];
            [submenu addItem: [NSMenuItem separatorItem]];
            [[submenu addItemWithTitle: NSLocalizedStringFromTableInBundle(@"Automatic", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Remember the current session")
                action: @selector(toggleRememberSession:)
                    keyEquivalent: [NSString string]]
                        setTarget: [self sharedSessionManager]];
            [MI setSubmenu: [submenu autorelease]];
        };
    }
    if([[NSUserDefaults standardUserDefaults] boolForKey: iTMUDRememberSessionsKey])
        [[self sharedSessionManager] openSession: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationWillTerminate:
+ (void) applicationWillTerminate: (NSNotification *) aNotification;
/*"Tries to save the current session.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[NSNotificationCenter defaultCenter] removeObserver: self];
    if([[NSUserDefaults standardUserDefaults] boolForKey: iTMUDRememberSessionsKey])
        [[self sharedSessionManager] saveSession: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= init
- (id) init;
/*"The first session manager created is the shared one. Impossible to create more than one instance.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(_iTMSessionManager)
    {
        if(![self isEqual: _iTMSessionManager])
            [self release];
        return [_iTMSessionManager retain];
    }
    else
    {
        return _iTMSessionManager = [super init];
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= dealloc
- (void) dealloc;
/*"Never dealloc.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self->_SD release];
    self->_SD = nil;
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  documentControllerWillCloseAll:
- (void) documentControllerWillCloseAll: (NSNotification *) aNotification;
/*"Tries to save the current session: the notification is sent by the application delegate
just before the terminate process begins.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([[NSUserDefaults standardUserDefaults] boolForKey: iTMUDRememberSessionsKey])
        [self prepareSessionForSaving];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  documentControllerDidCloseAll:
- (void) documentControllerDidCloseAll: (NSNotification *) aNotification;
/*"Tries to save the current session: the notification is sent by the application delegate
just before the terminate process begins.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([[NSUserDefaults standardUserDefaults] boolForKey: iTMUDRememberSessionsKey])
        [self saveSession];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openSession:
- (void) openSession: (id) irrelevant;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSEnumerator * E = [[[NSFileManager defaultManager] directoryContentsAtPath:
                                        [self sessionsDirectoryPath]] objectEnumerator];
    id file;
    while(file = [E nextObject])
        if([[file pathExtension] isEqualToString: @"sTeXMac"])
        {
            NSArray * regularDocs = nil;
            NSUserDefaults * UD = [NSUserDefaults standardUserDefaults];
            NSString * defaultOpenDirectory = [UD objectForKey: @"NSDefaultOpenDirectory"];
            NSOpenPanel * OP = [NSOpenPanel openPanel];
            [OP setPrompt: NSLocalizedStringFromTableInBundle(@"Open Session", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Open session prompt.")];
            [OP setTitle: NSLocalizedStringFromTableInBundle(@"iTeXMac Sessions", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Open/Save/Alert Session Panel Title")];
    //        [OP setRequiredFileType: @"session"];
            [OP setAllowsMultipleSelection: NO];
            [OP setTreatsFilePackagesAsDirectories: NO];
            [OP setResolvesAliases: YES];
            [OP setExtensionHidden: YES];
    //        [OP setInitialFirstResponder: [[OP contentView] viewWithTag: NSFileHandlingPanelBrowser]]; it is useless
            if(NSOKButton == [OP runModalForDirectory:
                [self sessionsDirectoryPath]
                    file: [[NSUserDefaults standardUserDefaults] stringForKey: iTMUDLastSessionNameKey]
                        types: [NSArray arrayWithObject: @"sTeXMac"]])
            {
                NSString * fileName = [[OP filenames] objectAtIndex: 0];
                if(regularDocs = [NSArray arrayWithContentsOfFile: fileName])
                {
                    NSEnumerator * enumerator = [regularDocs objectEnumerator];
                    NSDictionary * dico;
                    while(dico = [enumerator nextObject])
                        if([dico isKindOfClass: [NSDictionary class]])
                        {
                            NSString * fileName = [dico objectForKey: @"fileName"];
                            if([fileName isKindOfClass: [NSString class]] && [fileName length])
                            {
                                NSNumber * dontDisplay = [dico objectForKey: @"dontDisplay"];
                                id document = [[NSDocumentController sharedDocumentController]
                                    openDocumentWithContentsOfFile: fileName
                                        display: ([dontDisplay respondsToSelector: @selector(boolValue)]?
                                                        ![dontDisplay boolValue]: YES)];
                                if([document respondsToSelector: @selector(setCurrentPhysicalPage:)])
                                {
                                    NSNumber * currentPhysicalPage = [dico objectForKey: @"currentPage"];
                                    [document setCurrentPhysicalPage: ([currentPhysicalPage respondsToSelector: @selector(intValue)]?
                                                                    [currentPhysicalPage intValue]: 0)];
                                }
                                if([document respondsToSelector: @selector(textView)])
                                {
                                    NSTextView * textView = [document textView];
                                    if([textView respondsToSelector: @selector(setSelectedRange:)])
                                    {
                                        NSString * selectedRange = [dico objectForKey: @"selectedRange"];
                                        if([selectedRange isKindOfClass: [NSString class]])
                                        {
                                            [textView setSelectedRange: NSRangeFromString(selectedRange)];
                                            [textView scrollRangeToVisible: [textView selectedRange]];
                                        }
                                    }
                                }
                                if([[document windowControllers] count])
                                {
                                    NSWindow * W = [[[document windowControllers] objectAtIndex: 0] window];
                                    NSString * windowFrame = [dico objectForKey: @"windowFrame"];
                                    if([windowFrame isKindOfClass: [NSString class]])
                                        [W setFrame: NSRectFromString(windowFrame) display: [W isVisible] animate: YES];
                                }
                            }
                        }
                }
                else
                    NSRunCriticalAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Sessions", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Open/Save/Alert Session Panel Title"),
            NSLocalizedStringFromTableInBundle(@"Could not read session at:\n%@", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Reading session problem. 1%@"),
                        nil, nil, nil, fileName);
            }
            [UD setObject: defaultOpenDirectory forKey: @"NSDefaultOpenDirectory"];
            break;
        }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  prepareSessionForSaving
- (void) prepareSessionForSaving;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSMutableArray * regularDocs = [NSMutableArray array];
    NSEnumerator * enumerator = [[[NSDocumentController sharedDocumentController] documents] objectEnumerator];
    id document;
    while(document = [enumerator nextObject])
    {
        if((![document respondsToSelector: @selector(isStrongGeneric)]||![document isStrongGeneric]) &&
                    [[document fileName] length])
        {
            NSMutableDictionary * MD = [NSMutableDictionary dictionary];
            NSArray * WCs = [document windowControllers];
            [MD setObject: [document fileName] forKey: @"fileName"];
            if([WCs count])
            {
                NSWindow * W = [[WCs objectAtIndex: 0] window];
                [MD setObject: NSStringFromRect([W frame]) forKey: @"windowFrame"];
                if([document respondsToSelector: @selector(isStrongGeneric)])// iTMProjectDocuments
                    [MD setObject: [NSNumber numberWithBool: ![W isVisible]] forKey: @"dontDisplay"];
            }
            else if([document respondsToSelector: @selector(isStrongGeneric)])// iTMProjectDocuments
                [MD setObject: [NSNumber numberWithBool: YES] forKey: @"dontDisplay"];
            if([document respondsToSelector: @selector(textView)] &&
                [[document textView] respondsToSelector: @selector(selectedRange)])
                    [MD setObject: NSStringFromRange([[document textView] selectedRange])
                        forKey: @"selectedRange"];
            if([document respondsToSelector: @selector(currentPhysicalPage)])
                [MD setObject: [NSNumber numberWithInt: [document currentPhysicalPage]] forKey: @"currentPage"];
            [regularDocs addObject: MD];
        }
    }
    [self->_SD release];
    self->_SD = [regularDocs copy];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  saveSession
- (void) saveSession;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSUserDefaults * UD = [NSUserDefaults standardUserDefaults];
    if([self->_SD count])
    {
        NSString * defaultOpenDirectory = [UD objectForKey: @"NSDefaultOpenDirectory"];
        NSSavePanel * SP = [NSSavePanel savePanel];
        [SP setPrompt: NSLocalizedStringFromTableInBundle(@"Save Current Session", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Save session prompt.")];
        [SP setTitle: NSLocalizedStringFromTableInBundle(@"iTeXMac Sessions", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Open/Save/Alert Session Panel Title")];
        [SP setRequiredFileType: @"sTeXMac"];
        [SP setTreatsFilePackagesAsDirectories: NO];
        [SP setExtensionHidden: YES];
        [SP setDelegate: self];
        {
            NSButton * CB = [[SP contentView] viewWithTag: NSCancelButton];
            if([CB respondsToSelector: @selector(setTitle:)])
            {
                [CB setTitle: NSLocalizedStringFromTableInBundle(@"Continue", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Save session prompt.")];
            }
        }
        if(NSOKButton == [SP runModalForDirectory:
            [self sessionsDirectoryPath]
                file: [UD stringForKey: iTMUDLastSessionNameKey]])
        {
            NSString * fileName = [SP filename];
            if([self->_SD writeToFile: fileName atomically: YES])
            {
                char type[] = "TEXT";
                char creator[] = "????";
                [[NSFileManager defaultManager] changeFileAttributes:
                    [NSDictionary dictionaryWithObjectsAndKeys:
                            [NSNumber numberWithInt: *(int*) type], NSFileHFSTypeCode,
                            [NSNumber numberWithInt: *(int*) creator], NSFileHFSCreatorCode,
                            [NSNumber numberWithBool: YES], NSFileExtensionHidden,
                            @"iTeXMac Session", @"DocumentType",
                                nil]
                        atPath: fileName];
                [UD setObject: [fileName lastPathComponent]
                        forKey: iTMUDLastSessionNameKey];
            }
            else
                NSRunCriticalAlertPanel(
                    NSLocalizedStringFromTableInBundle(@"iTeXMac Sessions", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Open/Save/Alert Session Panel Title"),
                    NSLocalizedStringFromTableInBundle(@"Could not save session at:\n%@", @"Sessions",
                    [NSBundle bundleForClass: [self class]], "Writing session problem. 1%@"),
                    nil, nil, nil, [SP filename]);
        }
        [UD setObject: defaultOpenDirectory forKey: @"NSDefaultOpenDirectory"];
    }
    else if([UD boolForKey: @"iTeXMac Shows Logs"])
        NSLog(@"No docs to save in the session");
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  saveSession:
- (void) saveSession: (id) irrelevant;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self prepareSessionForSaving];
    [self saveSession];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= removeSession:
- (void) removeSession: (id) irrelevant;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSOpenPanel * OP = [NSOpenPanel openPanel];
    [OP setPrompt: NSLocalizedStringFromTableInBundle(@"Remove Session", @"Sessions",
                [NSBundle bundleForClass: [self class]], "Remove session prompt.")];
    [OP setTitle: NSLocalizedStringFromTableInBundle(@"iTeXMac Sessions", @"Sessions",
                [NSBundle bundleForClass: [self class]], "Open/Save/Alert Session Panel Title")];
//        [OP setRequiredFileType: @"session"];
    [OP setAllowsMultipleSelection: YES];
    [OP setTreatsFilePackagesAsDirectories: NO];
    [OP setExtensionHidden: YES];
    [OP setResolvesAliases: YES];
//        [OP setInitialFirstResponder: [[OP contentView] viewWithTag: NSFileHandlingPanelBrowser]]; it is useless
    if(NSOKButton == [OP runModalForDirectory:
        [self sessionsDirectoryPath]
            file: [[NSUserDefaults standardUserDefaults] stringForKey: iTMUDLastSessionNameKey]
                types: [NSArray arrayWithObject: @"sTeXMac"]])
    {
        NSEnumerator * enumerator = [[OP filenames] objectEnumerator];
        NSString * path;
        while(path = [enumerator nextObject])
        {
            NSString * source = [path stringByDeletingLastPathComponent];
            NSString * filename = [path lastPathComponent];
            if([filename length])
                [[NSWorkspace sharedWorkspace] performFileOperation: NSWorkspaceRecycleOperation
                    source: source
                        destination: [NSString string]
                            files: [NSArray arrayWithObject: filename]
                                tag: nil];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= changeSession:
- (void) changeSession: (id) irrelevant;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self saveSession: self];
    {
        NSEnumerator * enumerator = [[[NSDocumentController sharedDocumentController] documents] objectEnumerator];
        id document;
        while(document = [enumerator nextObject])
            if(![document respondsToSelector: @selector(isStrongGeneric)] || ![document isStrongGeneric])
                [document canCloseDocumentWithDelegate: nil shouldCloseSelector: NULL contextInfo: nil];
    }
    [self openSession: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= toggleRememberSession:
- (void) toggleRememberSession: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSUserDefaults * SUD = [NSUserDefaults standardUserDefaults];
    BOOL old = [SUD boolForKey: iTMUDRememberSessionsKey];
    [SUD setBool: !old forKey: iTMUDRememberSessionsKey];
    [sender setState: ([SUD boolForKey: iTMUDRememberSessionsKey]? NSOnState: NSOffState)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateMenuItem:
- (BOOL) validateMenuItem: (id <NSMenuItem>) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (11/10/2001).
To do list:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    SEL action = [sender action];
    if(action == @selector(toggleRememberSession:))
    {
        [sender setState: ([[NSUserDefaults standardUserDefaults]
                                boolForKey: iTMUDRememberSessionsKey]? NSOnState: NSOffState)];
        return YES;
    }
    else
        return YES;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= panel:userEnteredFilename:confirmed:
- (NSString *) panel: (id) sender userEnteredFilename: (NSString *) filename confirmed: (BOOL) aFlag;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: Does not work: ask cocoa-dev
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(aFlag && ![[NSUserDefaults standardUserDefaults] boolForKey: iTMUDSmartSaveSessionKey])
    {
        NSString * source = [filename stringByDeletingLastPathComponent];
        NSString * filename = [[sender filename] lastPathComponent];
//NSLog
//NSLog(@">>>>>>> sender: %@\nfilename: %@\n[sender filename]: %@", sender, filename, [sender filename]);
        // recycling the previous file, if any
        if([[sender filename] length])
            [[NSWorkspace sharedWorkspace] performFileOperation: NSWorkspaceRecycleOperation
                source: source
                    destination: [NSString string]
                        files: [NSArray arrayWithObject: filename]
                            tag: nil];
    }
    return filename;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= sessionsDirectoryPath
- (NSString *) sessionsDirectoryPath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[NSBundle mainHomeLibraryPath] stringByAppendingPathComponent: @"Sessions"];
    BOOL isDirectory;
    if([[NSFileManager defaultManager] fileExistsAtPath: path isDirectory: &isDirectory])
    {
        static BOOL firstTimeError = YES;
        if(isDirectory)
        {
            return path;
        }
        else if(firstTimeError)
        {
            NSRunCriticalAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Installation Problem",
                            @"General", [NSBundle bundleForClass: [self class]], "Panel Title"),
                NSLocalizedStringFromTableInBundle(@"No file/bad file at:\n %@",
                            @"General", [NSBundle bundleForClass: [self class]], "status info format, 1%@"),
                nil, nil, nil, path);
            firstTimeError = NO;
        }
    }
    else if([[NSFileManager defaultManager] createDirectoryAtPath: path attributes: nil])
    {
        return path;
    }
    else
    {
        static BOOL firstTimeError = YES;
        if(firstTimeError)
        {
            NSRunCriticalAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Installation Problem",
                            @"General", [NSBundle bundleForClass: [self class]], "Panel Title"),
                NSLocalizedStringFromTableInBundle(@"Cannot create directory at path:\n %@",
                            @"General", [NSBundle bundleForClass: [self class]], "status info format, 1%@"),
                nil, nil, nil, path);
            firstTimeError = NO;
        }
    }
    return [NSString string];
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMSessionManager

