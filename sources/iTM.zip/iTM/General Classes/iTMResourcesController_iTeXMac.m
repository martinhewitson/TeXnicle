/*
//  iTMResourcesController_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Fri Oct 12 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import "iTMPathUtilities.h"
#import "iTMResourcesController_iTeXMac.h"
#import "iTMResourcesController(iTMTeXKit).h"
#import "iTMResourcesController(GenericProjects).h"
#import "iTMResourcesController(GeneralProject).h"
#import "NSBundle_iTeXMac.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMResourcesController(iTeXMac)
/*"This object provides access to iTeXMac specific resources, namely generics, templates, macros, colors that resides in different location in the file system.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: Simply implement
"*/
@interface iTMResourcesController(Private)
/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
- (BOOL) completeResourceForDirectoryWrapper: (NSFileWrapper *) aWrapper ressourceKey: (NSString *) aKey;
- (BOOL) completeGeneralResourcesForDirectoryWrapper: (NSFileWrapper *) aWrapper;
/*"Overriden methods"*/
@end

NSString * const iTMRCCachesKey = @"Caches";
NSString * const iTMRCAssistantsKey = @"Assistants";
NSString * const iTMRCKeyBindingsKey = @"Key Bindings";
NSString * const iTMRCScriptsKey = @"Scripts";

NSString * const iTMRCTeXMFDocumentationMenuPathKey = @"TeXMF Documentation Menu.private";
NSString * const iTMRCTeXMFFAQsMenuPathKey = @"TeXMF FAQs Menu.private";


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSString (iTMCompareExtension)

@implementation NSString (iTMCompareExtension)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= compareLastPathComponents:
- (NSComparisonResult) compareLastPathComponents: (NSString *) string;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [[self lastPathComponent] compare: [string lastPathComponent]];
}
@end

@implementation iTMResourcesController(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= _CompleteResourcesDirectoryWrapper:
- (BOOL) _CompleteResourcesForDirectoryWrapper: (NSFileWrapper *) aWrapper;
/*"This method ensures that the receiver contains at least the series of resources the application is designed to have. The aim is to provide a way to recover information in a consistent state after problems, external modifications... This is a one level consistency test: only subdirectories are tested. If they exist, nothing is done. If they do not exist they are created using a bundle resource. So a resources directory can exist with a bad content. This rule does not apply to the "General" directory, for which a content test is made.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: Implement what is announced
"*/
{
    BOOL result;
    NS_DURING;
    result = [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCTemplatesKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCGenericProjectsKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCHiddenGenericProjectsKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCMacrosKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCGeneralKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCCachesKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCAssistantsKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCKeyBindingsKey];
    result = result && [self completeResourceForDirectoryWrapper: aWrapper ressourceKey: iTMRCScriptsKey];
    result = result && [self completeGeneralResourcesForDirectoryWrapper: aWrapper];
    NS_HANDLER
    [NSApp reportException: localException];
    NS_ENDHANDLER;
    return result;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= completeResourceForDirectoryWrapper:ressourceKey:
- (BOOL) completeResourceForDirectoryWrapper: (NSFileWrapper *) aWrapper ressourceKey: (NSString *) aKey;
/*"If there is not a directory wrapper for %{aKey}, one is created by looking in the apllcation main bundle.
Returns YES if some change have been made, no otherwise. No saving operation is performed here. May raise an internal inconsistency exception if the required ressource is not found in the main bundle, or has a wrong type.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: Improve the last case... more user friendly
"*/
{
//NSLog
//NSLog(@"completeResourceForDirectoryWrapper: %@", aKey);
    if([[[aWrapper fileWrappers] allKeys] indexOfObject: aKey] == NSNotFound)
    {
        NSString * path = [[NSBundle mainBundle] pathForResource: aKey ofType: [NSString string]];
//NSLog
//NSLog(@"Bundle path: %@", path);
        if([path length])
        {
            NSFileWrapper * wrapper = [[[NSFileWrapper alloc] initWithPath: path] autorelease];
            if([wrapper isDirectory])
            {
                NSString * P = [[[NSBundle mainHomeLibraryPath]
 stringByAppendingPathComponent: aKey]
                                                                shortestStringByAbbreviatingWithTildeInPath];
                if(NSRunInformationalAlertPanel(
                    NSLocalizedStringFromTableInBundle(@"iTeXMac Support", @"General",
                            [NSBundle bundleForClass: [self class]], "Panel resource problem title"),
                        NSLocalizedStringFromTableInBundle(@"Creating support folder:\n%@", @"General",
                                [NSBundle bundleForClass: [self class]], "new support folder created"),
                            nil,
                                nil,//NSLocalizedStringFromTableInBundle(@"Cancel", "Panel button title"),
                                    nil, P) == NSOKButton)
                {
                    [wrapper setPreferredFilename: aKey];
                    [wrapper setIcon: nil];
                    [aWrapper addFileWrapper: wrapper];
                    return [wrapper writeToFile: [[NSBundle mainHomeLibraryPath]
 stringByAppendingPathComponent: aKey]
                        atomically: YES updateFilenames: YES];
                }
                else
                    return NO;
            }
        }
        else
        {
            NSFileWrapper * wrapper = [[[NSFileWrapper alloc] initDirectoryWithFileWrappers: nil] autorelease];
            [wrapper setPreferredFilename: aKey];
            [wrapper setIcon: nil];
            [aWrapper addFileWrapper: wrapper];
            return [wrapper writeToFile: [[NSBundle mainHomeLibraryPath]
 stringByAppendingPathComponent: aKey]
                        atomically: YES updateFilenames: YES];
        }
        NSRunInformationalAlertPanel(
            NSLocalizedStringFromTableInBundle(@"iTeXMac Support", @"General",
                    [NSBundle bundleForClass: [self class]], "Panel resource problem title"),
            NSLocalizedStringFromTableInBundle(@"Missing bundle resource:\n%@\nPlease reinstall when possible.", @"General",
                    [NSBundle bundleForClass: [self class]], "Writing resource problem"),
            nil, nil, nil, aKey);
        return NO;
    }
    else if([[[aWrapper fileWrappers] objectForKey: aKey] isDirectory])
        return YES;
    else
    {
        NSRunInformationalAlertPanel(
        NSLocalizedStringFromTableInBundle(@"iTeXMac Support", @"General",
                    [NSBundle bundleForClass: [self class]], "Panel resource problem title"),
        NSLocalizedStringFromTableInBundle(@"Expected directory at %@.", @"General",
                    [NSBundle bundleForClass: [self class]], "not a directory. 1 %@"),
        nil, nil, nil, [NSBundle mainHomeGeneralDirectoryPath]);
        return NO;
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= completeGeneralResourcesForDirectoryWrapper:
- (BOOL) completeGeneralResourcesForDirectoryWrapper: (NSFileWrapper *) aWrapper;
/*"Ensures that the "general" directory is consistent. YES if there was a change.
Not a strong algorithm.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: implement
"*/
{
    BOOL result = NO;
    NSFileWrapper * wrapper = [[aWrapper fileWrappers] objectForKey: iTMRCGeneralKey];
    if(!wrapper)
    {
        wrapper = [[[NSFileWrapper alloc] initDirectoryWithFileWrappers: nil] autorelease];
        [wrapper setPreferredFilename: iTMRCGeneralKey];
        [wrapper setIcon: nil];
        [aWrapper addFileWrapper: wrapper];
        result = YES;
    }
    if(wrapper && ![[wrapper fileWrappers] objectForKey: iTMRCVirtualKey])
    {
        NSFileWrapper * FW = [[[NSFileWrapper alloc] initWithPath: [[NSBundle mainBundle] pathForResource: iTMRCVirtualKey
                ofType: nil inDirectory: iTMRCGeneralKey]] autorelease];
        result = YES;
        [FW setPreferredFilename: iTMRCVirtualKey];
        [FW setIcon: nil];
        if(FW)
        {
            [wrapper addFileWrapper: FW];
            result = YES;
        }
        else if(![[NSUserDefaults standardUserDefaults] boolForKey: @"iTMVirtualProjectResourceMissing"])
        {
            NSRunInformationalAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Support", @"General",
                    [NSBundle bundleForClass: [self class]], "Panel resource problem title"),
                NSLocalizedStringFromTableInBundle(@"Missing bundle resource (%@), please reinstall when possible.", @"General",
                    [NSBundle bundleForClass: [self class]], "Resource problem"),
                nil, nil, nil, iTMRCVirtualKey);
            [[NSUserDefaults standardUserDefaults] registerDefaults:
                [NSDictionary dictionaryWithObject: [NSNumber numberWithBool: YES]
                    forKey: @"iTMVirtualProjectResourceMissing"]];
        }
    }
    return result? [wrapper writeToFile: [[NSBundle mainHomeLibraryPath]
 stringByAppendingPathComponent: iTMRCGeneralKey]
                        atomically: YES updateFilenames: YES]: NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= cachesDirectoryPath
- (NSString *) cachesDirectoryPath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSArray * RA = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    return [[([RA count]? [RA objectAtIndex: 0]: [NSBundle mainHomeLibraryPath]
)
        stringByAppendingPathComponent: @"Application Support/iTeXMac/Caches"] stringByStandardizingPath];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= TeXMFFAQsMenuPath
- (NSString *) TeXMFFAQsMenuPath;
/*"Before returning the path, the receivers verifies the consistency of the resources with
#{userResourcesDirectoryWrapper}.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self userResourcesDirectoryWrapper];
    return [[self cachesDirectoryPath] stringByAppendingPathComponent: iTMRCTeXMFFAQsMenuPathKey];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= TeXMFDocumentationMenuPath
- (NSString *) TeXMFDocumentationMenuPath;
/*"Before returning the path, the receivers verifies the consistency of the resources with
#{userResourcesDirectoryWrapper}.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self userResourcesDirectoryWrapper];
    return [[self cachesDirectoryPath] stringByAppendingPathComponent: iTMRCTeXMFDocumentationMenuPathKey];
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMResourcesController(iTeXMac)

