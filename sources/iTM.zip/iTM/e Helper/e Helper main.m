/*
//  e_Helper main.m
//  iTeXMac
//
//  Created by jlaurens on Fri Oct 26 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
//  07/21/2002: better support for non absolute paths and UTF8.
 */


#import <string.h>
#import <stdio.h>
#import <Cocoa/Cocoa.h>

NSString * const iTeXMacKey = @"iTeXMac-2";
#warning DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD the above name!!!

int main(int argc, const char *argv[])
{
    const char * fileName = "";
    const char * lineNumber = "";
    const char * columnNumber = "";
    int i;
    for(i = 1; i < argc; ++i)
    {
        if(!strcmp(argv[i], "-file"))
        {
            if(i<argc)
                fileName = argv[++i];
            else
                goto bail;
        }
        else if (!strcmp(argv[i], "-line"))
        {
            if(i<argc)
                lineNumber = argv[++i];
            else
                goto bail;
        }
        else if (!strcmp(argv[i], "-column"))
        {
            if(i<argc)
                columnNumber = argv[++i];
            else
                goto bail;
        }
        else
            goto bail;
    }
    if(strlen(fileName))
    {
        NSAutoreleasePool * AP = [[NSAutoreleasePool alloc] init];
        // problem because two iTM are launched in PB
[[[NSWorkspace sharedWorkspace] launchedApplications] writeToFile:@"/Users/jlaurens/COUCOU" atomically:YES];
        NSEnumerator * E = [[[NSWorkspace sharedWorkspace] launchedApplications] objectEnumerator];
        NSDictionary * D;
        BOOL isRunning = NO;
        while(D = [E nextObject])
            if([[D objectForKey: @"NSApplicationName"] isEqualToString: iTeXMacKey])
            {
                isRunning = YES;
                break;
            }
        if(!isRunning)
        {
            if([[NSWorkspace sharedWorkspace] launchApplication: iTeXMacKey])
            {
                [NSThread sleepUntilDate: [NSDate dateWithTimeIntervalSinceNow: 2]];
            }
            else
            {
                NSBeep();
                NSLog(@"Sorry, I could not open iTeXMac");
                goto skip;
            }
        }
        NSString * PWD = [[[NSProcessInfo processInfo] environment] objectForKey: @"PWD"];
        NSString * path = [[NSString stringWithUTF8String: fileName] stringByStandardizingPath];
        NSMutableDictionary * MD = [NSMutableDictionary dictionaryWithObjectsAndKeys:
            ([path hasPrefix: @"/"]? path:
                [[PWD stringByAppendingPathComponent: path] stringByStandardizingPath]), @"fileName",
                    nil];
        if(strlen(lineNumber))
            [MD setObject: [NSString stringWithCString: lineNumber] forKey: @"lineNumber"];
        if(strlen(columnNumber))
            [MD setObject: [NSString stringWithCString: columnNumber] forKey: @"columnNumber"];
    
        [[NSDistributedNotificationCenter defaultCenter]
            postNotificationName: @"iTMTextEditorShouldOpenTextFile"
                object: nil
                    userInfo: MD
                        deliverImmediately: YES];
        skip:
        [AP release];
    }
//    printf("iTMTextEditorShouldOpenTextFile distributed notification posted\nfile: <%s>, line: <%s>", fileName, lineNumber);
    return 0;
    bail:
    printf("Usage: %s -file fileName -line lineNumber -column columnNumber", argv[0]);
    return 1;
}
