/*
//  e_Helper main.m
//  iTeXMac
//
//  Created by jlaurens on Fri Oct 26 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
//  07/21/2002: better support for non absolute paths and UTF8.
 */

#import <Foundation/Foundation.h>

int main(int argc, const char *argv[])
{
    NSAutoreleasePool * AP = [[NSAutoreleasePool alloc] init];
    NSString * PWD = [[[NSProcessInfo processInfo] environment] objectForKey: @"PWD"];
    NSMutableArray * MRA = [NSMutableArray array];
    int i;
    for(i = 1; i < argc; ++i)
    {
        const char * fileName = argv[i];
        NSString * path = [[NSString stringWithUTF8String: fileName] stringByStandardizingPath];
        if([path isEqualToString: @"--help"])
        {
            NSLog(@"Usage: %s filename1 ... filenameN", argv[0]);
            NSLog(@"Let iTeXMac read and update the file named filename1 ... filenameN");
            NSLog(@"When not absolute, path are relative to the current directory.");
            NSLog(@"Usage: %s", argv[0]);
            NSLog(@"With no argument, let iTeXMac update all its documents.");
            NSLog(@"Prints this help and exit.");
            NSLog(@"Usage: %s --help", argv[0]);
            NSLog(@"Prints this help and exit.");
            return 0;
            exit;
        }
        if(![path hasPrefix: @"/"])
            path = [[PWD stringByAppendingPathComponent: path] stringByStandardizingPath];
        [MRA addObject: path];
    }
    [[NSDistributedNotificationCenter defaultCenter]
        postNotificationName: @"iTeXMacShouldUpdateDocuments"
            object: nil
                userInfo: [NSDictionary dictionaryWithObject: MRA forKey: @"documents"]
                    deliverImmediately: YES];
    [AP release];
    return 0;
}
