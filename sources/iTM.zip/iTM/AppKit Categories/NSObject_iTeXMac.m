/*
//  NSObject_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Fri May 31 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "NSObject_iTeXMac.h"

@interface NSObject(iTMScripting_Private)
- (NSRange) rangeValue;
- (unsigned) index;
- (unsigned) insertionIndex;
- (unsigned) intValue;
- (NSScriptObjectSpecifier *)startSpecifier;
- (NSScriptObjectSpecifier *)endSpecifier;
- (BOOL)validateUserInterfaceItem:(id <NSValidatedUserInterfaceItem>)anItem;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSObject(iTeXMac)
/*"Description forthcoming."*/
@implementation NSObject(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  evaluatedPosition
- (unsigned) evaluatedPosition;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([self respondsToSelector: @selector(insertionIndex)])
    {
        return [self insertionIndex];
    }
    else if([self respondsToSelector: @selector(index)])
    {
        return [self index];
    }
    else if([self respondsToSelector: @selector(intValue)])
    {
        return [self intValue];
    }
    else
        return NSNotFound;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  evaluatedRange
- (NSRange) evaluatedRange;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([self isKindOfClass: [NSRangeSpecifier class]])
    {
        unsigned start = [[self startSpecifier] evaluatedPosition];
        unsigned end = [[self endSpecifier] evaluatedPosition];
        return NSMakeRange(start, end - start);
    }
    else if([self respondsToSelector: @selector(rangeValue)])
    {
        return [self rangeValue];
    }
    else
        return NSMakeRange(NSNotFound, 0);
}
#if 1
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  target:validateUserInterfaceItem:
+ (BOOL) target: (id) target validateUserInterfaceItem: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * actionString = NSStringFromSelector([sender action]);
    NSString * begin = [[actionString substringWithRange: NSMakeRange(0, 1)] capitalizedString];
    NSString * end = [actionString substringWithRange: NSMakeRange(1, [actionString length] - 1)];
    SEL validatorAction = NSSelectorFromString([NSString stringWithFormat: @"validate%@%@", begin, end]);
    if([target respondsToSelector: validatorAction])
    {
        [target performSelector: validatorAction withObject: sender];
        return ![sender respondsToSelector: @selector(isEnabled)] || [(NSMenuItem *)sender isEnabled];
    }
    else
        return YES;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  validateUserInterfaceItem:
- (BOOL) validateUserInterfaceItem: (id <NSValidatedUserInterfaceItem>) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[self class] target: self validateUserInterfaceItem: sender];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  validateUserInterfaceItem:
+ (BOOL) validateUserInterfaceItem: (id <NSValidatedUserInterfaceItem>) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [self target: self validateUserInterfaceItem: sender];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  validateMenuItem:
- (BOOL) validateMenuItem: (id <NSMenuItem>) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[self class] target: self validateUserInterfaceItem: sender];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  validateMenuItem:
+ (BOOL) validateMenuItem: (id <NSMenuItem>) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [self target: self validateUserInterfaceItem: sender];
}
#endif
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSObject(iTeXMac)

