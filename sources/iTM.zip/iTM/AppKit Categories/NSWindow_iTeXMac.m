/*
//  NSWindow_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Thu Jul 12 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history:
//  * initial content on Thu Jul 12 2001
//      +frameIdentifier
//      +initialize

*/


#import "NSWindow_iTeXMac.h"
#import "iTMSettings.h"

NSString * const iTMFrameSavedWindowKey = @"Saved ";
NSString * const iTMFrameFixedWindowKey = @"Fixed ";
NSString * const iTMFrameCurrentWindowKey = @"Current ";
NSString * const iTMAutosaveModeKeySuffix = @" Autosave Mode";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindow(iTeXMac)
/*"It registers in the default database the position of the window on screen. The volatile registration domain is used. This is useful when the user wants new windows to open at the same position of the current one. Different kinds of windows are dealt with a programmatic identifying key. To use this feature, you simply need to override the #{+frameIdentifier} message to return your own string, and to send the NSWindow class object the #{+observeWindowPosition} message, for example in your #{windowControllerDidLoadNib} message or event better in your #{+initialize} method. This is a class wide manager: you must subclass NSWindow each time you want a different management.

All you have to do is #{+initialize} the iTMWindowsObserver and subclass the #{+frameIdentifier} in your NSWindow subclass. Then you access the #+{frame} for the appropriate window class. It is the frame of the current instance window on screen.
If none the frame size and position is 0.

It replaces the previous iTMWindowManager written by Dirk Holmes. It uses internally the standard user default manager.
It is not the best solution."*/
@implementation NSWindow(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= frameIdentifier
+ (NSString *) frameIdentifier;
/*"Subclasses should override this method. The default implementation returns a 0 length string, and deactivates the 'register current frame' process.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return @"";
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= frame
+ (NSRect) frame;
/*"Subclasses should override this method. The default implementation returns a 0 length string, and deactivates the 'register current frame' process.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return NSRectFromString([[NSUserDefaults standardUserDefaults] stringForKey: [iTMFrameCurrentWindowKey stringByAppendingString: [self frameIdentifier]]]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= frameAutosaveIdentifierForMode:
+ (NSString *) frameAutosaveIdentifierForMode: (iTMWindowFrameAutosaveMode) aMode;
/*"DF
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSString * frameIdentifier = [self frameIdentifier];
    if([frameIdentifier length])
    {
        switch(aMode)
        {
            case iTMWindowFrameSavedMode:
                return [iTMFrameSavedWindowKey stringByAppendingString: frameIdentifier];
            case iTMWindowFrameFixedMode:
                return [iTMFrameFixedWindowKey stringByAppendingString: frameIdentifier];
            case iTMWindowFrameCurrentMode:
                return [iTMFrameCurrentWindowKey stringByAppendingString: frameIdentifier];
        }
    }
    return @"";
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= frameAutosaveModeKey
+ (NSString *) frameAutosaveModeKey;
/*"Subclasses must declare a default value for all the modes.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [NSStringFromClass(self) stringByAppendingString: iTMAutosaveModeKeySuffix];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= shouldBeObserved
+ (BOOL) shouldBeObserved;
/*"Subclasses will return YES.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setFrameFromStandardUserDefaults
- (void) setFrameFromStandardUserDefaults;
/*"Uses the 
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] frame: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), NSStringFromRect([self frame]));
    iTMWindowFrameAutosaveMode mode = [[self settings] integerForKey: [[self class] frameAutosaveModeKey]];
//NSLog(@"-[%@ %@] mode: %i", NSStringFromClass([self class]), NSStringFromSelector(_cmd), mode);
    NSString * identifier = [[self class] frameAutosaveIdentifierForMode: mode];
//NSLog(@"-[%@ %@] identifier: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), identifier);
    [self setFrameUsingName: identifier];
//NSLog(@"-[%@ %@] frame: %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), NSStringFromRect([self frame]));
    return;
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindow(iTeXMac)

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindowController(iTeXMac)
/*"Description Forthcoming."*/
@implementation NSWindowController(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= standardFrameAutosave
- (void) standardFrameAutosave;
/*"Gives a default value, useful for window observer?
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self setWindowFrameAutosaveName: [[[self window] class] frameIdentifier]];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindowController(iTeXMac)

