/*
//  NSFileManager_iTeXMac.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sun June 01 2003.
//  Copyright  © 2003 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import <Foundation/Foundation.h>

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSFileManager(iTeXMac)

@interface NSFileManager(iTeXMac)

/*! 
@method smartCreateDirectoryAtPath:attributes:
@abstract creates a directory and the whole hierarchy if necessary. Returns YES if the file exists
@discussion Description Forthcoming.
@param path is the path where the directory should be created, if the path is not absolute (ie if it does not start with a /, it is appended to the current directory.
@param attributes are the attributes of all the created directories.
@result yorn.
*/
- (BOOL) smartCreateDirectoryAtPath: (NSString *) path attributes: (NSDictionary *) attributes;

/*! 
@method smartCreateFileAtPath:contents:attributes:
@abstract creates a file and the whole hierarchy if necessary. Returns YES if the file is created, No if the file can't be created or is already existing.
@discussion Description Forthcoming.
@param path is the path where the directory should be created, if the path is not absolute (ie if it does not start with a /, it is appended to the current directory.
@param contents is the file contents.
@param attributes are the attributes of all the created directories.
@result yorn.
*/
- (BOOL) smartCreateFileAtPath: (NSString *) path contents: (NSData *) data attributes: (NSDictionary *) attributes;

/*! 
@method smartCreateSymbolicLinkAtPath:pathContent:
@abstract creates a link and the whole hierarchy if necessary. Returns YES if the link is created, no otherwise. If there exists something at path, No is returned.
@discussion Description Forthcoming.
@param path is the path where the directory should be created, if the path is not absolute (ie if it does not start with a /, it is appended to the current directory.
@param otherpath is the target.
@result yorn.
*/
- (BOOL) smartCreateSymbolicLinkAtPath: (NSString *) path pathContent: (NSString *) otherpath;

/*! 
@method isSmartWritableDirectoryAtPath:
@abstract Whether we have a writable directory at path, eventuallt creating it.
@discussion Description Forthcoming.
@param path is the path where the directory should be created, if the path is not absolute (ie if it does not start with a /, it is appended to the current directory.
@result yorn.
*/
- (BOOL) isSmartWritableDirectoryAtPath: (NSString *) path;

@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSFileManager(iTeXMac)
