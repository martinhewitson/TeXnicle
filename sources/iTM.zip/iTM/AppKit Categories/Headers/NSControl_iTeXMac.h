/*
//  NSControl_iTeXMac.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sun Sep 09 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import <Cocoa/Cocoa.h>

#import <Cocoa/Cocoa.h>

#import <Cocoa/Cocoa.h>


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView(Validate)

@interface NSView(Validate)
/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
- (void) validateUserInterfaceItems;
- (BOOL) isValid;
- (void) validateWindowContent;
/*"Overriden methods"*/
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindow(iTeXMac)
@interface NSWindow(Validate)
/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
- (void) validateContent;
/*"Overriden methods"*/
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSControl(iTeXMac)

@interface NSControl(iTeXMac)
/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
/*"Overriden methods"*/
- (BOOL) isValid;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSControl(iTeXMac)

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView(iTeXMacValidate)
