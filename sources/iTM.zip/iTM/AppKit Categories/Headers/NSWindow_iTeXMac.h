/*
//  NSWindow_iTeXMac.h
//NSLog
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Thu Jul 12 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
*/


#import <Cocoa/Cocoa.h>

#import <Cocoa/Cocoa.h>


@class NSString;

typedef enum _iTMWindowFrameAutosaveMode 
{
    iTMWindowFrameFixedMode = 0, //default mode
    iTMWindowFrameSavedMode = 1,
    iTMWindowFrameCurrentMode = 2
} iTMWindowFrameAutosaveMode;

extern NSString * const iTMFrameSavedWindowKey;
extern NSString * const iTMFrameFixedWindowKey;
extern NSString * const iTMFrameCurrentWindowKey;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindow(iTeXMac)

@interface NSWindow(iTeXMac)
/*"Class methods"*/
+ (NSString *) frameIdentifier;
+ (NSRect) frame;
/*"Setters and Getters"*/
+ (NSString *) frameAutosaveIdentifierForMode: (iTMWindowFrameAutosaveMode) aMode; // private
+ (NSString *) frameAutosaveModeKey; // private
+ (BOOL) shouldBeObserved;
- (void) setFrameFromStandardUserDefaults;
/*"Main methods"*/
/*"Overriden methods"*/
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindow(iTeXMac)

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindowController(iTeXMac)

@interface NSWindowController(iTeXMac)
/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
- (void) standardFrameAutosave;
/*"Overriden methods"*/
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSWindowController(iTeXMac)
