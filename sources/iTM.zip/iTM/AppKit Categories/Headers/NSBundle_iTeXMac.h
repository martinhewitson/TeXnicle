/*
//  NSBundle_iTeXMac.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sun Apr 28 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#if 1
#import <Foundation/Foundation.h>

extern NSString * const iTMBGeneral;//used

extern NSString * const iTMRCGeneralKey;


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSBundle(iTeXMac)

@interface NSBundle(iTeXMac)

/*! 
@method iTMKitBundle
@abstract The iTMKit framework bundle.
@discussion The iTMKit framework is the one containing the iTMSettings.
@param domainMask is concerning one of the user, local or network domains.
*/
+ (NSBundle *) iTMKitBundle;

/*! 
@method pathsForApplicationSupportInDomain:
@abstract "Library/Application Support" with the relevant prefixes.
@discussion Description Forthcoming.
@param domainMask is concerning one of the user, local or network domains.
*/
+ (NSArray *) pathsForApplicationSupportInDomain: (NSSearchPathDomainMask) domainMask;

/*! 
@method pathsForITMResourcesInDomain:
@abstract The application support subdirectory named like the receiver's CFBundleName entry in its dictionary.
@discussion Description Forthcoming.
@param domainMask is concerning one of the user, local or network domains..
@result an array of the paths
*/
- (NSArray *) pathsForITMResourcesInDomain: (NSSearchPathDomainMask) domainMask;

/*! 
@method subpathForResource:ofType:inDirectory:
@abstract Path components.
@discussion Basically "subpath/name.ext".
@param name.
@param ext.
@param subpath should be a path relative to one of the domains.
@result the result
*/
- (NSString *) subpathForResource: (NSString *) name ofType: (NSString *) ext inDirectory: (NSString *) subpath;

/*! 
@method mainHomeLibraryPath
@abstract Description Forthcoming.
@discussion Will be deprecated.
@result Cached value
*/
+ (NSString *) mainHomeLibraryPath;

/*! 
@method mainHomeGeneralDirectoryPath
@abstract Description Forthcoming.
@discussion Will be deprecated.
@result Cached value
*/
+ (NSString *) mainHomeGeneralDirectoryPath;

/*! 
@method mainHomeGenericProjectsPath
@abstract Description Forthcoming.
@discussion Will be deprecated.
@result Cached value
*/
+ (NSString *) mainHomeGenericProjectsPath;

/*! 
@method mainHomeHiddenGenericProjectsPath
@abstract Description Forthcoming.
@discussion Will be deprecated.
@result Cached value
*/
+ (NSString *) mainHomeHiddenGenericProjectsPath;

/*! 
@method saveDocumentAsUser:
@abstract Save the document in the user domain.
@discussion Description Forthcoming.
@param Irrelevant.
*/
- (NSArray *) subpathsForResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath domain: (NSSearchPathDomainMask) domainMask;
- (NSArray *) subpathsForBuiltInResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath;
- (NSArray *) pathsForITMResourcesInDomain: (NSSearchPathDomainMask) domainMask;
- (NSEnumerator *) pathEnumeratorForITMResource: (NSString *) name ofType: (NSString *) ext inDirectory: (NSString *) subpath inDomain: (NSSearchPathDomainMask) domainMask;
- (NSString *) smartPathForITMDirectoryResources: (NSString *) subpath inDomain: (NSSearchPathDomainMask) domainMask;
- (NSString *) firstPathForITMResource: (NSString *) name ofType: (NSString *) ext inDirectory: (NSString *) subpath;
- (NSString *) temporaryDirectoryPath;
- (NSString *) defaultWritableFolderPath;
/*"Setters and Getters"*/
/*"Main methods"*/
/*"Overriden methods"*/
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSBundle(iTeXMac)
#else
#import <Cocoa/Cocoa.h>

extern NSString * const iTMApplicationSupport;
extern NSString * const iTMBGeneral;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSBundle(iTeXMac)

@interface NSBundle(iTeXMac)
/*"Class methods"*/
- (NSArray *) subpathsForResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath domain: (NSSearchPathDomainMask) domainMask;
- (NSArray *) subpathsForUserResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath;
- (NSArray *) subpathsForLocalResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath;
- (NSArray *) subpathsForNetworkResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath;
- (NSArray *) subpathsForBuiltInResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath;
- (NSString *) pathForResourcesInDomain: (NSSearchPathDomainMask) domainMask;
- (NSString *) pathForDomainResource: (NSString *) name ofType: (NSString *) ext;
- (NSString *) pathForResource: (NSString *) name ofType: (NSString *) ext inDomain: (NSSearchPathDomainMask) domainMask;
- (NSString *) pathForResource: (NSString *) name ofType: (NSString *) ext inDomain: (NSSearchPathDomainMask) domainMask create: (BOOL) yorn;
- (NSString *) pathForResourcesInDomain: (NSSearchPathDomainMask) domainMask create: (BOOL) yorn;
/*"Setters and Getters"*/
/*"Main methods"*/
/*"Overriden methods"*/
@end
#endif
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSBundle(iTeXMac)
