/*
//  NSView_iTeXMac.h
//  TBR Tutorial
//
//  Created by jlaurens@users.sourceforge.net on Wed Jun 27 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
*/

#import <Cocoa/Cocoa.h>

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView_iTeXMac

@interface NSView(iTeXMac)
/*"Class methods"*/
+ (int) grabKeyMask;
+ (int) zoomInKeyMask;
+ (int) zoomOutKeyMask;
/*"Setters and Getters"*/
- (NSPoint) frameCenter;
- (void) setFrameCenter: (NSPoint) aCenter;
- (NSPoint) boundsCenter;
- (void) setBoundsCenter: (NSPoint) aCenter;
- (float) visibleArea;
- (NSComparisonResult) compareArea: (NSView *) otherView;
/*"Main methods"*/
- (NSPoint) absolutePointWithPoint: (NSPoint) aPoint;
- (NSPoint) pointWithAbsolutePoint: (NSPoint) aRelativePoint;
- (NSSize) absoluteSizeWithSize: (NSSize) aSize;
- (NSSize) sizeWithAbsoluteSize: (NSSize) aSize;
- (NSRect) absoluteRectWithRect: (NSRect) aRect;
- (NSRect) rectWithAbsoluteRect: (NSRect) aRect;
- (void) centerBoundsOrigin;
- (void) centerInSuperview;
- (void) removeSubviewsWithoutNeedingDisplay;
/*"Overriden methods"*/
@end

@interface NSView(iTeXMacScrolling)
- (void) scrollPageLeft: (id) sender;
- (void) scrollPageRight: (id) sender;
- (void) scrollCharacterLeft: (id) sender;
- (void) scrollCharacterRight: (id) sender;
- (void) scrollLineUp: (id) sender;
- (void) scrollLineDown: (id) sender;
- (void) scrollPageUp: (id) sender;
- (void) scrollPageDown: (id) sender;
@end

@interface NSView(iTeXMacShadow)
+ (NSImage *) shadowImage;
- (void) drawShadowForRect: (NSRect) R distance: (float) distance offset: (NSPoint) offset fraction: (float) delta;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView_iTeXMac
