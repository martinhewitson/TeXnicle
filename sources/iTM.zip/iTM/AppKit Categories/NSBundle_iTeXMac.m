/*
//  NSBundle_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sun Apr 28 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import <sys/stat.h>
#import <AppKit/AppKit.h>
#import "NSBundle_iTeXMac.h"
#import "NSFileManager_iTeXMac.h"
#import "iTMPathUtilities.h"

NSString * const iTMBGeneral = @"General";
NSString * const iTMKitBundleIdentifier = @"comp.text.tex.iTMKit";
NSString * const iTMBApplicationSupport = @"Application Support";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSBundle(iTeXMac)
/*"Description forthcoming."*/
@implementation NSBundle(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMKitBundle
+ (NSBundle *) iTMKitBundle;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [NSBundle bundleWithIdentifier: iTMKitBundleIdentifier];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  subpathsForResourcesOfType:inDirectory:domain:
- (NSArray *) subpathsForResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath domain: (NSSearchPathDomainMask) domainMask;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [[[[self pathsForITMResourcesInDomain: domainMask] lastObject] stringByAppendingPathComponent: subpath] stringByResolvingSymlinksAndFinderAliasesInPath];
    id result = [[NSFileManager defaultManager] subpathsAtPath: path];
    if([ext length])
    {
        NSEnumerator * E = [result objectEnumerator];
        result = [NSMutableArray array];
        while(path = [E nextObject])
            if([[[path pathExtension] lowercaseString] isEqualToString: ext])
                [result addObject: path];
    }
    return [result sortedArrayUsingSelector: @selector(compare:)];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  subpathForResource:ofType:inDirectory:
- (NSString *) subpathForResource: (NSString *) name ofType: (NSString *) ext inDirectory: (NSString *) subpath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    subpath = [subpath length]? [subpath stringByAppendingPathComponent: name]: name;
    if([subpath length] && [ext length])
        subpath = [subpath stringByAppendingPathExtension: ext];
    return subpath? subpath: [NSString string];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  pathEnumeratorForITMResource:ofType:inDirectory:inDomain:
- (NSEnumerator *) pathEnumeratorForITMResource: (NSString *) name ofType: (NSString *) ext inDirectory: (NSString *) subpath inDomain: (NSSearchPathDomainMask) domainMask;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSEnumerator * E = [[self pathsForITMResourcesInDomain: domainMask] objectEnumerator];
    NSMutableArray * MRA = [NSMutableArray array];
    NSString * suffix = [self subpathForResource: name ofType: ext inDirectory: subpath];
    NSString * P;
    while(P = [E nextObject])
    {
        NSString * path = [[P stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath];
        if([[NSFileManager defaultManager] fileExistsAtPath: path])
            [MRA addObject: path];
    }
    if(domainMask & iTMBuiltInDomainMask)
    {
        NSString * path = [self pathForResource: [suffix lastPathComponent] ofType: nil inDirectory: [suffix stringByDeletingLastPathComponent]];
        if([path length])
            [MRA addObject: path];
    }
    return [MRA objectEnumerator];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  firstPathForITMResource:ofType:inDirectory:
- (NSString *) firstPathForITMResource: (NSString *) name ofType: (NSString *) ext inDirectory: (NSString *) subpath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSEnumerator * E = [[self pathsForITMResourcesInDomain: NSAllDomainsMask] objectEnumerator];
    NSString * P;
    NSString * suffix = [self subpathForResource: name ofType: ext inDirectory: subpath];
    while(P = [E nextObject])
    {
        NSString * path = [[P stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath];
        if([[NSFileManager defaultManager] fileExistsAtPath: path])
            return path;
    }
    return [self pathForResource: name ofType: ext
        inDirectory: [[iTMBApplicationSupport stringByAppendingPathComponent: [[[NSBundle mainBundle] infoDictionary] objectForKey: (NSString *) kCFBundleNameKey]] stringByAppendingPathComponent: subpath]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  pathForBuiltInITMResource:ofType:inDirectory:
- (NSString *) pathForBuiltInITMResource: (NSString *) name ofType: (NSString *) ext inDirectory: (NSString *) subpath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSEnumerator * E = [[self pathsForITMResourcesInDomain: NSAllDomainsMask] objectEnumerator];
    NSString * P;
    NSString * suffix = [self subpathForResource: name ofType: ext inDirectory: subpath];
    while(P = [E nextObject])
    {
        NSString * path = [[P stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath];
        if([[NSFileManager defaultManager] fileExistsAtPath: path])
            return path;
    }
    return [self pathForResource: name ofType: ext
        inDirectory: [[iTMBApplicationSupport stringByAppendingPathComponent: [[[NSBundle mainBundle] infoDictionary] objectForKey: (NSString *) kCFBundleNameKey]] stringByAppendingPathComponent: subpath]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  smartPathForITMDirectoryResources:inDomain:
- (NSString *) smartPathForITMDirectoryResources: (NSString *) subpath inDomain: (NSSearchPathDomainMask) domainMask;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(!subpath)
        subpath = [NSString string];
    NSString * path = [[[[[[self class] pathsForApplicationSupportInDomain: domainMask] lastObject]
                stringByAppendingPathComponent: [[[NSBundle mainBundle] infoDictionary] objectForKey: (NSString *) kCFBundleNameKey]]
                    stringByAppendingPathComponent: subpath]
                        stringByResolvingSymlinksAndFinderAliasesInPath];
    return [[NSFileManager defaultManager] smartCreateDirectoryAtPath: path attributes: nil]? path: [NSString string];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  subpathsForBuiltInResourcesOfType:inDirectory:
- (NSArray *) subpathsForBuiltInResourcesOfType: (NSString *) ext inDirectory: (NSString *) subpath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [self pathForResource: subpath ofType: nil];
    id result = [[NSFileManager defaultManager] subpathsAtPath: path];
    if([ext length])
    {
        NSEnumerator * E = [result objectEnumerator];
        result = [NSMutableArray array];
        while(path = [E nextObject])
            if([[[path pathExtension] lowercaseString] isEqualToString: ext])
                [result addObject: path];
    }
    return [result sortedArrayUsingSelector: @selector(compare:)];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  pathsForApplicationSupportInDomain:
+ (NSArray *) pathsForApplicationSupportInDomain: (NSSearchPathDomainMask) domainMask;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSMutableArray * MRA = [NSMutableArray array];
    NSString * suffix = iTMBApplicationSupport;
    if(domainMask&NSUserDomainMask)
        [MRA addObject: [[[NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) lastObject]
            stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath]];
    if(domainMask&NSLocalDomainMask)
        [MRA addObject: [[[NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSLocalDomainMask, YES) lastObject]
            stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath]];
    if(domainMask&NSNetworkDomainMask)
        [MRA addObject: [[[NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSNetworkDomainMask, YES) lastObject]
            stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath]];
    if(domainMask&NSSystemDomainMask)
        [MRA addObject: [[[NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSSystemDomainMask, YES) lastObject]
            stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath]];
    return [[MRA copy] autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  pathsForITMResourcesInDomain:
- (NSArray *) pathsForITMResourcesInDomain: (NSSearchPathDomainMask) domainMask;
/*"Description forthcoming. Does not check for existence.
Returns a subarray of
~/Library/Application\ Support/iTeXMac
/Library/Application\ Support/iTeXMac
/Network/Library/Application\ Support/iTeXMac
/System/Library/Application\ Support/iTeXMac
according to the flags given in argument
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSEnumerator * E = [[[self class] pathsForApplicationSupportInDomain: domainMask] objectEnumerator];
    NSMutableArray * MRA = [NSMutableArray array];
    NSString * P;
    NSString * suffix = [[[NSBundle mainBundle] infoDictionary] objectForKey: (NSString *) kCFBundleNameKey];
    while(P = [E nextObject])
        [MRA addObject: [[P stringByAppendingPathComponent: suffix] stringByResolvingSymlinksAndFinderAliasesInPath]];
    return [[MRA copy] autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  temporaryDirectoryPath
- (NSString *) temporaryDirectoryPath;
/*"Description forthcoming. Does not check for existence.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [NSTemporaryDirectory() stringByAppendingPathComponent: [self bundleIdentifier]];
    BOOL isDirectory = NO;
    if(![[NSFileManager defaultManager] fileExistsAtPath: path])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath: path attributes: nil];
    }
    if([[NSFileManager defaultManager] fileExistsAtPath: path isDirectory: &isDirectory] && isDirectory)
        return path;
    else
    {
        NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
        NSLog(@"Directory expected at %@...", path);
        return NSTemporaryDirectory();
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  defaultWritableFolderPath
- (NSString *) defaultWritableFolderPath;
/*"As side effect, the folder is created, if needed.
Version History: jlaurens@users.sourceforge.net 
- 1: 09/02/2001
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSFileManager * FM = [NSFileManager defaultManager];
    NSString * CDP = [FM currentDirectoryPath];
    [FM changeCurrentDirectoryPath: NSTemporaryDirectory()];
    BOOL isDirectory = NO;
    if(![FM fileExistsAtPath: [self bundleIdentifier] isDirectory: &isDirectory])
    {
        [FM createDirectoryAtPath: [self bundleIdentifier]
            attributes: [NSDictionary dictionaryWithObject: [NSNumber numberWithInt: S_IRWXU|S_IRWXG|S_IRWXO] forKey: NSFilePosixPermissions]];
    }
    if([FM changeCurrentDirectoryPath: [self bundleIdentifier]])
    {
        if(![FM fileExistsAtPath: NSUserName() isDirectory: &isDirectory])
        {
            [FM createDirectoryAtPath: NSUserName()
                attributes: [NSDictionary dictionaryWithObject: [NSNumber numberWithInt: S_IRWXU] forKey: NSFilePosixPermissions]];
        }
    }
    [FM changeCurrentDirectoryPath: CDP];
    NSString * result = [[NSTemporaryDirectory() stringByAppendingPathComponent: [self bundleIdentifier]] stringByAppendingPathComponent: NSUserName()];
    return [FM fileExistsAtPath: result isDirectory: &isDirectory] && isDirectory? result : @"";
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= mainHomeLibraryPath
+ (NSString *) mainHomeLibraryPath;
/*"Returns a cached version of ~/Library/Application\ Support/Main Bundle Name.
Version history: jlaurens@users.sourceforge.net
- 1.3: 09/10/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSString * S = nil;
    return S? S: (S = [[[[NSHomeDirectory() stringByAppendingPathComponent: [[@"Library" stringByAppendingPathComponent: iTMBApplicationSupport]
        stringByAppendingPathComponent: [[[self mainBundle] infoDictionary] objectForKey: @"CFBundleName"]]]
                                            stringByStandardizingPath] stringByResolvingSymlinksInPath] retain]);
}

NSString * const iTMRCGenericProjectsKey = @"Generic Projects";
NSString * const iTMRCHiddenGenericProjectsKey = @"Hidden Generic Projects";
NSString * const iTMRCGeneralKey = @"General";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= mainHomeGenericProjectsPath
+ (NSString *) mainHomeGenericProjectsPath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    static NSString * S = nil;
    return S? S: (S = [[[[[NSBundle mainHomeLibraryPath] stringByAppendingPathComponent: iTMRCGenericProjectsKey] stringByStandardizingPath] stringByResolvingSymlinksInPath] retain]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= mainHomeGeneralDirectoryPath
+ (NSString *) mainHomeGeneralDirectoryPath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    static NSString * S = nil;
    return S? S: (S = [[[[[NSBundle mainHomeLibraryPath] stringByAppendingPathComponent: iTMRCGeneralKey] stringByStandardizingPath] stringByResolvingSymlinksInPath] retain]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= mainHomeHiddenGenericProjectsPath
+ (NSString *) mainHomeHiddenGenericProjectsPath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    static NSString * S = nil;
    return S? S: (S = [[[[[NSBundle mainHomeLibraryPath] stringByAppendingPathComponent: iTMRCHiddenGenericProjectsKey] stringByStandardizingPath] stringByResolvingSymlinksInPath] retain]);
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  NSBundle(iTeXMac)
