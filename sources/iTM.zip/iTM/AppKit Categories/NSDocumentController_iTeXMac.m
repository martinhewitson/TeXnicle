/*
//  NSDocumentController_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sat Dec 22 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import "NSDocumentController_iTeXMac.h"


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSDocumentController(iTeXMac)
/*"Description forthcoming."*/
@implementation NSDocumentController(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  saveAllDocumentsWithDelegate:didSaveSelector:contextInfo:
- (void) saveAllDocumentsWithDelegate: (id) delegate didSaveAllSelector: (SEL) action contextInfo: (void *) contextInfo;
/*"Call back must have the following signature:
- (void) documentController: (id) DC didSaveAll: (BOOL) flag contextInfo: (void *) contextInfo;
Version History: jlaurens@users.sourceforge.net (12/07/2001)
- < 1.1: 03/10/2002
To Do List: to be improved... to allow different signature
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self saveAllDocuments: self];
    BOOL resultFlag = YES;
    NSMethodSignature * myMS = [self methodSignatureForSelector:
                                    @selector(_fakeDocumentController:didSaveAll:contextInfo:)];
    if([myMS isEqual: [delegate methodSignatureForSelector: action]])
    {
        NSInvocation * I = [NSInvocation invocationWithMethodSignature: myMS];
        [I setSelector: action];
        [I setTarget: delegate];
        [I setArgument: &self atIndex: 2];
        [I setArgument: &resultFlag atIndex: 3];
        [I setArgument: &contextInfo atIndex: 4];
        [I invoke];
    }
    else
    {
	NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
        NSLog(@"Bad method signature in saveAllDocumentsWithDelegate...");
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _fakeDocumentController:didSaveAll:contextInfo:
- (void) _fakeDocumentController: (id) DC didSaveAll: (BOOL) flag contextInfo: (void *) contextInfo;
/*"Call back must have the following signature:
- (void) documentController: (if) DC didSaveAll: (BOOL) flag contextInfo: (void *) contextInfo;
Version History: jlaurens@users.sourceforge.net (12/07/2001)
- < 1.1: 03/10/2002
To Do List: to be improved...
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= openDocumentWithContentsOfFile:display:useHelperIfNeeded:
- (id) openDocumentWithContentsOfFile: (NSString *) fileName display: (BOOL) display useHelperIfNeeded: (BOOL) aFlag;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [self openDocumentWithContentsOfFile: fileName display: display];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= projectForFileName:
- (id) projectForFileName: (NSString *) aFileName;
/*"Looks for a project concerning aFileName among the current open projects, regardless the extensions.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: look also in the projects stored.
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return nil;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSDocumentController(iTeXMac)

