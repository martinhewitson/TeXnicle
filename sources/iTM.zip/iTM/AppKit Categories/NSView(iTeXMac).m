/*
//  NSView(iTeXMac).m
//  TBR Tutorial
//
//  Created by jlaurens@users.sourceforge.net on Wed Jun 27 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: jlaurens@users.sourceforge.net(format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import "NSView(iTeXMac).h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView(iTeXMac)
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
@implementation NSView(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= frameCenter
- (NSPoint) frameCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return NSMakePoint(NSMidX([self frame]),NSMidY([self frame]));
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setFrameCenter:
- (void) setFrameCenter: (NSPoint) aCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSSize size = [self frame].size;
    int width = size.width/2;
    int height = size.height/2;
    [self setFrame: NSInsetRect(NSMakeRect(aCenter.x, aCenter.y,0,0), -width, -height)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= relativeFrameCenter
- (NSPoint) relativeFrameCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [self absolutePointWithPoint: [self frameCenter]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= absolutePointWithPoint:
- (NSPoint) absolutePointWithPoint: (NSPoint) aPoint;
/*"Given aPoint in the receiver coordinate system, it returns a point in a normalized coordinate system, with the origin at the lower left corner, height and width equal 1. For example to top right corner has normalized coordinates (1, 1).
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    float width = [self bounds].size.width > 0? [self bounds].size.width: 0.0001;
    float height = [self bounds].size.height > 0? [self bounds].size.height: 0.0001;
    NSPoint result;
    result = NSMakePoint((aPoint.x-[self bounds].origin.x)/width, (aPoint.y-[self bounds].origin.y)/height);
    return result;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= pointWithAbsolutePoint:
- (NSPoint) pointWithAbsolutePoint: (NSPoint) aPoint;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return NSMakePoint([self bounds].origin.x+aPoint.x*[self bounds].size.width,
                            [self bounds].origin.y+aPoint.y*[self bounds].size.height);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= boundsCenter
- (NSPoint) boundsCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return NSMakePoint(NSMidX([self bounds]), NSMidY([self bounds]));
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setBoundsCenter:
- (void) setBoundsCenter: (NSPoint) aCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSSize size = [self bounds].size;
    int width = size.width/2;
    int height = size.height/2;
    [self setBounds: NSInsetRect(NSMakeRect(aCenter.x, aCenter.y, 0, 0), -width, -height)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= centerBoundsOrigin
- (void) centerBoundsOrigin;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self setBoundsOrigin: [self boundsCenter]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= centerInSuperview
- (void) centerInSuperview;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if([self superview])
        [self setFrameCenter: [[self superview] boundsCenter]];
    return;
}
@end

@implementation NSView(iTeXMacScrolling)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageLeft:
- (void) scrollPageLeft: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR,-2*VR.size.width/5, 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageRight:
- (void) scrollPageRight: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 2*VR.size.width/5, 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageUp:
- (void) scrollPageUp: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    #warning flipped ?
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0,2*VR.size.height/5), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageDown:
- (void) scrollPageDown: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    #warning flipped ?
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0, -2*VR.size.height/5), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollCharacterLeft:
- (void) scrollCharacterLeft: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR,-MAX(VR.size.width/50, 16), 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollCharacterRight:
- (void) scrollCharacterRight: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, MAX(VR.size.width/50, 16), 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollLineUp:
- (void) scrollLineUp: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0, MAX(16, VR.size.height/50)), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollLineDown:
- (void) scrollLineDown: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0, -MAX(16, VR.size.height/50)), [self frame])];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView(iTeXMac)

