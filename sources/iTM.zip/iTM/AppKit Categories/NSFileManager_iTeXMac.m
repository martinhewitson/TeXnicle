/*
//  NSFileManager_iTeXMac.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sun June 01 2003.
//  Copyright  © 2003 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import <AppKit/AppKit.h>
#import "NSFileManager_iTeXMac.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSFileManager(iTeXMac)
/*"Description Forthcoming."*/
@interface NSFileManager(PRIVATE)
- (BOOL) _smartCreateDirectoryAtPath: (NSString *) path attributes: (NSDictionary *) attributes seed: (NSFileWrapper *) son;
@end

@implementation NSFileManager(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  isSmartWritableDirectoryAtPath:
- (BOOL) isSmartWritableDirectoryAtPath: (NSString *) path;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 06/01/03
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(![path isAbsolutePath])
        path = [[self currentDirectoryPath] stringByAppendingPathComponent: path];
    path = [path stringByStandardizingPath];
    BOOL isDirectory;
    if([self fileExistsAtPath: path isDirectory: &isDirectory])
    {
        return isDirectory && [self isWritableFileAtPath: path];
    }
    else
    {
        NSString * newPath = [path stringByDeletingLastPathComponent];
        return ([newPath length]<[path length]) && [self isSmartWritableDirectoryAtPath: newPath];
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  smartCreateDirectoryAtPath:attributes:
- (BOOL) smartCreateDirectoryAtPath: (NSString *) path attributes: (NSDictionary *) attributes;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 06/01/03
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(![path isAbsolutePath])
        path = [[self currentDirectoryPath] stringByAppendingPathComponent: path];
    path = [path stringByStandardizingPath];
    NSFileWrapper * son = nil;
    BOOL isDirectory;
    oneMoreTime:
    if([self fileExistsAtPath: path isDirectory: &isDirectory])
    {
        return isDirectory && (!son
                    || [son writeToFile: [path stringByAppendingPathComponent: [son preferredFilename]]
                                atomically: YES updateFilenames: NO]);
    }
    else
    {
        if(son)
        {
            NSFileWrapper * newSon = [[[NSFileWrapper alloc] initDirectoryWithFileWrappers: nil] autorelease];
            [newSon addFileWrapper: son];
            son = newSon;
        }
        else
            son = [[[NSFileWrapper alloc] initDirectoryWithFileWrappers: nil] autorelease];
        [son setPreferredFilename: [path lastPathComponent]];
        if(attributes)
            [son setFileAttributes: attributes];
        NSString * newPath = [path stringByDeletingLastPathComponent];
        if([newPath length]<[path length])
        {
            path = newPath;
            goto oneMoreTime;
        }
        else
            return NO;
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  smartCreateFileAtPath:contents:attributes:
- (BOOL) smartCreateFileAtPath: (NSString *) path contents: (NSData *) data attributes: (NSDictionary *) attributes;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 06/01/03
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(![path isAbsolutePath])
        path = [[self currentDirectoryPath] stringByAppendingPathComponent: path];
    path = [path stringByStandardizingPath];
    if([self fileExistsAtPath: path])
    {
        return NO;
    }
    else
    {
        NSFileWrapper * son = [[[NSFileWrapper alloc] initRegularFileWithContents: data] autorelease];
        [son setPreferredFilename: [path lastPathComponent]];
        if(attributes)
            [son setFileAttributes: attributes];
        return [self _smartCreateDirectoryAtPath: [path stringByDeletingLastPathComponent]
                            attributes: attributes seed: son];
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  smartCreateSymbolicLinkAtPath:pathContent:
- (BOOL) smartCreateSymbolicLinkAtPath: (NSString *) path pathContent: (NSString *) otherpath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 06/01/03
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(![path isAbsolutePath])
        path = [[self currentDirectoryPath] stringByAppendingPathComponent: path];
    path = [path stringByStandardizingPath];
    if([self fileExistsAtPath: path])
        return NO;
    else
    {
        NSFileWrapper * son = [[[NSFileWrapper alloc] initSymbolicLinkWithDestination: path] autorelease];
        [son setPreferredFilename: [path lastPathComponent]];
        return [self _smartCreateDirectoryAtPath: [path stringByDeletingLastPathComponent]
                            attributes: nil seed: son];
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _smartCreateDirectoryAtPath:attributes:seed:
- (BOOL) _smartCreateDirectoryAtPath: (NSString *) path attributes: (NSDictionary *) attributes seed: (NSFileWrapper *) son;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 06/01/03
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(![path isAbsolutePath])
        path = [[self currentDirectoryPath] stringByAppendingPathComponent: path];
    path = [path stringByStandardizingPath];
    BOOL isDirectory;
    oneMoreTime:
    if([self fileExistsAtPath: path isDirectory: &isDirectory])
    {
        return isDirectory && (!son
                    || [son writeToFile: [path stringByAppendingPathComponent: [son preferredFilename]]
                                atomically: YES updateFilenames: NO]);
    }
    else
    {
        if(son)
        {
            NSFileWrapper * newSon = [[[NSFileWrapper alloc] initDirectoryWithFileWrappers: nil] autorelease];
            [newSon addFileWrapper: son];
            son = newSon;
        }
        else
            son = [[[NSFileWrapper alloc] initDirectoryWithFileWrappers: nil] autorelease];
        [son setPreferredFilename: [path lastPathComponent]];
        if(attributes)
            [son setFileAttributes: attributes];
        NSString * newPath = [path stringByDeletingLastPathComponent];
        if([newPath length]<[path length])
        {
            path = newPath;
            goto oneMoreTime;
        }
        else
            return NO;
    }
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSFileManager(iTeXMac)
