/*
//  NSButton_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Fri Dec 13 2002.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "NSButton_iTeXMac.h"


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSButton(iTeXMac)
/*"Description forthcoming."*/
@implementation NSButton(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= button
+ (id) button;
/*"Private use only. Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[[self alloc] initWithFrame: NSMakeRect(0,0,32,32)] autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  fixImageNamed:inBundle:
- (void) fixImageNamed: (NSString *) name inBundle: (NSBundle *) B;
/*"If the image is found, .
Version History: jlaurens@users.sourceforge.net
- 1.3: 13/12/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [B pathForImageResource: name];
    NSImage * I = nil;
    if(![path length] || !(I = [[[NSImage allocWithZone: [self zone]] initWithContentsOfFile: path] autorelease]))
        NSLog(@"-[%@ %@] 0x%x error: Could not find a QuestionMark image, PLEASE report BUG iTM02103",
            NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    else
    {
//NSLog(@"INFO: image path : %@", path);
        [self setImage: I];
        [self setImagePosition: NSImageOnly];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  fixImageNamed:
- (void) fixImageNamed: (NSString *) name;
/*"This one calls the above method with the receiver's bundle as second argument.
Version History: jlaurens@users.sourceforge.net
- 1.3: 13/12/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self fixImageNamed: (NSString *) name inBundle: [NSBundle bundleForClass: [self class]]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  fixImage
- (void) fixImage;
/*"This one calls the above method with the receiver's bundle as second argument.
Version History: jlaurens@users.sourceforge.net
- 1.3: 13/12/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self fixImageNamed: NSStringFromClass([self class])];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSButton(iTeXMac)

