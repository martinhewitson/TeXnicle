/*
//  NSControl_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sun Sep 09 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import "NSControl_iTeXMac.h"


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSControl(iTeXMac)
/*"Description forthcoming."*/
@implementation NSControl(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  isValid
- (BOOL) isValid;
/*"Called by validateUserInterfaceItems (NSView). The validator is the object responding to the action, either the target of the receiver of an object in the responder chain (or the window delegate). The standard validating process is extended. Assuming the action of the receiver is #{fooAction:}, and the target responds to #{validateFooAction:} this message is sent to validate the receiver. If the target does not respond to #{validateFooAction}, then it is asked for #{validateUserInterfaceItem:} as usual.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * actionString = NSStringFromSelector([self action]);
    if([actionString length]>0)
    {
        id <NSObject, NSUserInterfaceValidations> validator =
            [NSApp targetForAction: [self action] to: [self target] from: self];
        if(validator? validator:
            (validator = [NSApp targetForAction: [self action] to: [[self window] delegate] from: self]))
        {
            NSString * begin = [[actionString substringWithRange: NSMakeRange(0, 1)] capitalizedString];
            NSString * end = [actionString substringWithRange: NSMakeRange(1, [actionString length] - 1)];
            SEL validatorAction = NSSelectorFromString([@"validate" stringByAppendingString:
                                                                        [begin stringByAppendingString: end]]);
            if([validator respondsToSelector: validatorAction])
                [validator performSelector: validatorAction withObject: self];
            else if([validator respondsToSelector: @selector(validateUserInterfaceItem:)])
                [self setEnabled: [validator validateUserInterfaceItem: self]];
            else 
                [self setEnabled: YES];
        }
        else
            [self setEnabled: YES];
    }
    else if([self isKindOfClass: [NSPopUpButton class]])
    {
        [self setEnabled: ([(NSPopUpButton *)self numberOfItems]>0)];
    }
    else if([self isKindOfClass: [NSTextField class]])
    {
        [self setEnabled: YES];
    }
    else 
        [self setEnabled: NO];
    return YES;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSControl(iTeXMacValidate)

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSView(iTeXMacValidate)
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
@implementation NSView(Validate)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateUserInterfaceItems
- (void) validateUserInterfaceItems;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(![self isValid]) [[self subviews] makeObjectsPerformSelector: _cmd];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  isValid
- (BOOL) isValid;
/*"Called by validateUserInterfaceItems (NSView). The default implementation returns NO, which causes the view to forward the #{validateUserInterfaceItems} message to its subviews.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateWindowContent
- (void) validateWindowContent;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[self window] validateContent];
    return;
}
@end

@implementation NSWindow(Validate)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateContent
- (void) validateContent;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[self contentView] validateUserInterfaceItems];
    return;
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSView(Validate)

