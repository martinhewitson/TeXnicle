/*
//  NSResponder_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Tue Nov 27 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "NSResponder_iTeXMac.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSResponder(iTeXMac)  

@interface NSResponder(iTeXMacPrivate)
/*"Designated initializer and... Private use only."*/
+ (id) responderForWindow: (NSWindow *) aWindow;
+ (BOOL) responder: (NSResponder*) aResponder hasAmongNextResponders: (NSResponder*) anotherResponder;
- (BOOL) insertInResponderChainAfter: (NSResponder*) responder;
- (void) windowWillClose: (NSNotification *) notification;
@end

@implementation NSResponder(iTeXMac)
/*"The purpose is to insert a new responder in the responder chain to observe and catch some messages or respond to them.
This allows to split code in logically different units and it is an alternative to subclass.
When we improve an object with further methods, we can either add a new responder or subclass an existing one.
Both methods may be used.

As suggested by apple‚Ñ¢ in the NSView documentation, we can insert responders after the main window content view
or after the window delegate.

To Richard, in terms of performance, this is by no means a performance lost, but any object oriented program
does loose performance. As a counterpart, its efficiency gain can be great, both for the programmer and the user.

There might be a bug/memory leak when the window is closed but not released (as for iTeXMac project windows).
Better design is needed."*/
//=-=-=-=-=-=-=-=-=-=-=  installResponderForWindow:
+ (void) installResponderForWindow: (NSWindow *) aWindow;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    id responder = [[self alloc] init];
    if([responder insertInResponderChainAfter: [aWindow contentView]])
    {
        [[NSNotificationCenter defaultCenter] addObserver: responder
            selector: @selector(responderWindowWillClose:)
                name: NSWindowWillCloseNotification
                    object: aWindow];
    }
    
    return;
}
//=-=-=-=-=-=-=-=-=-=-=  responderForWindow:
+ (id) responderForWindow: (NSWindow *) aWindow;
/*"Scans the responder chain after aWindow's content view, if there is already a NSResponder
of class [self class] that will be able to send an apropriate Notification for example, or respond to appropriate messages.
If it is not the case, we create such an object.

Note that only the 100 first objects in the chain are investigated. Beware of loops."*/
{
    NSResponder * responder = [aWindow contentView];
    id nextResponder;
    int max = 100;
    int index = 0;
    while((nextResponder = [responder nextResponder]) &&
                    [nextResponder isKindOfClass: [NSResponder class]] &&
                                index < max)
        if([nextResponder isKindOfClass: [self class]])
            return nextResponder;
        else
            responder = nextResponder;
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=  responder:hasAmongNextResponders:
+ (BOOL) responder: (NSResponder*) aResponder hasAmongNextResponders: (NSResponder *) anotherResponder;
/*"We should not insert in the responder chain starting from aResponder, an object that is already in it.
It would remove some previously registered responders and would cause unexpected effects."*/
{
    NSResponder * nextResponder = [aResponder nextResponder];
    if(!anotherResponder)
        return YES;
    else if(!nextResponder)
        return NO;
    else if([nextResponder isEqual: anotherResponder])
        return YES;
    else
        // the answer is NO if either nextResponder==nil or
        // "responder" does not match any subsequent responder
        return [self responder: nextResponder hasAmongNextResponders: anotherResponder];
}
//=-=-=-=-=-=-=-=-=-=-=-=-= responderWindowWillClose:
- (void) responderWindowWillClose: (NSNotification *) aNotification;
/*"The receiver just send the #{autorelease} message to itself."*/
{
    [[NSNotificationCenter defaultCenter] removeObserver: self name: nil object: nil];
    [self autorelease];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=  insertInResponderChainAfter:
- (BOOL) insertInResponderChainAfter: (NSResponder *) aResponder;
/*"Inserts the receiver in the responder chain just after aResponder, if it is not already there."*/
{
    // we must preserve the existing chain
//    if(![iTMFlagsChangedResponder responder: responder hasAmongNextResponders: self])
    if(![NSResponder responder: aResponder hasAmongNextResponders: self])
    {
        [self setNextResponder: [aResponder nextResponder]];
        [aResponder setNextResponder: self];
        return YES;
    }
    else
        return NO;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSResponder(iTeXMac)  
