/*
//  NSView_iTeXMac.m
//  TBR Tutorial
//
//  Created by jlaurens@users.sourceforge.net on Wed Jun 27 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: jlaurens@users.sourceforge.net(format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/


#import "NSView_iTeXMac.h"
#import "NSBundle_iTeXMac.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView(iTeXMac)
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
@implementation NSView(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  grabKeyMask
+ (int) grabKeyMask;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSCommandKeyMask;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  zoomInKeyMask
+ (int) zoomInKeyMask;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSShiftKeyMask;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  zoomOutKeyMask
+ (int) zoomOutKeyMask;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSAlternateKeyMask;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= frameCenter
- (NSPoint) frameCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSMakePoint(NSMidX([self frame]), NSMidY([self frame]));
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setFrameCenter:
- (void) setFrameCenter: (NSPoint) aCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSSize size = [self frame].size;
    aCenter.x -= size.width/2;
    aCenter.y -= size.height/2;
    [self setFrameOrigin: aCenter];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= relativeFrameCenter
- (NSPoint) relativeFrameCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [self absolutePointWithPoint: [self frameCenter]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= absolutePointWithPoint:
- (NSPoint) absolutePointWithPoint: (NSPoint) aPoint;
/*"Given aPoint in the receiver coordinate system, it returns a point in a normalized coordinate system, with the origin at the lower left corner, height and width equal 1. For example to top right corner has normalized coordinates (1, 1).
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    float width = [self bounds].size.width != 0? [self bounds].size.width: 0.0001;
    float height = [self bounds].size.height != 0? [self bounds].size.height: 0.0001;
    NSPoint result;
    result = NSMakePoint((aPoint.x-[self bounds].origin.x)/width, (aPoint.y-[self bounds].origin.y)/height);
    return result;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= pointWithAbsolutePoint:
- (NSPoint) pointWithAbsolutePoint: (NSPoint) aPoint;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSMakePoint([self bounds].origin.x+aPoint.x*[self bounds].size.width,
                            [self bounds].origin.y+aPoint.y*[self bounds].size.height);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= absoluteSizeWithSize:
- (NSSize) absoluteSizeWithSize: (NSSize) aSize;
/*"Given aPoint in the receiver coordinate system, it returns a point in a normalized coordinate system, with the origin at the lower left corner, height and width equal 1. For example to top right corner has normalized coordinates (1, 1).
Version history: jlaurens@users.sourceforge.net
- 1.3: 07/17/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    float width = [self bounds].size.width != 0? [self bounds].size.width: 0.0001;
    float height = [self bounds].size.height != 0? [self bounds].size.height: 0.0001;
    NSSize result;
    result = NSMakeSize(aSize.width/width, aSize.height/height);
    return result;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= sizeWithAbsoluteSize:
- (NSSize) sizeWithAbsoluteSize: (NSSize) aSize;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 07/17/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSMakeSize(aSize.width*[self bounds].size.width, aSize.height*[self bounds].size.height);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= absoluteSizeWithSize:
- (NSRect) absoluteRectWithRect: (NSRect) aRect;
/*"Given aPoint in the receiver coordinate system, it returns a point in a normalized coordinate system, with the origin at the lower left corner, height and width equal 1. For example to top right corner has normalized coordinates (1, 1).
Version history: jlaurens@users.sourceforge.net
- 1.3: 07/17/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    float width = [self bounds].size.width != 0? [self bounds].size.width: 0.0001;
    float height = [self bounds].size.height != 0? [self bounds].size.height: 0.0001;
    NSRect result;
    result = NSMakeRect((aRect.origin.x-[self bounds].origin.x)/width, (aRect.origin.y-[self bounds].origin.y)/height,
        aRect.size.width/width, aRect.size.height/height);
    return result;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= rectWithAbsoluteRect:
- (NSRect) rectWithAbsoluteRect: (NSRect) aRect;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: 07/17/2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSMakeRect([self bounds].origin.x+aRect.origin.x*[self bounds].size.width, [self bounds].origin.y+aRect.origin.y*[self bounds].size.height,
                            aRect.size.width*[self bounds].size.width, aRect.size.height*[self bounds].size.height);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= boundsCenter
- (NSPoint) boundsCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSMakePoint(NSMidX([self bounds]), NSMidY([self bounds]));
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setBoundsCenter:
- (void) setBoundsCenter: (NSPoint) aCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSSize size = [self bounds].size;
    aCenter.x -= size.width/2;
    aCenter.y -= size.height/2;
    [self setBoundsOrigin: aCenter];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= centerBoundsOrigin
- (void) centerBoundsOrigin;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self setBoundsOrigin: [self boundsCenter]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= centerInSuperview
- (void) centerInSuperview;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//NSLog(NSStringFromRect([[self superview] bounds]));
    if([self superview])
        [self setFrameCenter: [[self superview] boundsCenter]];
//NSLog(NSStringFromRect([self frame]));
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= removeSubviewsWithoutNeedingDisplay
- (void) removeSubviewsWithoutNeedingDisplay;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSEnumerator * E = [[self subviews] objectEnumerator];
    NSView * V;
    while(V = [E nextObject])
        [V removeFromSuperviewWithoutNeedingDisplay];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= visibleArea
- (float) visibleArea;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [self visibleRect];
    return VR.size.width * VR.size.height;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= compareArea:
- (NSComparisonResult) compareArea: (NSView *) otherView;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSAssert(!otherView || [otherView isKindOfClass: [NSView class]], @"Unexpected  rhs");
    float lhs = [self visibleArea];
    float rhs = [otherView visibleArea];
    if(lhs>rhs)
        return NSOrderedDescending;
    else if(lhs<rhs)
        return NSOrderedAscending;
    else 
        return NSOrderedSame;
}
@end

@implementation NSView(iTeXMacScrolling)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageLeft:
- (void) scrollPageLeft: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR,-2*VR.size.width/5, 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageRight:
- (void) scrollPageRight: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 2*VR.size.width/5, 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageUp:
- (void) scrollPageUp: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    #warning flipped ?
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0,2*VR.size.height/5), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollPageDown:
- (void) scrollPageDown: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    #warning flipped ?
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0, -2*VR.size.height/5), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollCharacterLeft:
- (void) scrollCharacterLeft: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR,-MAX(VR.size.width/50, 16), 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollCharacterRight:
- (void) scrollCharacterRight: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, MAX(VR.size.width/50, 16), 0), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollLineUp:
- (void) scrollLineUp: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0, MAX(16, VR.size.height/50)), [self frame])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= scrollLineDown:
- (void) scrollLineDown: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSRect VR = [[self enclosingScrollView] documentVisibleRect];
    [[[self enclosingScrollView] documentView] scrollRectToVisible: NSIntersectionRect(NSOffsetRect(VR, 0, -MAX(16, VR.size.height/50)), [self frame])];
    return;
}
@end

@implementation NSView(iTeXMacShadow)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= shadowImage
+ (NSImage *) shadowImage;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSImage * I;
    if(!I)
        I = [[NSImage allocWithZone: [self zone]] initWithContentsOfFile: [[NSBundle iTMKitBundle] pathForImageResource: @"iTMShadow"]];
    return [[I copy] autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= drawShadowForRect:distance:offset:fraction:
- (void) drawShadowForRect: (NSRect) R distance: (float) distance offset: (NSPoint) offset fraction: (float) delta;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 2.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//NSLog(@"R = %@", NSStringFromRect(R));
//NSLog(@"distance = %f", distance);
offset = NSZeroPoint;
[NSBezierPath strokeRect: R];
#if 0
    float pixelH = MAX(1, abs([self convertSize: NSMakeSize(1, distance) fromView: nil].height));
    distance = MAX(3*pixelH, MIN(distance, 8*pixelH));
#endif
    [[NSGraphicsContext currentContext] saveGraphicsState];
    NSImage * I = [[self class] shadowImage];
    if(!I) return;
    NSSize S = [I size];
    NSRect fromRect = NSZeroRect;
    NSRect destRect = NSZeroRect;
    float halfW = S.width / 2;
    float halfH = S.height / 2;
    #if 0
    R = NSIntegralRect(NSOffsetRect(NSInsetRect(R, -distance, -distance), -offset.x, -offset.y));
    distance = nearbyint(distance);
    #else
    NSBezierPath * BP = [NSBezierPath bezierPathWithRect: R];
    R = NSOffsetRect(NSInsetRect(R, -distance, -distance), -offset.x, -offset.y);
    [BP appendBezierPath: [[NSBezierPath bezierPathWithRect: R] bezierPathByReversingPath]];
    [BP setWindingRule: NSNonZeroWindingRule];
    [BP addClip];
    #endif
    //////// center
    destRect.origin.x = NSMinX(R);
    destRect.origin.y = NSMinY(R);
    destRect.size.width = distance;
    destRect.size.height = distance;
    fromRect.origin.x = 0;
    fromRect.origin.y = 0;
    fromRect.size = S;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// center
    destRect.origin.x = NSMinX(R) + distance;
    destRect.origin.y = NSMinY(R) + distance;
    destRect.size.width = NSWidth(R) - 2 * distance;
    destRect.size.height = NSHeight(R) - 2 * distance;
    fromRect.origin.x = halfW;
    fromRect.origin.y = halfH;
    fromRect.size.width = 1;
    fromRect.size.height = 1;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// bottom left
    destRect.origin.x = NSMinX(R);
    destRect.origin.y = NSMinY(R);
    destRect.size.width = distance;
    destRect.size.height = distance;
    fromRect.origin.x = 0;
    fromRect.origin.y = 0;
    fromRect.size.width = halfW;
    fromRect.size.height = halfH;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// bottom
    destRect.origin.x = NSMaxX(destRect);
//    destRect.origin.y = NSMinY(R);
    destRect.size.width = NSWidth(R) - 2 * distance;
//    destRect.size.height = distance;
    fromRect.origin.x = halfW;
//    fromRect.origin.y = 0;
    fromRect.size.width = 1;
//    fromRect.size.height = halfH;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// bottom right
    destRect.origin.x = NSMaxX(destRect);
//    destRect.origin.y = NSMinY(R);
    destRect.size.width = distance;
//    destRect.size.height = distance;
//    fromRect.origin.x = halfW;
//    fromRect.origin.y = 0;
    fromRect.size.width = halfW;
//    fromRect.size.height = halfH;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// right
//    destRect.origin.x = NSMaxX(R) - distance;
    destRect.origin.y = NSMaxY(destRect);
//    destRect.size.width = distance;
    destRect.size.height = NSHeight(R) - 2 * distance;
//    fromRect.origin.x = halfW;
    fromRect.origin.y = halfH;
//    fromRect.size.width = halfW;
    fromRect.size.height = 1;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// top right
//    destRect.origin.x = NSMaxX(destRect) - distance;
    destRect.origin.y = NSMaxY(destRect);
//    destRect.size.width = distance;
    destRect.size.height = distance;
//    fromRect.origin.x = halfW;
//    fromRect.origin.y = halfH;
//    fromRect.size.width = halfW;
    fromRect.size.height = halfH;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    ////// top
    destRect.origin.x = NSMinX(R) + distance;
//    destRect.origin.y = NSMaxY(destRect) - distance;
    destRect.size.width = NSWidth(R) - 2 * distance;
//    destRect.size.height = distance;
//    fromRect.origin.x = halfW;
//    fromRect.origin.y = halfH;
    fromRect.size.width = 1;
//    fromRect.size.height = haffH;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// top left
    destRect.origin.x = NSMinX(R);
//    destRect.origin.y = NSMaxY(destRect) - distance;
    destRect.size.width = distance;
//    destRect.size.height = distance;
    fromRect.origin.x = 0;
//    fromRect.origin.y = halfH;
    fromRect.size.width = halfW;
//    fromRect.size.height = haffH;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];
    //////// left
//    destRect.origin.x = NSMinX(R);
    destRect.origin.y = NSMinY(R) + distance;
//    destRect.size.width = distance;
    destRect.size.height = NSHeight(R) - 2 * distance;
    fromRect.origin.x = 0;
//    fromRect.origin.y = halfH;
//    fromRect.size.width = halfW;
    fromRect.size.height = 1;
    [I drawInRect: destRect fromRect: fromRect operation: NSCompositeSourceOver fraction: delta];

    [[NSGraphicsContext currentContext] restoreGraphicsState];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= NSView(iTeXMac)

