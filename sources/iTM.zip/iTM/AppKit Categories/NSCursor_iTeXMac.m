/*
//  NSCursor_iTeXMac.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Thu Jan 23 2003.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "NSCursor_iTeXMac.h"
#import "NSBundle_iTeXMac.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSCursor(iTeXMac)
/*"Description forthcoming."*/
@implementation NSCursor(iTeXMac)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  fingerCursor
+ (NSCursor *) fingerCursor;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Thu Jan 23 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSCursor * cursor = nil;
    if(!cursor)
    {
        NSString * path = [[NSBundle iTMKitBundle] pathForImageResource: @"iTMFingerCursor"];
        if(path)
            cursor = [[NSCursor allocWithZone: [self zone]] initWithImage: 
                    [[NSImage allocWithZone: [self zone]] initWithContentsOfFile: path]
                        hotSpot: NSMakePoint(6.5, 2)];
        else
        {
            NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
            NSLog(@"Could not create hand cursor...");
            cursor = [[NSCursor arrowCursor] retain];
        }
    }
    return cursor;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  handCursor
+ (NSCursor *) handCursor;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Thu Jan 23 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSCursor * cursor = nil;
    if(!cursor)
    {
        NSString * path = [[NSBundle iTMKitBundle] pathForImageResource: @"iTMHandCursor"];
        if(path)
            cursor = [[NSCursor allocWithZone: [self zone]] initWithImage: 
                    [[NSImage allocWithZone: [self zone]] initWithContentsOfFile: path]
                        hotSpot: NSMakePoint(7, 7)];
        else
        {
            NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
            NSLog(@"Could not create hand cursor...");
            cursor = [[NSCursor arrowCursor] retain];
        }
    }
    return cursor;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  zoomInCursor
+ (NSCursor *) zoomInCursor;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Thu Jan 23 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSCursor * cursor = nil;
    if(!cursor)
    {
        NSString * path = [[NSBundle iTMKitBundle] pathForImageResource: @"iTMZoomInCursor"];
        if(path)
            cursor = [[NSCursor allocWithZone: [self zone]] initWithImage: 
                    [[NSImage allocWithZone: [self zone]] initWithContentsOfFile: path]
                        hotSpot: NSMakePoint(7, 7)];
        else
        {
            NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
            NSLog(@"Could not create zoom in cursor...");
            cursor = [[NSCursor arrowCursor] retain];
        }
    }
    return cursor;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  zoomOutCursor
+ (NSCursor *) zoomOutCursor;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Thu Jan 23 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSCursor * cursor = nil;
    if(!cursor)
    {
        NSString * path = [[NSBundle iTMKitBundle] pathForImageResource: @"iTMZoomOutCursor"];
        if(path)
            cursor = [[NSCursor allocWithZone: [self zone]] initWithImage: 
                    [[NSImage allocWithZone: [self zone]] initWithContentsOfFile: path]
                        hotSpot: NSMakePoint(7, 7)];
        else
        {
            NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
            NSLog(@"Could not create zoom in cursor...");
            cursor = [[NSCursor arrowCursor] retain];
        }
    }
    return cursor;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  crossHairCursor
+ (NSCursor *) crossHairCursor;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Thu Jan 23 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSCursor * cursor = nil;
    if(!cursor)
    {
        NSString * path = [[NSBundle iTMKitBundle] pathForImageResource: @"iTMCrossHair"];
        if(path)
            cursor = [[NSCursor allocWithZone: [self zone]] initWithImage: 
                    [[NSImage allocWithZone: [self zone]] initWithContentsOfFile: path]
                        hotSpot: NSMakePoint(7, 7)];
        else
        {
            NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
            NSLog(@"Could not create hand cursor...");
            cursor = [[NSCursor arrowCursor] retain];
        }
    }
    return cursor;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  horizontalResizeCursor
+ (NSCursor *) horizontalResizeCursor;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Thu Jan 23 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSCursor * cursor = nil;
    if(!cursor)
    {
        NSImage * I = [[[NSImage alloc] initWithSize: NSMakeSize(16, 16)] autorelease];
        NS_DURING
        [I lockFocus];
        [[NSColor blackColor] set];
        NSBezierPath * BP = [NSBezierPath bezierPath];
        [BP moveToPoint: NSMakePoint(0, 7.5)];
        [BP relativeLineToPoint: NSMakePoint(3.5, -3)];
        [BP relativeLineToPoint: NSMakePoint(0, 6)];
        [BP relativeLineToPoint: NSMakePoint(-3.5, -3)];
        [BP closePath];
        [BP moveToPoint: NSMakePoint(15, 7.5)];
        [BP relativeLineToPoint: NSMakePoint(-3.5, 3)];
        [BP relativeLineToPoint: NSMakePoint(0, -6)];
        [BP relativeLineToPoint: NSMakePoint(3.5, 3)];
        [BP closePath];
        [BP fill];
        [NSBezierPath setDefaultLineWidth: 1.5];
        [NSBezierPath strokeLineFromPoint: NSMakePoint(1, 7.5) toPoint: NSMakePoint(5.5, 7.5)];
        [NSBezierPath strokeLineFromPoint: NSMakePoint(14, 7.5) toPoint: NSMakePoint(9.5, 7.5)];
        [NSBezierPath strokeLineFromPoint: NSMakePoint(7.5, 1.5) toPoint: NSMakePoint(7.5, 14.5)];
        [I unlockFocus];
        cursor = [[NSCursor allocWithZone: [self zone]] initWithImage: I
                        hotSpot: NSMakePoint(7.5, 7.5)];
        NS_HANDLER
        cursor = [[NSCursor arrowCursor] retain];
	NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
	NSLog(@"EXCEPTION CATCHED: %@", [localException reason]);
        NS_ENDHANDLER
    }
    return cursor;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  verticalResizeCursor
+ (NSCursor *) verticalResizeCursor;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Thu Jan 23 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    static NSCursor * cursor = nil;
    if(!cursor)
    {
        NSImage * I = [[[NSImage alloc] initWithSize: NSMakeSize(16, 16)] autorelease];
        NS_DURING
        [I lockFocus];
        [[NSColor blackColor] set];
        NSBezierPath * BP = [NSBezierPath bezierPath];
        [BP moveToPoint: NSMakePoint(7.5, 0)];
        [BP relativeLineToPoint: NSMakePoint(-3, 3.5)];
        [BP relativeLineToPoint: NSMakePoint(6, 0)];
        [BP relativeLineToPoint: NSMakePoint(-3, -3.5)];
        [BP closePath];
        [BP moveToPoint: NSMakePoint(7.5, 15)];
        [BP relativeLineToPoint: NSMakePoint(3, -3.5)];
        [BP relativeLineToPoint: NSMakePoint(-6, 0)];
        [BP relativeLineToPoint: NSMakePoint(3, 3.5)];
        [BP closePath];
        [BP fill];
        [NSBezierPath setDefaultLineWidth: 1.5];
        [NSBezierPath strokeLineFromPoint: NSMakePoint(7.5, 1) toPoint: NSMakePoint(7.5, 5.5)];
        [NSBezierPath strokeLineFromPoint: NSMakePoint(7.5, 14) toPoint: NSMakePoint(7.5, 9.5)];
        [NSBezierPath strokeLineFromPoint: NSMakePoint(1.5, 7.5) toPoint: NSMakePoint(14.5, 7.5)];
        [I unlockFocus];
        cursor = [[NSCursor allocWithZone: [self zone]] initWithImage: I
                        hotSpot: NSMakePoint(7.5, 7.5)];
        NS_HANDLER
        cursor = [[NSCursor arrowCursor] retain];
	NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
	NSLog(@"EXCEPTION CATCHED: %@", [localException reason]);
        NS_ENDHANDLER
    }
    return cursor;
}

@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSCursor(iTeXMac)

