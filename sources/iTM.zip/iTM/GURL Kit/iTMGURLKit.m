/*
//  iTMGURLKit.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Wed Jul 09 2003.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMGURLKit.h"


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMGURLKit
/*"Description forthcoming."*/
@implementation iTMGURLScriptCommand
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performDefaultImplementation
- (id) performDefaultImplementation;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Wed Jul 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return nil;
}
@end

@implementation iTMSrcSpecialURLHandle
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initialize
+ (void) initialize;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Wed Jul 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self registerURLHandleClass: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  canInitWithURL:
+ (BOOL) canInitWithURL: (NSURL *) anURL;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Wed Jul 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[anURL scheme] isEqualToString: @"src-special"];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  cachedHandleForURL:
+ (NSURLHandle *) cachedHandleForURL: (NSURL *) anURL;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Wed Jul 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithURL:cached:
- (id) initWithURL: (NSURL *) anURL cached: (BOOL) willCache;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Wed Jul 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [super initWithURL: anURL cached: willCache];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  propertyForKey:
- (id) propertyForKey: (NSString *) propertyKey;  // Must be overridden by subclasses
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Wed Jul 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  writeData:
- (BOOL) writeData: (NSData *) data; // Must be overridden by subclasses; returns success or failure
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Wed Jul 09 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NO;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMGURLKit

