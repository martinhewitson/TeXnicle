#import <Cocoa/Cocoa.h>

@interface iTMCompileDescriptor : NSWindowController
{
    IBOutlet id absoluteCheck;
    IBOutlet id baseCombo;
    IBOutlet id chooseEnvironment;
    IBOutlet id chooseTranslate;
    IBOutlet id DVICheck;
    IBOutlet id engineCombo;
    IBOutlet id formatCombo;
    IBOutlet id interactionPopUp;
    IBOutlet id MLCheck;
    IBOutlet id PSCheck;
    IBOutlet id rootField;
    IBOutlet id translateMatrix;
}
- (IBAction)absoluteChecked:(id)sender;
- (IBAction)baseChosen:(id)sender;
- (IBAction)chooseBase:(id)sender;
- (IBAction)chooseEngine:(id)sender;
- (IBAction)chooseFormat:(id)sender;
- (IBAction)chooseRoot:(id)sender;
- (IBAction)chooseTranslate:(id)sender;
- (IBAction)DVIChecked:(id)sender;
- (IBAction)engineChosen:(id)sender;
- (IBAction)formatChosen:(id)sender;
- (IBAction)interactionChosen:(id)sender;
- (IBAction)MLChecked:(id)sender;
- (IBAction)PSChecked:(id)sender;
- (IBAction)translateChosen:(id)sender;
@end
