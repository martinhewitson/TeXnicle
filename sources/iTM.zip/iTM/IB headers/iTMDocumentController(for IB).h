// for IB only
@interface iTMDocumentController : NSDocumentController
{
    IBOutlet id newDocumentAssistantPanel;
    IBOutlet id openAccessoryView;
    IBOutlet id newFileTypePopUp;
    IBOutlet id openFileTypePopUp;
    IBOutlet id openStringEncodingPopUp;
}
- (IBAction) newDocumentOK: (id)sender;
- (IBAction) newDocumentCancel: (id) sender;
- (IBAction) newFileTypeChosen: (id)sender;
- (IBAction) openFileTypeChosen: (id)sender;
- (IBAction) openStringEncodingChosen: (id)sender;
@end
