// IB use only

@interface iTMTerminalController: NSWindowController
{
@private
    IBOutlet id input;
    IBOutlet id output;
}
- (IBAction) performInput: (id) sender;
@end
