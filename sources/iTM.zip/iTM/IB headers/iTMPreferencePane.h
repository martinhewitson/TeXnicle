#import <Cocoa/Cocoa.h>

@interface iTMTeXInputPrefPane : iTMPreferencePane
{
}
- (IBAction)macroTabAnchorFieldEdited:(id)sender;
- (IBAction)spacesFieldEdited:(id)sender;
- (IBAction)toggleContinuousCheckSpelling:(id)sender;
- (IBAction)toggleMatchDelimiter:(id)sender;
- (IBAction)togglePreserveIndentation:(id)sender;
- (IBAction)toggleSmartInsert:(id)sender;
- (IBAction)toggleSmartInsertDelete:(id)sender;
- (IBAction)toggleUseSpacesAsTabs:(id)sender;
- (IBAction)toggleWatchText:(id)sender;
@end
