// IB use only
@interface FirstResponder(Navigation)
- (void) displayForwardPage: (id) sender;
- (void) displayBackPage: (id) sender;
- (void) displayFirstPage: (id) sender;
- (void) displayLastPage: (id) sender;
- (void) displayPreviousPage: (id) sender;
- (void) displayNextPage: (id) sender;
- (void) displayPreviousPreviousPage: (id) sender;
- (void) displayNextNextPage: (id) sender;
@end
