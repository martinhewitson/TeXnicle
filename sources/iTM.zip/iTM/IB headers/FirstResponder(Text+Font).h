// IB use only
// these commands are specific to a format
@interface FirstResponder(TextFinding)
- (void) textBold: (id) sender;
- (void) textItalic: (id) sender;
- (void) textUnderline: (id) sender;
- (void) textAlignLeft: (id) sender;
- (void) textAlignCenter: (id) sender;
- (void) textAlignRight: (id) sender;
- (void) textAlignJustified: (id) sender;
@end
#if 0
- (void) text: (id) sender;
- (void) text: (id) sender;
- (void) text: (id) sender;
- (void) text: (id) sender;
- (void) text: (id) sender;
- (void) text: (id) sender;
- (void) text: (id) sender;
- (void) text: (id) sender;
- (void) text: (id) sender;
#endif
