// IB use only
@interface iTMTextView: NSTextView
{
@private
    IBOutlet id lineField;
    IBOutlet id statusField;
}
@end
