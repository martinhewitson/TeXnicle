 this is obsolete








#import <Cocoa/Cocoa.h>
// IB use only
 
@interface iTMProjectDocument : NSDocument
{
    IBOutlet NSView * fileView;
    IBOutlet NSView * customCompileView;
    IBOutlet NSView * builtInCompileView;
    IBOutlet NSView * customTypesetView;
    IBOutlet NSView * builtInTypesetView;
    IBOutlet NSView * makeTheBibliographyView;
    IBOutlet NSView * makeTheIndexView;
    IBOutlet NSTabView * projectTabView;
    IBOutlet NSTabView * mainTabView;
    IBOutlet NSTextView * typesetTextView;
    IBOutlet NSTextView * compileTextView;
    IBOutlet NSTextView * errorsTextView;
    IBOutlet NSPopUpButton * errorsPopUp;
    IBOutlet NSView * projectView;
    IBOutlet NSView * terminalView;
    IBOutlet NSView * filesView;
    IBOutlet NSView * errorsView;
    IBOutlet NSTextField * terminalInput;
    IBOutlet NSTextView * terminalOutput;
}
- (IBAction)terminalQuiet:(id) sender;
- (IBAction)terminalStop:(id) sender;
- (IBAction)terminalIgnore:(id) sender;
- (IBAction)terminalExit:(id) sender;
- (IBAction)terminalEscape:(id) sender;
- (IBAction)scrollToNextError:(id) sender;
@end
