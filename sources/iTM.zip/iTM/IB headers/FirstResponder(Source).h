// IB use only
@interface FirstResponder(Source)
- (void) useLineEndings: (id) sender;
- (void) toggleShowControls: (id) sender;
- (void) toggleShowInvisible: (id) sender;
- (void) toggleGroupMatching: (id) sender;
- (void) toggleSyntaxColoring: (id) sender;
- (void) changeDefaultFont: (id) sender;
- (void) changeDefaultColor: (id) sender;
@end
