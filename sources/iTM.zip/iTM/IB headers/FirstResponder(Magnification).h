// IB use only 01/25/2002
@interface iTMRepWindowController(Magnification)
- (void) displayAtMagnification: (id) sender;
- (void) displayAtStepperMagnification: (id) sender;
- (void) displayZoomIn: (id) sender;
- (void) displayZoomOut: (id) sender;
- (void) toggleFixedSize: (id) sender;
- (void) toggleStickToWidth: (id) sender;
- (void) toggleStickToHeight: (id) sender;
- (void) toggleStickToView: (id) sender;
- (void) toggleStickToWindow: (id) sender;
@end
