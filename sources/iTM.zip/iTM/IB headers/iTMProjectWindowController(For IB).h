#import <Cocoa/Cocoa.h>
// IB use only
 
@interface iTMProjectWindowController: NSWindowController
{
    IBOutlet NSTabView * mainTabView;
}
- (IBAction) genericChecked: (id) sender;
- (IBAction) rootEdited: (id) sender;
- (IBAction) chooseRoot: (id) sender;
- (IBAction) relativeAbsolute: (id) sender;
- (IBAction) customIdentChecked: (id) sender;
- (IBAction) outputIdentEdited: (id) sender;

- (IBAction) editCompileScript: (id) sender;
- (IBAction) toggleCompile: (id) sender;
- (IBAction) interactionSelected: (id) sender;
- (IBAction) chooseEngine: (id) sender;
- (IBAction) chooseFormat: (id) sender;
- (IBAction) chooseBase: (id) sender;
- (IBAction) engineEdited: (id) sender;
- (IBAction) formatEdited: (id) sender;
- (IBAction) baseEdited: (id) sender;
- (IBAction) compileSilentlyChecked: (id) sender;
- (IBAction) keepsDVIChecked: (id) sender;
- (IBAction) keepsPSChecked: (id) sender;
- (IBAction) mlTeXChecked: (id) sender;

- (IBAction) editTypesetScript: (id) sender;
- (IBAction) toggleTypeset: (id) sender;
- (IBAction) toggleTypesetMode: (id) sender;

- (IBAction) editBibliographyScript: (id) sender;
- (IBAction) toggleBibliography: (id) sender;
- (IBAction) minXReferencesChosen: (NSTextField *) sender;
- (IBAction) bibTeXSilentlyChecked: (id) sender;
- (IBAction) toggleBibTeXExtendedMode: (id) sender;

- (IBAction) editIndexScript: (id) sender;
- (IBAction) toggleIndex: (id) sender;
- (IBAction) compressBlankChecked: (id) sender;
- (IBAction) germanOrderingChecked: (id) sender;
- (IBAction) letterOrderingChecked: (id) sender;
- (IBAction) noImplicitRangeChecked: (id) sender;
- (IBAction) indexStyleChecked: (id) sender;
- (IBAction) indexOutputChecked: (id) sender;
- (IBAction) separateIndexChecked: (id) sender;
- (IBAction) chooseIndexOutput: (id) sender;
- (IBAction) chooseIndexStyle: (id) sender;
- (IBAction) indexStyleEdited: (id) sender;
- (IBAction) indexOutputEdited: (id) sender;
- (IBAction) indexStartingEdited: (id) sender;
- (IBAction) indexStartingChosen: (id) sender;
- (IBAction) makeIndexSilentlyChecked: (id) sender;

- (IBAction) editCleanScript: (id) sender;
- (IBAction) toggleClean: (id) sender;

- (IBAction) editSpecialScript: (id) sender;
- (IBAction) toggleSpecial: (id) sender;

- (IBAction) macrosDocEdited: (id) sender;
- (IBAction) macrosGfxEdited: (id) sender;
- (IBAction) macrosMathEdited: (id) sender;
- (IBAction) macrosMiscEdited: (id) sender;
- (IBAction) macrosTextEdited: (id) sender;
- (IBAction) macrosTmplEdited: (id) sender;
@end
// 51 actions