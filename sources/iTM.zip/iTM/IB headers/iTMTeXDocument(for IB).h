// IB only
@interface iTMTeXDocument : NSDocument 
{
    IBOutlet id textView;		/*" textView displaying the current TeX source "*/
    IBOutlet id statusField;
    IBOutlet id lineField;
}
- (IBAction) selectedLineChosen: (NSTextField *) sender;
@end






