#import <Cocoa/Cocoa.h>

@interface iTMEditorPrefPane : iTMPreferencePane
{
}
- (IBAction)autoSaveFieldEdited:(id)sender;
- (IBAction)chooseHelper:(id)sender;
- (IBAction)helperFieldEdited:(id)sender;
- (IBAction)toggleAutoSave:(id)sender;
- (IBAction)toggleKeepBackupFile:(id)sender;
- (IBAction)toggleUsesTeXHelper:(id)sender;
@end
