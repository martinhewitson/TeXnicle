#import <Cocoa/Cocoa.h>

@interface iTMTeXFontColorPrefPane : NSObject
{
    IBOutlet id initialKeyView;
    IBOutlet id window;
}
- (IBAction)popupSyntaxAttributes:(id)sender;
- (IBAction)popupTextViewAttributes:(id)sender;
- (IBAction)showColorPanel:(id)sender;
- (IBAction)showFontPanel:(id)sender;
- (IBAction)showSyntaxColorPanel:(id)sender;
- (IBAction)showTextViewColorPanel:(id)sender;
- (IBAction)toggleUseSyntaxColoring:(id)sender;
- (IBAction)toggleUseTextViewColors:(id)sender;
@end
