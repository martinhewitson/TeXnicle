#import <Cocoa/Cocoa.h>

@interface iTMTextFinder : NSWindowController
{
    IBOutlet id findNextButton;
    IBOutlet id findTextField;
    IBOutlet id ignoreCaseButton;
    IBOutlet id replaceAllScopeMatrix;
    IBOutlet id replaceTextField;
    IBOutlet id statusField;
}
- (IBAction)findNext:(id)sender;
- (IBAction)findNextAndOrderFindPanelOut:(id)sender;
- (IBAction)findPrevious:(id)sender;
- (IBAction)replace:(id)sender;
- (IBAction)replaceAll:(id)sender;
- (IBAction)replaceAndFind:(id)sender;
@end
