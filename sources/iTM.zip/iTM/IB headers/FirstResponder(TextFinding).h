// IB use only
@interface FirstResponder(TextFinding)
- (void) showFindPanel: (id) sender;
- (void) centerSelectionInVisibleArea: (id) sender;
- (void) findNext: (id) sender;
- (void) findPrevious: (id) sender;
- (void) replace: (id) sender;
- (void) replaceAndFind:(id) sender;
- (void) enterSelection: (id) sender;
- (void) enterFindPboardSelection: (id) sender;
- (void) replaceAll: (id) sender;
@end
