#import <Cocoa/Cocoa.h>

@interface iTMSimpleScriptWC : NSWindowController
{
    IBOutlet id baseFormatField;
    IBOutlet id customFormatField;
    IBOutlet id customScriptField;
    IBOutlet id extendedCheck;
    IBOutlet id factoryButton;
    IBOutlet id formatMatrix;
    IBOutlet id keepPSCheck;
    IBOutlet id latexScriptField;
    IBOutlet id renderingMatrix;
    IBOutlet id texScriptField;
}
- (IBAction)baseFormatChosen:(id)sender;
- (IBAction)changeRootFile:(id)sender;
- (IBAction)customFormatChosen:(id)sender;
- (IBAction)customScriptChosen:(id)sender;
- (IBAction)engineChosen:(id)sender;
- (IBAction)extendedChecked:(id)sender;
- (IBAction)formatChosen:(id)sender;
- (IBAction)keepPSChecked:(id)sender;
- (IBAction)latexScriptChosen:(id)sender;
- (IBAction)revertToFactoryDefaults:(id)sender;
- (IBAction)texScriptChosen:(id)sender;
@end
