// IB use only, does not work unfortunately
@interface NSTextView(iTMD)
{
    IBOutlet id textStorageDelegate;
}
@end
