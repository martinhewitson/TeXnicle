// for IB only
@interface iTMProjectsManager : NSObject
{
    IBOutlet id activeProjectsMenu;
    IBOutlet id showProjectsMenuItem;
    IBOutlet id projectMenuItem;
    IBOutlet id noProjectMenuItem;
}
- (IBAction)loadDefaultsProjects:(id)sender;
- (IBAction) makeTheIndex: (id) sender;
- (IBAction) makeTheBibliography: (id) sender;
- (IBAction) makeTheGlossary: (id) sender;
- (IBAction) typeset: (id) sender;
- (IBAction) compile: (id) sender;
- (IBAction) special: (id) sender;
- (IBAction) clean: (id) sender;
- (IBAction) terminalRestart: (id) sender;
- (IBAction) terminalStop: (id) sender;
- (IBAction) showProject: (id) sender;
- (IBAction) showFile: (id) sender;
- (IBAction) showInput: (id) sender;
- (IBAction) showOutput: (id) sender;
- (IBAction) showTerminal: (id) sender;
- (IBAction) showTypeset: (id) sender;
- (IBAction) showCompile: (id) sender;
- (IBAction) showMakeTheBibliography: (id) sender;
- (IBAction) showMakeTheIndex: (id) sender;
@end
