#import <Cocoa/Cocoa.h>

@interface iTMWindowsPrefPane : iTMPreferencePane
{
}
- (IBAction)loadCurrent:(id)sender;
- (IBAction)magnificationCurrent:(id)sender;
- (IBAction)magnificationField:(id)sender;
- (IBAction)magnificationPopUp:(id)sender;
- (IBAction)radioPosition:(id)sender;
- (IBAction)show:(id)sender;
- (IBAction)toggleCascade:(id)sender;
@end
