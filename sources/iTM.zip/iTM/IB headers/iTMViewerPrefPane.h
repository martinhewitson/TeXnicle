#import <Cocoa/Cocoa.h>

@interface iTMViewerPrefPane : iTMPreferencePane
{
}
- (IBAction)chooseExternal:(id)sender;
- (IBAction)externalFieldEdited:(id)sender;
- (IBAction)magnificationCurrent:(id)sender;
- (IBAction)magnificationFieldEdited:(id)sender;
- (IBAction)popUpMagnification:(id)sender;
- (IBAction)popUpNewPDFPageMode:(id)sender;
- (IBAction)toggleAutoUpdate:(id)sender;
- (IBAction)toggleBackgroundPDFRendering:(id)sender;
- (IBAction)toggleCompareSize:(id)sender;
- (IBAction)toggleExternal:(id)sender;
- (IBAction)togglePreferA4:(id)sender;
- (IBAction)toggleSmartUpdate:(id)sender;
- (IBAction)toggleStickToWindow:(id)sender;
@end
