// IB use only
@interface NSTextView(TextUtils)
- (IBAction) scrollLineToVisible: (id) sender;
@end
