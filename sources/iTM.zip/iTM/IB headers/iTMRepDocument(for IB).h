// IB use only
@interface iTMRepDocument : NSDocument
{
@private
    IBOutlet id album;/*"Album view"*/
}
@end
