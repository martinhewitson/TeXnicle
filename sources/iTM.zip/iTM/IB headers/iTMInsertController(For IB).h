#import <Cocoa/Cocoa.h>
// IB use only
@interface iTMMacrosController : NSObject
{
    IBOutlet id templatesMenuItem;
}
@end
