// IB use only
@interface iTMPDFDocument : NSDocument
{
@private
    IBOutlet id album;/*"Album view"*/
}
@end
