@interface iTMTeXWindow : NSWindow 
{
}
@end
