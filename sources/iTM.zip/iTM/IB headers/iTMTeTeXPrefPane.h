#import <Cocoa/Cocoa.h>

@interface iTMTeTeXPrefPane : iTMPreferencePane
{
}
- (IBAction)ghostScriptBrowse:(id)sender;
- (IBAction)ghostScriptField:(id)sender;
- (IBAction)ghostScriptRadio:(id)sender;
- (IBAction)helpBrowse:(id)sender;
- (IBAction)helpField:(id)sender;
- (IBAction)helpMenuRecache:(id)sender;
- (IBAction)helpToggleCustom:(id)sender;
- (IBAction)teTeXBrowse:(id)sender;
- (IBAction)teTeXField:(id)sender;
- (IBAction)teTeXRadio:(id)sender;
@end
