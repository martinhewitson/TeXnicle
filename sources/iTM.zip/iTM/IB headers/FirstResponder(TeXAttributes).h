#import <Cocoa/Cocoa.h>
// IB use only
@interface FirstResponder(TeXAttributes)
- (void) changeDefaultFont: (id) sender;
- (void) changeDefaultColor: (id) sender;
- (void) chooseFontToChange: (id) sender;
- (void) chooseColorToChange: (id) sender;
@end
