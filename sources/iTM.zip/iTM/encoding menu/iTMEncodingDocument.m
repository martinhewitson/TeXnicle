/*
//  iTMEncodingDocument.m
//  iTeXMac Encoding Menu
//
//  Created by jlaurens@users.sourceforge.net on Sat May 31 2003.
//  Copyright © 2003 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMEncodingDocument.h"
#import "iTMEncodingController.h"
#import "NSControl_iTeXMac.h"
#import "NSBundle_iTeXMac.h"
#import "NSFileManager_iTeXMac.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMEncodingDocument
/*"Description Forthcoming."*/

NSString * const iTMDraggingEncodingsPboardType = @"iTMDraggingEncodings";

@implementation iTMEncodingDocument
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [_ActualEncodings autorelease];
    _ActualEncodings = nil;
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  windowNibName
- (NSString *) windowNibName;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return NSStringFromClass([self class]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  displayName
- (NSString *) displayName;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([[self fileName] isEqual: [iTMEncodingController encodingsPathInDomain: NSUserDomainMask]])
        return NSLocalizedStringFromTableInBundle(@"User Domain Encodings", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "");
    else if([[self fileName] isEqual: [iTMEncodingController encodingsPathInDomain: NSLocalDomainMask]])
        return NSLocalizedStringFromTableInBundle(@"Local Domain Encodings", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "");
    else if([[self fileName] isEqual: [iTMEncodingController encodingsPathInDomain: NSNetworkDomainMask]])
        return NSLocalizedStringFromTableInBundle(@"Network Domain Encodings", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "");
    else
        return [super displayName];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dataRepresentationOfType:
- (NSData *) dataRepresentationOfType: (NSString *) type;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [iTMEncodingController dataWithEncodings: _ActualEncodings];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  loadDataRepresentation:ofType:
- (BOOL) loadDataRepresentation: (NSData *) data ofType: (NSString *) type;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    id encodings = [iTMEncodingController encodingsWithData: data];
    if(encodings)
    {
        [_ActualEncodings autorelease];
        _ActualEncodings = [encodings retain];
        [actualTableView reloadData];
        return YES;
    }
    else
        return NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  delete:
- (IBAction) delete: (id) sender;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);NSTableView
    NSEnumerator * E = [actualTableView selectedRowEnumerator];
    NSNumber * N;
    while(N = [E nextObject])
        [_ActualEncodings replaceObjectAtIndex: [N intValue] withObject: [NSNull null]];
    int index = 0;
    int row = -1;
    while(index<[_ActualEncodings count])
        if([[_ActualEncodings objectAtIndex: index] isEqual: [NSNull null]])
        {
            [_ActualEncodings removeObjectAtIndex: index];
            if(row<0)
                row = index;
        }
        else
            ++index;
    [actualTableView reloadData];
    if(row<[actualTableView numberOfRows])
        [actualTableView selectRow: row byExtendingSelection: NO];
    else
        [actualTableView selectRow: ([actualTableView numberOfRows] - 1) byExtendingSelection: NO];
    [[actualTableView window] makeFirstResponder: actualTableView];
    [self updateChangeCount: NSChangeDone];
    [self validateUserInterface];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateDelete:
- (void) validateDelete: (id) sender;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [sender setEnabled: ([actualTableView numberOfSelectedRows]>0)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  addSelection:
- (IBAction) addSelection: (id) sender;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);NSTableView
    id O = [[availableTableView dataSource]
                    tableView: availableTableView
                        objectValueForTableColumn: nil
                            row: [availableTableView selectedRow]];
    if(O)
    {
        int targetRow = [actualTableView selectedRow];
        if(targetRow<0)
            targetRow = [actualTableView numberOfRows];
        else if(targetRow<[actualTableView numberOfRows])
            ++targetRow;
        [_ActualEncodings insertObject: O atIndex: targetRow];
        [actualTableView selectRow: targetRow byExtendingSelection: NO];
        [self updateChangeCount: NSChangeDone];
        [actualTableView reloadData];
        [self validateUserInterface];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  addSeparator:
- (IBAction) addSeparator: (id) sender;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);NSTableView
    int SR = [actualTableView selectedRow];
    if(SR<0)
        SR = [_ActualEncodings count];
    else if(SR < [_ActualEncodings count])
        ++SR;
    [_ActualEncodings insertObject: [NSString string] atIndex: SR];
    [actualTableView reloadData];
    [actualTableView selectRow: SR byExtendingSelection: NO];
    [[actualTableView window] makeFirstResponder: actualTableView];
    [self updateChangeCount: NSChangeDone];
    [self validateUserInterface];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  windowControllerDidLoadNib:
- (void) windowControllerDidLoadNib: (NSWindowController *) windowController;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [super windowControllerDidLoadNib: windowController];
    if(!_ActualEncodings)
    {
        [_ActualEncodings autorelease];
        _ActualEncodings = [[NSMutableArray array] retain];
    }
    [[[[availableTableView tableColumns] lastObject] dataCell] setFormatter: [[[iTMEncodingFormatter alloc] init] autorelease]];
    [[[[actualTableView tableColumns] lastObject] dataCell] setFormatter: [[[iTMEncodingFormatter alloc] init] autorelease]];
    [actualTableView registerForDraggedTypes: [NSArray arrayWithObject: iTMDraggingEncodingsPboardType]];
    [availableTableView setDoubleAction: @selector(addSelection:)];
    [actualTableView reloadData];
    [self validateUserInterface];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateUserInterface
- (void) validateUserInterface;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [actualTableView validateWindowContent];
    return;
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMEncodingDocument:

@implementation iTMEncodingDocument(NSTableDataSource)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  numberOfRowsInTableView:
- (int) numberOfRowsInTableView: (NSTableView *) tableView;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [tableView isEqual: actualTableView]? [_ActualEncodings count]: [[iTMEncodingController availableEncodings] count];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  tableView:objectValueForTableColumn:row:
- (id) tableView: (NSTableView *) tableView objectValueForTableColumn: (NSTableColumn *) tableColumn row: (int) row;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([tableView isEqual: actualTableView])
    {
        if((row>=0) && (row < [_ActualEncodings count]))
            return [_ActualEncodings objectAtIndex: row];
    }
    else
    {
        if((row>=0) && (row < [[iTMEncodingController availableEncodings] count]))
            return [[iTMEncodingController availableEncodings] objectAtIndex: row];
    }
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  tableView:writeRows:toPasteboard:
- (BOOL) tableView: (NSTableView *) tv writeRows: (NSArray*) rows toPasteboard: (NSPasteboard*) pboard;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([rows count])
    {
        return ([pboard changeCount] !=
            [pboard declareTypes: [NSArray arrayWithObject: iTMDraggingEncodingsPboardType] owner: nil])
                && [pboard setPropertyList: [[rows copy] autorelease] forType: iTMDraggingEncodingsPboardType];
    }
    else
        return NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  tableView:validateDrop:proposedRow:proposedDropOperation:
- (NSDragOperation) tableView: (NSTableView *) tv validateDrop: (id <NSDraggingInfo>) info proposedRow: (int) row proposedDropOperation: (NSTableViewDropOperation) op;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([tv isEqual: actualTableView])
    {
//NSLog(@"Move or copy %x = %x = %x", tv, actualTableView, [info draggingSource]);
        if((0<=row) && (row < [tv numberOfRows]))
            [tv setDropRow: row dropOperation: NSTableViewDropAbove];
        else
            [tv setDropRow: [tv numberOfRows] dropOperation: NSTableViewDropAbove];
        return [[info draggingSource] isEqual: tv]? NSDragOperationMove: NSDragOperationCopy;
    }
    return NSDragOperationNone;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  tableView:acceptDrop:row:dropOperation:
- (BOOL) tableView: (NSTableView *) tv acceptDrop: (id <NSDraggingInfo>) info row: (int) row dropOperation: (NSTableViewDropOperation) op;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if([tv isEqual: actualTableView])
    {
        if([tv isEqual: [info draggingSource]])
        {
            //move operation:
            NSEnumerator * E = [[[info draggingPasteboard] propertyListForType: iTMDraggingEncodingsPboardType] objectEnumerator];
            NSNumber * N;
            NSMutableArray * MRA = [NSMutableArray array];
            id draggingS = [info draggingSource];
            id dataS = [draggingS dataSource];
            while(N = [E nextObject])
            {
                int index = [N intValue];
                id O = [dataS tableView: draggingS objectValueForTableColumn: nil row: index];
                if(O)
                {
                    [MRA addObject: O];
                    [_ActualEncodings replaceObjectAtIndex: index withObject: [NSNull null]];
                }
            }
            E = [MRA reverseObjectEnumerator];
            while(N = [E nextObject])
                [_ActualEncodings insertObject: N atIndex: row];
            E = [_ActualEncodings reverseObjectEnumerator];
            int index = 0;
            while(index<[_ActualEncodings count])
            {
                if([[_ActualEncodings objectAtIndex: index] isEqual: [NSNull null]])
                {
                    if(index<row)
                        --row;
                    [_ActualEncodings removeObjectAtIndex: index];
                }
                else
                    ++index;
            }
            [tv reloadData];
            int length = [MRA count];
            if(length)
                [tv selectRow: row byExtendingSelection: NO];
            while(--length>0)
                [tv selectRow: ++row byExtendingSelection: YES];
            [[tv window] makeFirstResponder: tv];
            [self updateChangeCount: NSChangeDone];
            [self validateUserInterface];
            return YES;
        }
        else
        {
            NSEnumerator * E = [[[info draggingPasteboard] propertyListForType: iTMDraggingEncodingsPboardType] reverseObjectEnumerator];
            NSNumber * N;
            int length = 0;
            id draggingS = [info draggingSource];
            id dataS = [draggingS dataSource];
            while(N = [E nextObject])
            {
                id O = [dataS tableView: draggingS objectValueForTableColumn: nil row: [N intValue]];
                if(O)
                {
                    [_ActualEncodings insertObject: O atIndex: row];
                    ++length;
                }
            }
            [tv reloadData];
            if(length)
                [tv selectRow: row byExtendingSelection: NO];
            while(--length>0)
                [tv selectRow: ++row byExtendingSelection: YES];
            [[tv window] makeFirstResponder: tv];
            [self updateChangeCount: NSChangeDone];
            [self validateUserInterface];
            return YES;
        }
    }
    return NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  tableViewSelectionDidChange:
- (void) tableViewSelectionDidChange: (NSNotification *) notification;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self validateUserInterface];
    return;
}
#if 0
// optional @implementation MyOutlineView 

- (NSDragOperation)draggingSourceOperationMaskForLocal:(BOOL)isLocal {
    if (isLocal) return NSDragOperationEvery;
    else return NSDragOperationCopy;
}

@end
registerForDragged
- (void)tableView:(NSTableView *)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn *)tableColumn row:(int)row;

// optional - drag and drop support
- (BOOL)tableView:(NSTableView *)tv writeRows:(NSArray*)rows toPasteboard:(NSPasteboard*)pboard;
    // This method is called after it has been determined that a drag should begin, but before the drag has been started.  To refuse the drag, return NO.  To start a drag, return YES and place the drag data onto the pasteboard (data, owner, etc...).  The drag image and other drag related information will be set up and provided by the table view once this call returns with YES.  The rows array is the list of row numbers that will be participating in the drag.

- (NSDragOperation)tableView:(NSTableView*)tv validateDrop:(id <NSDraggingInfo>)info proposedRow:(int)row proposedDropOperation:(NSTableViewDropOperation)op;
    // This method is used by NSTableView to determine a valid drop target.  Based on the mouse position, the table view will suggest a proposed drop location.  This method must return a value that indicates which dragging operation the data source will perform.  The data source may "re-target" a drop if desired by calling setDropRow:dropOperation: and returning something other than NSDragOperationNone.  One may choose to re-target for various reasons (eg. for better visual feedback when inserting into a sorted position).

- (BOOL)tableView:(NSTableView*)tv acceptDrop:(id <NSDraggingInfo>)info row:(int)row dropOperation:(NSTableViewDropOperation)op;
    // This method is called when the mouse is released over an outline view that previously decided to allow a drop via the validateDrop method.  The data source should incorporate the data from the dragging pasteboard at this time.
#endif
@end

@implementation iTMEncodingFormatter
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  stringForObjectValue:
- (NSString *) stringForObjectValue: (id) obj;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * result = [NSString string];
    if([obj respondsToSelector: @selector(unsignedIntValue)])
    {
        result = [NSString localizedNameOfStringEncoding: [(NSNumber *)obj unsignedIntValue]];
    }
    else if([obj isKindOfClass: [NSString class]] && [(NSString *)obj length])
    {
        result = [NSString localizedNameOfStringEncoding: [[iTMEncodingController stringEncodingFromString: obj] unsignedIntValue]];
    }
    if(![result length])
        result = [NSString stringWithUTF8String: "―"];
    return result;
}
@end
