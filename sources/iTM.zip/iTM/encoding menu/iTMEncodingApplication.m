/*
//  iTMEncodingApplication.m
//  encoding menu
//
//  Created by jlaurens@users.sourceforge.net on Mon Jun 02 2003.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMEncodingApplication.h"
#import "iTMEncodingController.h"
#import "NSControl_iTeXMac.h"
#import "NSBundle_iTeXMac.h"
#import "NSFileManager_iTeXMac.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMEncodingApplication
/*"Description forthcoming."*/
@implementation iTMEncodingApplication
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  customizeUser:
- (IBAction) customizeUser: (id) sender;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [iTMEncodingController encodingsPathInDomain: NSUserDomainMask];
    if(![[NSDocumentController sharedDocumentController] openDocumentWithContentsOfFile: path display: YES])
    {
        NSString * directory = [path stringByDeletingLastPathComponent];
        if([[NSFileManager defaultManager] smartCreateDirectoryAtPath: directory attributes: nil]
            && [[NSFileManager defaultManager] isWritableFileAtPath: directory])
        {
            NSDocument * D = [[NSDocumentController sharedDocumentController] openUntitledDocumentOfType: @"DocumentType" display: YES];
            [D setFileName: path];
    //        [D updateChangeCount: NSChangeDone];
        }
        else
            NSBeep();
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  customizeLocal:
- (IBAction) customizeLocal: (id) sender;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [iTMEncodingController encodingsPathInDomain: NSLocalDomainMask];
    if(![[NSDocumentController sharedDocumentController] openDocumentWithContentsOfFile: path display: YES])
    {
        NSString * directory = [path stringByDeletingLastPathComponent];
        if([[NSFileManager defaultManager] smartCreateDirectoryAtPath: directory attributes: nil]
            && [[NSFileManager defaultManager] isWritableFileAtPath: directory])
        {
            NSDocument * D = [[NSDocumentController sharedDocumentController] openUntitledDocumentOfType: @"DocumentType" display: YES];
            [D setFileName: path];
    //        [D updateChangeCount: NSChangeDone];
        }
        else
            NSBeep();
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  customizeNetwork:
- (IBAction) customizeNetwork: (id) sender;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSString * path = [iTMEncodingController encodingsPathInDomain: NSNetworkDomainMask];
    if(![[NSDocumentController sharedDocumentController] openDocumentWithContentsOfFile: path display: YES])
    {
        NSString * directory = [path stringByDeletingLastPathComponent];
        if([[NSFileManager defaultManager] smartCreateDirectoryAtPath: directory attributes: nil]
            && [[NSFileManager defaultManager] isWritableFileAtPath: directory])
        {
            NSDocument * D = [[NSDocumentController sharedDocumentController] openUntitledDocumentOfType: @"DocumentType" display: YES];
            [D setFileName: path];
    //        [D updateChangeCount: NSChangeDone];
        }
        else
            NSBeep();
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateMenuItem:
- (BOOL) validateMenuItem: (id <NSMenuItem>) anItem;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- for 1.3: Sat May 31 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    SEL action = [anItem action];
    if(action == @selector(customizeUser:))
    {
        NSString * path = [iTMEncodingController encodingsPathInDomain: NSUserDomainMask];
//NSLog(@"user path: %@", path);
        if([[NSFileManager defaultManager] isWritableFileAtPath: path])
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"User Domain: Edit", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
        else if([[NSFileManager defaultManager] fileExistsAtPath: path])
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"User Domain: Open", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
        else
        {
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"User Domain: Create", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
            return [[NSFileManager defaultManager] isSmartWritableDirectoryAtPath: [path stringByDeletingLastPathComponent]];
        }
        return YES;
    }
    else if(action == @selector(customizeLocal:))
    {
        NSString * path = [iTMEncodingController encodingsPathInDomain: NSLocalDomainMask];
//NSLog(@"local path: %@", path);
        if([[NSFileManager defaultManager] isWritableFileAtPath: path])
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"Local Domain: Edit", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
        else if([[NSFileManager defaultManager] fileExistsAtPath: path])
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"Local Domain: Open", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
        else
        {
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"Local Domain: Create", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
            return [[NSFileManager defaultManager] isSmartWritableDirectoryAtPath: [path stringByDeletingLastPathComponent]];
        }
        return YES;
    }
    else if(action == @selector(customizeNetwork:))
    {
        NSString * path = [iTMEncodingController encodingsPathInDomain: NSNetworkDomainMask];
//NSLog(@"network path: %@", path);
        if([[NSFileManager defaultManager] isWritableFileAtPath: path])
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"Network Domain: Edit", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
        else if([[NSFileManager defaultManager] fileExistsAtPath: path])
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"Network Domain: Open", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
        else
        {
            [anItem setTitle: NSLocalizedStringFromTableInBundle(@"Network Domain: Create", @"EncodingMenu", [NSBundle bundleForClass: [self class]], "")];
            return [[NSFileManager defaultManager] isSmartWritableDirectoryAtPath: [path stringByDeletingLastPathComponent]];
        }
        return YES;
    }
    else 
        return [super validateMenuItem: anItem];
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMEncodingApplication

