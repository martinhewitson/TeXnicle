/*
//  iTMInternetUpdater.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Mar 03 2003.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMInternetUpdater.h"
#import "NSControl_iTeXMac.h"

NSString * const iTMIUiTeXMacKey = @"iTeXMac";
NSString * const iTMIUiTeXMacDevKey = @"iTeXMac Dev";
NSString * const iTMIUiTMKeyBindingEditorKey = @"iTM Key Binding Editor";
NSString * const iTMIUiTMMacroEditorKey = @"iTM Macro Editor";
NSString * const iTMIULaTeXHelpBookKey = @"LaTeX Help Book";
NSString * const iTMIUTCOKey = @"TCO";
NSString * const iTMIUFAQLaTeXFrKey = @"FAQ LaTeX Fr";
NSString * const iTMIUDownloadURLKey = @"Download URL";
NSString * const iTMIUNotesURLKey = @"Notes URL";
NSString * const iTMIUVersionKey = @"version";

enum
{
    iTMIUiTeXMacTag = 1,
    iTMIUiTeXMacDevTag = 2,
    iTMIUiTMKeyBindingEditorTag = 3,
    iTMIUiTMMacroEditorTag = 4,
    iTMIULaTeXHelpBookTag = 5,
    iTMIUTCOTag = 6,
    iTMIUFAQLaTeXFrTag = 7
};
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMInternetUpdater
/*"Description forthcoming."*/
@implementation iTMInternetUpdater
static id _iTMSharedInternetUpdater = nil;
static NSArray * _iTMInternetUpdaterKeys = nil;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initialize
+ (void) initialize;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"+[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(!_iTMInternetUpdaterKeys)
        _iTMInternetUpdaterKeys = [[NSArray arrayWithObjects: [NSNull null], iTMIUiTeXMacKey, iTMIUiTeXMacDevKey, iTMIUiTMKeyBindingEditorKey, iTMIUiTMMacroEditorKey, iTMIULaTeXHelpBookKey, iTMIUTCOKey, iTMIUFAQLaTeXFrKey, nil] retain];// [NSNull null] for tag == index
    [[NSUserDefaults standardUserDefaults] registerDefaults: [NSDictionary dictionaryWithObjectsAndKeys:
        @"", iTMIUiTeXMacKey,
        @"", iTMIUiTeXMacDevKey,
        @"", iTMIUiTMKeyBindingEditorKey,
        @"", iTMIUiTMMacroEditorKey,
        @"", iTMIULaTeXHelpBookKey,
        @"", iTMIUTCOKey,
        @"", iTMIUFAQLaTeXFrKey,
            nil]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  sharedInternetUpdater
+ (id) sharedInternetUpdater;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return [[[self alloc] init] autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  init
- (id) init;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(_iTMSharedInternetUpdater)
    {
        [self dealloc];
        return _iTMSharedInternetUpdater;
    }
    else if(self = [super init])
    {
        _iTMSharedInternetUpdater = [self retain];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [super dealloc];
    [self setVersions: nil];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  awakeFromNib
- (void) awakeFromNib;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [progressWheel setStyle: NSProgressIndicatorSpinningStyle];
    [progressWheel setDisplayedWhenStopped: NO];
    [self validateUserInterface];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  browseiTeXMac:
- (IBAction) browseiTeXMac: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  browseiTeXMacDev:
- (IBAction) browseiTeXMacDev: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  browseiTMKBE:
- (IBAction) browseiTMKBE: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  checkForUpdates:
- (IBAction) checkForUpdates: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [self setVersions: nil];
    [self versions];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateCheckForUpdates:
- (IBAction) validateCheckForUpdates: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [sender setEnabled: (_Versions == nil)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  installiTeXMac:
- (IBAction) installiTeXMac: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  installiTeXMacDev:
- (IBAction) installiTeXMacDev: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  installiTMKBE:
- (IBAction) installiTMKBE: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  windowWillClose:
- (void) windowWillClose: (NSNotification *) aNotification;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [NSApp terminate: nil];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateUserInterface
- (void) validateUserInterface;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    [[progressWheel window] validateContent];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  threadedLookUpVersions:
- (void) threadedLookUpVersions: (id) sender;
/*"Lazy Initializer.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSAutoreleasePool * AP = [NSAutoreleasePool new];
    [progressWheel startAnimation: self];
    [self setVersions: [NSDictionary dictionaryWithContentsOfURL:
        [NSURL URLWithString: @"http://itexmac.sourceforge.net/Versions.plist"]]];
//NSLog(@"_Versions: %@", _Versions);
    [progressWheel stopAnimation: self];
    if(!_Versions)
        [self performSelectorOnMainThread: @selector(couldNotLookUpVersions:) withObject: nil waitUntilDone: NO];
    [AP release];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  couldNotLookUpVersions:
- (void) couldNotLookUpVersions: (id) sender;
/*"Lazy Initializer.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    NSBeginCriticalAlertSheet(
        NSLocalizedStringFromTableInBundle(@"iTeXMac_Update Problem", @"Updater", [NSBundle bundleForClass: [self class]], "Panel Title"),
        nil, nil, nil, [progressWheel window], nil, NULL, NULL, nil,
        NSLocalizedStringFromTableInBundle(@"Cannot find update information.", @"Updater", [NSBundle bundleForClass: [self class]], "Problem"));
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  versions
- (NSDictionary *) versions;
/*"Lazy Initializer.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(!_Versions)
    {
        [NSThread detachNewThreadSelector:@selector(threadedLookUpVersions:) toTarget: self withObject: nil];
    }
    return _Versions;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setVersions:
- (void) setVersions: (NSDictionary *) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [NSDictionary class]])
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSDictionary argument expected: %@.",
            [self class], NSStringFromSelector(_cmd), argument];
    else
    {
        NSLock * L = [[NSLock alloc] init];
        [L lock];
        [_Versions autorelease];
        _Versions = [argument copy];
        [L unlock];
        [L release];
        [self validateUserInterface];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  latestEdited:
- (IBAction) latestEdited: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateLatestEdited:
- (void) validateLatestEdited: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSDictionary * D = [_Versions objectForKey: [_iTMInternetUpdaterKeys objectAtIndex: tag]];
        id O = [D isKindOfClass: [NSDictionary class]]? [D objectForKey: iTMIUVersionKey]: @"";
        [sender setObjectValue: (O? O: @"")];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  installedEdited:
- (IBAction) installedEdited: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateInstalledEdited:
- (void) validateInstalledEdited: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSString * path = [[NSUserDefaults standardUserDefaults] stringForKey: [_iTMInternetUpdaterKeys objectAtIndex: tag]];
        NSBundle * B = [NSBundle bundleWithPath: path];
        NSString * version = [[B infoDictionary] objectForKey: @"CFBundleVersion"];
        [sender setStringValue: ([version length]? version: @"?")];
    }
    else
        [sender setStringValue: @""];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  seeNotes:
- (IBAction) seeNotes: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//iTMIUNotesURLKey
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSDictionary * D = [_Versions objectForKey: [_iTMInternetUpdaterKeys objectAtIndex: tag]];
        NSString * url = [D isKindOfClass: [NSDictionary class]]? [D objectForKey: iTMIUNotesURLKey]: @"";
        [[NSWorkspace sharedWorkspace] openURL: [NSURL URLWithString: (url? url: @"")]];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateSeeNotes:
- (IBAction) validateSeeNotes: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//iTMIUNotesURLKey
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSDictionary * D = [_Versions objectForKey: [_iTMInternetUpdaterKeys objectAtIndex: tag]];
        NSString * url = [D isKindOfClass: [NSDictionary class]]? [D objectForKey: iTMIUNotesURLKey]: @"";
        [sender setEnabled: ([url length]>0)];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  browse:
- (IBAction) browse: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//iTMIUNotesURLKey
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
    //NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
        NSString * K = [_iTMInternetUpdaterKeys objectAtIndex: tag];
        NSOpenPanel * OP = [NSOpenPanel openPanel];
        [OP setAllowsMultipleSelection: NO];
        [OP setCanChooseFiles: YES];
        [OP setCanChooseDirectories: NO];
        [OP setResolvesAliases: NO];
        [OP setTreatsFilePackagesAsDirectories: NO];
        [OP setPrompt: [NSString stringWithFormat:
            NSLocalizedStringFromTableInBundle(@"%@ Location", @"Internet Updater", [NSBundle bundleForClass: [self class]], ""),
                K]];
        [OP beginSheetForDirectory: nil
            file: nil
                types: [NSArray arrayWithObject: @"app"]
                    modalForWindow: [progressWheel window]
                        modalDelegate: self
                            didEndSelector: @selector(openPanelDidBrowse:returnCode:key:)
                                contextInfo: K];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  openPanelDidBrowse:returnCode:key:
- (void) openPanelDidBrowse: (NSOpenPanel *) sheet returnCode: (int) returnCode key: (NSString *) aKey
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    if(returnCode == NSOKButton)
    {
        NSAssert4(([aKey isKindOfClass: [NSString class]] && [aKey length]),
            @"-[%@ %@] 0x%x Bad context info: %@", [self class], NSStringFromSelector(_cmd), self, aKey);
        [[NSUserDefaults standardUserDefaults] setObject: [[sheet filenames] objectAtIndex: 0] forKey: aKey];
        [self validateUserInterface];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateBrowse:
- (IBAction) validateBrowse: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//iTMIUNotesURLKey
    int tag = [sender tag];
    [sender setEnabled: ((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  install:
- (IBAction) install: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//iTMIUNotesURLKey
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSDictionary * D = [_Versions objectForKey: [_iTMInternetUpdaterKeys objectAtIndex: tag]];
        NSString * url = [D isKindOfClass: [NSDictionary class]]? [D objectForKey: iTMIUDownloadURLKey]: @"";
        [[NSWorkspace sharedWorkspace] openURL: [NSURL URLWithString: (url? url: @"")]];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateInstall:
- (IBAction) validateInstall: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
//iTMIUNotesURLKey
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSString * K = [_iTMInternetUpdaterKeys objectAtIndex: tag];
        NSDictionary * D = [_Versions objectForKey: K];
        NSString * lastVersion = [D isKindOfClass: [NSDictionary class]]? [D objectForKey: iTMIUVersionKey]: @"";
        NSString * path = [[NSUserDefaults standardUserDefaults] stringForKey: K];
        NSBundle * B = [NSBundle bundleWithPath: path];
        NSString * oldVersion = [[B infoDictionary] objectForKey: @"CFBundleVersion"];
        [sender setEnabled: ([lastVersion length] && ![oldVersion isEqual: lastVersion])];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  see:
- (IBAction) see: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSString * path = [[NSUserDefaults standardUserDefaults] stringForKey: [_iTMInternetUpdaterKeys objectAtIndex: tag]];
        [[NSWorkspace sharedWorkspace] selectFile: path inFileViewerRootedAtPath: [path stringByDeletingLastPathComponent]];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateSee:
- (IBAction) validateSee: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.3: Mon Mar 03 2003
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", [self class], NSStringFromSelector(_cmd), self);
    int tag = [sender tag];
    if((tag > 0) && (tag < [_iTMInternetUpdaterKeys count]))
    {
        NSString * path = [[NSUserDefaults standardUserDefaults] stringForKey: [_iTMInternetUpdaterKeys objectAtIndex: tag]];
        [sender setEnabled: [[NSFileManager defaultManager] fileExistsAtPath: path]];
        return;
    }
    [sender setEnabled: NO];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMInternetUpdater

