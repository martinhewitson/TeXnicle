//
//  main.m
//  Internet Updater
//
//  Created by J�r�me Laurens on Mon Mar 03 2003.
//  Copyright (c) 2003 Laurens'Tribune. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
