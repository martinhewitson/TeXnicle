/*
//  iTMGeometry.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Dec 02 2002.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import <Foundation/NSGeometry.h>
#import <Foundation/NSString.h>
#import <Foundation/NSException.h>
//#import <Foundation/Foundation.h>
//#import <AppKit/AppKit.h>
#import "iTMGeometry.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMGeometry
/*"Description forthcoming."*/
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMPointConvertedToIntrinsic
NSPoint iTMPointConvertedToIntrinsic(NSPoint point, NSRect rect)
/*"Given a frame and a point in the same absolute coordinate space, returns the coordinates of this point expressed relative to the frame intrinsic coordinate space.
The relative coordinates of the frame are NSMakeRect(0, 0, 1, 1).
The frame must have a non zero width and height, otherwise an exception is raised.
Version History: jlaurens@users.sourceforge.net
- 1.3: 03/10/2002
To Do List:
"*/
{
    if((rect.size.width<=0) || (rect.size.height<=0))
        [NSException raise: NSInvalidArgumentException format: @"iTMIntrinsicPointRelativeToFrame bad size: got %@.", NSStringFromRect(rect)];
    return NSMakePoint((point.x - rect.origin.x)/rect.size.width, (point.y - rect.origin.y)/rect.size.height);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMPointConvertedToGlobal
NSPoint iTMPointConvertedToGlobal(NSPoint point, NSRect rect)
/*"This is the convers operation of the above one.
Given a frame and a point in the frame intrinsic coordinate space, returns the coordinates of the point given relative to the frame in the global space coordinates.
The relative coordinates of the frame are NSMakeRect(0, 0, 1, 1).
The frame must have a non zero width and height, otherwise an exception is raised.
Version History: jlaurens@users.sourceforge.net
- 1.3: 03/10/2002
To Do List:
"*/
{
    if((rect.size.width<=0) || (rect.size.height<=0))
        [NSException raise: NSInvalidArgumentException format: @"iTMRelativePointIntrinsicToFrame bad size: got %@.", NSStringFromRect(rect)];
    return NSMakePoint(rect.origin.x+point.x*rect.size.width, rect.origin.y+point.y*rect.size.height);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMCenterRect
NSRect iTMCenterRect(NSRect rect, NSPoint newCenter)
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.3: 03/10/2002
To Do List:
"*/
{
    return NSOffsetRect(rect, -NSMidX(rect) + newCenter.x, -NSMidY(rect) + newCenter.y);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMGeometry

