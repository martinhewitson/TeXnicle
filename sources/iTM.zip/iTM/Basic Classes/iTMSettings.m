/*
//  iTMSettings.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Tue Mar 26 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution (contributor) ") 
//  To Do List: (format "- proposition (percentage actually done) ") 
*/

#import "iTeXMac.h"

#import <Foundation/NSDictionary.h>
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import "NSUserDefaults(iTeXMac).h"
#import "iTMSettings.h"

NSString * const iTMSettingsDidChangeNotification = @"iTMSettingsDidChange";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMSettings
/*"This object is used to store settings that might override some settings in a basic set of settings, typically the user defaults data base. It implements all the setters and getters of the NSUserDefaults instances. Beware when categories are created. All the setters really fill the settings, even if afterwards the values are the same in the settings and the base settings. This might be implemented in a different way driven by a flag. It is consistent now because the base settings are the user defaults data base: if those defaults are changed, the local settings are not.

When no basic settings are given on initialization time, the user defaults data base is used instead. The NSUserDefaults shared instance is cached.

Various categories are declared here, the NSDocument instances are the only object where settings are really stored, if ever."*/
@implementation iTMSettings
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"Very lazy initializer.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    [self setDictionaryRepresentation: nil];
    [self setBaseSettings: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dictionaryRepresentation
- (NSMutableDictionary *) dictionaryRepresentation;
/*"Very lazy initializer.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    return _DR? _DR: (_DR = [[NSMutableDictionary dictionary] retain]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setDictionaryRepresentation:
- (void) setDictionaryRepresentation: (NSDictionary *) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    if (argument && ![argument isKindOfClass: [NSDictionary class]]) 
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSDictionary argument expected: %@.",
            [self class], NSStringFromSelector (_cmd) , argument];
    else if (![_DR isEqual: argument]) 
    {
        [_DR autorelease];
        _DR = [argument mutableCopy];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  baseSettings
- (id) baseSettings;
/*"Very lazy initializer.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    return _BaseSettings? _BaseSettings: (_BaseSettings = [[NSUserDefaults standardUserDefaults] retain]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setBaseSettings:
- (void) setBaseSettings: (id) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    if (![_BaseSettings isEqual: argument]) 
    {
        [_BaseSettings autorelease];
        _BaseSettings = [argument retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  objectForKey:
- (id) objectForKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    if([key isKindOfClass: [NSString class]] && [key length])
    {
        id result = [[self dictionaryRepresentation] objectForKey: key];
        return result? result: [[self baseSettings] objectForKey: key];
    }
    else
        return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setObject:forKey:
- (void) setObject: (id) value forKey: (NSString *) key;
/*"Non 0 length strings only, non nil values only, otherwise no effect.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    if([key isKindOfClass: [NSString class]] && [key length] && (value != nil))
        [[self dictionaryRepresentation] setObject: value forKey: key];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  removeObjectForKey:
- (void) removeObjectForKey: (NSString *) key;
/*"Non 0 length strings only, otherwise no effect.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    if([key isKindOfClass: [NSString class]] && [key length])
        [[self dictionaryRepresentation] removeObjectForKey: key];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= fontForKey:
- (NSFont *) fontForKey: (NSString *) aKey;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [NSFont fontWithNameSizeDictionary: [self objectForKey: aKey]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setFont:forKey:
- (void) setFont: (NSFont *) aFont forKey: (NSString *) aKey;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self setObject: [aFont nameSizeDictionary] forKey: aKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= colorForKey:
- (NSColor *) colorForKey: (NSString *) aKey;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [NSColor colorWithRGBADictionary: [self objectForKey: aKey]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setColor:forKey:
- (void) setColor: (NSColor *) aColor forKey: (NSString *) aKey;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self setObject: [aColor RGBADictionary] forKey: aKey];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  stringForKey:
- (NSString *) stringForKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    id result = [self objectForKey: key];
    return [result isKindOfClass: [NSString class]]?
                result:
                    ([result respondsToSelector: @selector(stringValue)]? [result stringValue]: [NSString string]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  arrayForKey:
- (NSArray *) arrayForKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    id result = [self objectForKey: key];
    return [result isKindOfClass: [NSArray class]]? result: nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dictionaryForKey:
- (NSDictionary *) dictionaryForKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    id result = [self objectForKey: key];
    return [result isKindOfClass: [NSDictionary class]]? result: nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dataForKey:
- (NSData *) dataForKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    id result = [self objectForKey: key];
    return [result isKindOfClass: [NSData class]]? result: nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  stringArrayForKey:
- (NSArray *) stringArrayForKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    BOOL OK = YES;
    id result = [self arrayForKey: key];
    NSMutableArray * MA = [NSMutableArray array];
    NSEnumerator * E = [result objectEnumerator];
    id object;
    while(object = [E nextObject])
        if([object isKindOfClass: [NSString class]])
            [MA addObject: object];
        else if([object respondsToSelector: @selector(stringValue)])
            [MA addObject: [object stringValue]];
        else
        {
            OK = NO;
            break;
        }
    return OK? result: nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  integerForKey:
- (int) integerForKey: (NSString *) key; 
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    id result = [self objectForKey: key];
    return [result respondsToSelector: @selector(intValue)]? [result intValue]: 0;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  floatForKey:
- (float) floatForKey: (NSString *) key; 
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    id result = [self objectForKey: key];
    return [result respondsToSelector: @selector(floatValue)]? [result floatValue]: 0;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  boolForKey:
- (BOOL) boolForKey: (NSString *) key;  
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    id result = [self objectForKey: key];
    return [result respondsToSelector: @selector(boolValue)]? [result boolValue]: 0;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setInteger:forKey:
- (void) setInteger: (int) value forKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    [self setObject: [NSNumber numberWithInt: value] forKey: key];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setFloat:forKey:
- (void) setFloat: (float) value forKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    [self setObject: [NSNumber numberWithFloat: value] forKey: key];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setBool:forKey:
- (void) setBool: (BOOL) value forKey: (NSString *) key;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    [self setObject: [NSNumber numberWithBool: value] forKey: key];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  notifyChangeNow
- (void) notifyChangeNow;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    [[NSNotificationCenter defaultCenter] postNotificationName: iTMSettingsDidChangeNotification object: self];
    return;
}
@end

@implementation NSObject(iTMSettings)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  settings:
- (id) settings;
/*"Subclasses will most certainly override this method.
Default implementation returns the NSUserDefaults shared instance.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    return [NSUserDefaults standardUserDefaults];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  settingsDidChange
- (void) settingsDidChange;
/*"This message is sent each time the settings have changed.
The receiver will take appropriate actions to synchronize its state with its settings.
Subclasses will most certainly override this method because the default implementation does nothing.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    return;
}
@end

@implementation NSWindowController(iTMSettings)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  settings:
- (id) settings;
/*"Returns the settings of its document.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    return [[self document] settings];
}
@end

@implementation NSWindow(iTMSettings)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  settings:
- (id) settings;
/*"Returns the settings of its window controller.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    return [[[self windowController] document] settings];
}
@end

@implementation NSView(iTMSettings)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  settings:
- (id) settings;
/*"Returns the settings of its window.
Version history: jlaurens@users.sourceforge.net
- 1.1.a6: 03/26/2002
To Do List:
"*/
{
    return [[[[self window] windowController] document] settings];
}
@end

@implementation NSTextStorage(iTMSettings)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  settings:
- (id) settings;
/*"Returns the settings of the first text view of its first layout manager.
Version history: jlaurens@users.sourceforge.net
- 1.1.b0: 04/17/2002
To Do List:
"*/
{
    NSArray * A = [self layoutManagers];
    iTMSettings * theResult = [A count]?
        [[[[[[A objectAtIndex: 0] firstTextView] window] windowController] document] settings]:
            [NSUserDefaults standardUserDefaults];
    return theResult? theResult: [NSUserDefaults standardUserDefaults];
}
@end


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMSettings

