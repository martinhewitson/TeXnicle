/*
//  iTMHistoryButton.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Tue Sep 25 2001.
//  Copyright ¬© 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

//#import "iTeXMac.h"

#import <Foundation/NSObject.h>
#import <Foundation/NSGeometry.h>
#import <Foundation/NSString.h>
#import "NSButton(iTeXMac).h"
#import "iTMMixedButton.h"
#import "iTMHistoryButton.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMHistoryButton
/*"Private use only. Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
@implementation iTMForwardButton
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initWithFrame:
- (id) initWithFrame: (NSRect) irrelevant;
/*"Private use only. Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(self = [super initWithFrame: NSMakeRect(0,0,32,31)])
    {
        [self setBordered: YES];
        [[self cell] setBezelStyle: NSCircularBezelStyle];
        [[self cell] setControlSize: NSSmallControlSize];
        [[self cell] setHighlightsBy: NSChangeGrayCellMask];//[NSContentsCellMask];
        [self setCenteredArrow: NO];
        [self setMixedEnabled: YES];
        [self fixImage];
        [self setTitle: @""];
        [self setAction: @selector(displayForwardPage:)];
        [self setTarget: nil];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  awakeFromNib
- (void) awakeFromNib;
/*"No target set here.
Version History: jlaurens@users.sourceforge.net
- 1.3: 13/12/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if([[self superclass] instancesRespondToSelector: _cmd])
        [super awakeFromNib];
    [self fixImage];
    return;
}
@end

@implementation iTMBackButton
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initWithFrame:
- (id) initWithFrame: (NSRect) irrelevant;
/*"Private use only. Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(self = [super initWithFrame: NSMakeRect(0,0,32,31)])
    {
        [self setBordered: YES];
        [[self cell] setBezelStyle: NSCircularBezelStyle];
        [[self cell] setControlSize: NSSmallControlSize];
        [[self cell] setHighlightsBy: NSChangeGrayCellMask];//[NSContentsCellMask];
        [self setCenteredArrow: NO];
        [self setMixedEnabled: YES];
        [self fixImage];
        [self setTitle: @""];
        [self setAction: @selector(displayBackPage:)];
        [self setTarget: nil];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  awakeFromNib
- (void) awakeFromNib;
/*"No target set here.
Version History: jlaurens@users.sourceforge.net
- 1.3: 13/12/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if([[self superclass]¬†instancesRespondToSelector: _cmd])
        [super awakeFromNib];
    [self fixImage];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMHistoryButton

