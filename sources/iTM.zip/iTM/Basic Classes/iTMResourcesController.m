/*
//  iTMResourcesController.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Fri Oct 12 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTMResourcesController.h"

NSString * const iTMRCGeneralKey = @"General";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMResourcesController
/*"This object provides access to iTeXMac specific resources, namely generics, templates, macros, colors that resides in different location in the file system. All relevant code is emplemented in categories elsewhere.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: Simply implement
"*/
@interface iTMResourcesController(Virtual)
- (BOOL) _CompleteResourcesForDirectoryWrapper: (NSFileWrapper *) aWrapper;
@end

@interface iTMResourcesController(Private)
- (BOOL) completeResourcesForDirectoryWrapper: (NSFileWrapper *) aWrapper;
@end

@implementation iTMResourcesController
static id _iTMResourcesController;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= sharedResourcesController
+ (id) sharedResourcesController;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _iTMResourcesController? _iTMResourcesController:
                        (_iTMResourcesController = [[self allocWithZone: [NSApp zone]] init]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= init
- (id) init;
/*"The first ressources controller created is the shared one. Registers the receiver as the observer of NSApplicationWillFinishLaunchingNotification, if it responds to #{applicationWillFinishLaunching:}.
This message is defined in the iTeXMac category.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if(_iTMResourcesController)
    {
        if(![self isEqual: _iTMResourcesController])
            [self release];
        return [_iTMResourcesController retain];
    }
    else
    {
        if(self = [super init])
        {
            [[NSNotificationCenter defaultCenter] removeObserver: [self class]
                name: NSApplicationWillFinishLaunchingNotification
                    object: NSApp];
            [[NSNotificationCenter defaultCenter] addObserver: self
                selector: @selector(applicationWillFinishLaunching:)
                    name: NSApplicationWillFinishLaunchingNotification
                        object: NSApp];
        }
        return _iTMResourcesController = self;
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= relativeLibraryPath
- (NSString *) relativeLibraryPath;
/*"The first ressources controller created is the shared one.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [[[@"Library" stringByAppendingPathComponent: @"Application Support"]
        stringByAppendingPathComponent: [[[NSBundle mainBundle] infoDictionary] objectForKey: @"CFBundleName"]]// "iTeXMac"
            stringByStandardizingPath];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= libraryPath
- (NSString *) libraryPath;
/*"The first ressources controller created is the shared one.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [[NSHomeDirectory() stringByAppendingPathComponent: [self relativeLibraryPath]]
                                            stringByStandardizingPath];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= generalDirectoryPath
- (NSString *) generalDirectoryPath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [[self libraryPath] stringByAppendingPathComponent: iTMRCGeneralKey];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= applicationWillFinishLaunching:
- (void) applicationWillFinishLaunching: (NSNotification *) aNotification;
/*"Release the shared controller.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[NSNotificationCenter defaultCenter] removeObserver: self name: [aNotification name] object: nil];
    [self userResourcesDirectoryWrapper];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= userResourcesDirectoryWrapper
- (NSFileWrapper *) userResourcesDirectoryWrapper;
/*"Returns a directory wrapper at path @"~/Library/Application Support/iTeXMac". Creates the directory from scratch if it does not exist. This message is and should be the only one who eventually saves file wrappers.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: Aren't the file wrappers too expensive?
"*/
{
    NSString * path = [self libraryPath];
    if([[NSFileManager defaultManager] fileExistsAtPath: path])
    {
    	NSFileWrapper * wrapper = [[[NSFileWrapper alloc] initWithPath: path] autorelease];
        int index = 0, max = 16;
        while([wrapper isSymbolicLink] && index++<max)
        {
            NSString * destination = [wrapper symbolicLinkDestination];
            wrapper = [[[NSFileWrapper alloc] initWithPath: destination] autorelease];
        }
        if([wrapper isDirectory])
        {
            static BOOL firstTimeWriteResourceError = YES;
            if([self completeResourcesForDirectoryWrapper: wrapper])
                if(firstTimeWriteResourceError)
                {
                    NSRunCriticalAlertPanel(
                        NSLocalizedStringFromTableInBundle(@"iTeXMac Support", @"General",
                    [NSBundle bundleForClass: [self class]], "Panel resource problem title"),
                        NSLocalizedStringFromTableInBundle(@"Could not write at path:\n%@", @"General",
                    [NSBundle bundleForClass: [self class]], "Writing resource problem"),
                        nil, nil, nil, path);
                    firstTimeWriteResourceError = NO;
                }
            return wrapper;
        }
        else
        {
            static BOOL firstTimeLinkResourceError = YES;
            if(firstTimeLinkResourceError)
            {
                NSRunCriticalAlertPanel(
                    NSLocalizedStringFromTableInBundle(@"iTeXMac Support", @"General",
                        [NSBundle bundleForClass: [self class]], "Panel resource problem title"),
                    NSLocalizedStringFromTableInBundle(@"No [link to a] directory at path:\n%@", @"General",
                        [NSBundle bundleForClass: [self class]], "Missing resource problem"),
                    nil, nil, nil, path);
                firstTimeLinkResourceError = NO;
            }
        }
    }
    else
    {
    	NSFileWrapper * wrapper = [[[NSFileWrapper alloc] initDirectoryWithFileWrappers: nil] autorelease];
        NSLog(@"****  I am currently completing the file wrapper at path: %@", path);
        [self completeResourcesForDirectoryWrapper: wrapper];
        if([wrapper writeToFile: path atomically: YES updateFilenames: YES])
            return wrapper;
        else
            NSRunCriticalAlertPanel(
                NSLocalizedStringFromTableInBundle(@"iTeXMac Support", @"General",
                    [NSBundle bundleForClass: [self class]], "Panel resource problem title"),
                NSLocalizedStringFromTableInBundle(@"Could not write at path:\n%@", @"General",
                    [NSBundle bundleForClass: [self class]], "Writing resource problem"),
                nil, nil, nil, path);
    }
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= _CompleteResourcesDirectoryWrapper:
- (BOOL) completeResourcesForDirectoryWrapper: (NSFileWrapper *) aWrapper;
/*"This method ensures that the receiver contains at least the series of resources the application is designed to have. The aim is to provide a way to recover information in a consistent state after problems, external modifications... This is a one level consistency test: only subdirectories are tested. If they exist, nothing is done. If they do not exist they are created using a bundle resource. So a resources directory can exist with a bad content. This rule does not apply to the "General" directory, for which a content test is made.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: Implement what is announced
"*/
{
    if([self respondsToSelector: @selector(_CompleteResourcesForDirectoryWrapper:)])
        return [self _CompleteResourcesForDirectoryWrapper: aWrapper];
    else
        return YES;
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMResourcesController

