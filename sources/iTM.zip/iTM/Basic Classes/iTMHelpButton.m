/*
//  iTMHelpButton.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Sep 24 2001.
//  Copyright � 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/NSObject.h>
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import "NSButton(iTeXMac).h"
#import "iTMHelpButton.h"

#define dIsLargeButtonSize NO

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMHelpButton
/*"Description forthcoming."*/
@implementation iTMHelpButton
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  initWithFrame:
- (id) initWithFrame: (NSRect) irrelevant;
/*"No target set here.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(self = [super initWithFrame: NSMakeRect(0,0,32,32)])
    {
        [[self cell] setBezelStyle: NSCircularBezelStyle];
        #if 0
        if(dIsLargeButtonSize)
            [[self cell] setControlSize: NSRegularControlSize];
        else
        #endif
            [[self cell] setControlSize: NSSmallControlSize];
        [[self cell] setHighlightsBy: NSChangeGrayCellMask];//[NSContentsCellMask];
        [self setAction: @selector(showHelp:)];
        [self setTarget: self];
        [self fixImage];
        [self setBordered: YES];
    }
    return self;
}
#if 0
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  initWithCoder:
- (id) initWithCoder: (NSCoder *) aDecoder;
/*"No target set here.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(self = [super initWithCoder: aDecoder])
    {
        NSLog(NSStringFromRect([self frame]));
        NSLog(@"isTransparent: %@", ([self isTransparent]? @"Y": @"N"));
        NSLog(@"isBordered: %@", ([self isBordered]? @"Y": @"N"));
        NSLog(@"allowsMixedState: %@", ([self allowsMixedState]? @"Y": @"N"));
        NSLog(@"bezelStyle: %i", [self bezelStyle]);
        NSLog(@"imagePosition: %i", [self imagePosition]);
        NSLog(@"highlightsBy: %i", [[self cell] highlightsBy]);
        NSLog(@"showsStateBy: %i", [[self cell] showsStateBy]);
    }
    return self;
}
#endif
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  awakeFromNib
- (void) awakeFromNib;
/*"No target set here.
Version History: jlaurens@users.sourceforge.net
- 1.3: 13/12/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if([[self superclass] instancesRespondToSelector: _cmd])
        [super awakeFromNib];
    [self fixImage];
    return;
}
#if 0
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= drawRect:
- (void) drawRect: (NSRect) aRect;
/*"Draws a button (inherited method), then draws a question mark.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    float alpha = [self isEnabled]? 0.66: 0.4;
    float fontSize = dIsLargeButtonSize? 20:14;
    NSDictionary * attributes;
    NSString * QM = @"?";
    NSSize size;
    NSFont * font = [NSFont fontWithName: @"Times-Bold" size: 18];
    if(!font) font = [NSFont boldSystemFontOfSize: fontSize];
    attributes = [[NSDictionary dictionaryWithObjectsAndKeys: font, NSFontAttributeName,
                    [[NSColor blackColor] colorWithAlphaComponent: alpha], NSForegroundColorAttributeName, nil] retain];
    size = [QM sizeWithAttributes: attributes];
    [super drawRect: aRect];
    [QM drawAtPoint: NSMakePoint(NSMidX([self bounds])-size.width/2, NSMidY([self bounds])-size.height/2-2)
        withAttributes: attributes];
    [attributes release];
    return;
}
#endif
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= showHelp:
- (void) showHelp: (id) sender;
/*"When the receiver is in a palette, it should always be valid. Its target should be itself. Does nothing.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: IS IT RELEVANT?
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= description
- (NSString *) description;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return [NSString stringWithFormat: @"<%@ %@>", [super description], NSStringFromSelector([self action])];
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMHelpButton

