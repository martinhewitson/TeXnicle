/*
//  iTMListMenu.m
//  List Menu Server
//
//  Created by jlaurens@users.sourceforge.net on Wed Apr 04 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
*/

#import "iTeXMac.h"

#import <Foundation/NSFileManager.h>
#import <Foundation/NSString.h>
#import "NSMenu(iTeXMac).h"
#import "iTMListMenu.h"
#import "iTMSmallMenuItemCell.h"
#import "iTMFilePathFilter.h"
#import "iTMEventObserver.h"
#import "NSString(iTeXMac).h"
#import "iTMPathUtilities.h"

NSString * const iTMListMenuSmallSizeKey = @"iTMSmallListMenuSize";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMListMenu
/*"Description forthcoming."*/
@implementation iTMListMenu
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initialize
+ (void)initialize;
/*"It registers a default value for the user defaults keyed #{smallMenuSizeKey}. "YES" is this default."*/
{
    [super initialize];
    [[NSUserDefaults standardUserDefaults] registerDefaults:
                [NSDictionary dictionaryWithObject: @"YES" forKey: iTMListMenuSmallSizeKey]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initWithTitle:target:action:
- (id) initWithTitle: (NSString*) aTitle target: (id) aTarget action: (SEL) aSelector;
/*"#{-initWithTitle:target:controller:} with no controller."*/
{
    return [self initWithTitle: aTitle controller: nil target: aTarget action: aSelector];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initWithTitle:controller:target:action:
- (id) initWithTitle: (NSString*) aTitle controller: (id) aController target: (id) aTarget action: (SEL) aSelector;
/*"The receiver uses super #{initWithTitle:}, sets the controller and #{-_Prepare:}. If aTitle does not point to a valid directory, nil is returned. If aTitle points to a symbolic link, it is once resolved and if the target is a directory, the path is taken as source path, otherwise nil is returned once more. Only one level of indirection is managed.
This is the designated initializer."*/
{
    if([[NSFileManager defaultManager] fileExistsAtPath: aTitle])
    {
        NSFileWrapper * FW = [[[NSFileWrapper alloc] initWithPath: aTitle] autorelease];
        if([FW isSymbolicLink])
        {
            aTitle = [FW symbolicLinkDestination];
            FW = [[[NSFileWrapper alloc] initWithPath: aTitle] autorelease];
        }
        if([FW isDirectory])
        {
            self = [super initWithTitle: aTitle];
            [self setAction: aSelector];
            [self setController: aController];
            [self setTarget: aTarget];
            [self setAcceptsAlternate: NO];
            [self _Prepare];
            return self;
        }
    }
    [self autorelease];
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= dealloc
- (void) dealloc;
/*"Cleaning _Controller."*/
{
    [[NSNotificationCenter defaultCenter] removeObserver: self];
    [self setTarget: nil];
    [self setController: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= _Prepare
- (void) _Prepare;
/*"Asks the controller for #{-prepareMenu:} and send the message if appropriate. Otherwise sends a #{-prepare} message to the receiver."*/
{
    SEL selector = @selector(prepareMenu:);
    if([[self controller] respondsToSelector: selector])
        [[self controller] performSelector: selector withObject: self];
    else
        [self prepare];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= prepare
- (void) prepare;
/*"This default implementation is meant be to be overriden by controllers and subclasses that will implement a #{¬±prepareMenu:}.
Just prepare the menu view size using iTMListMenuSmallSizeKey keyed BOOL in the user default database. Send the #{-prepareMenu:} message to the controller, if it responds to."*/
{
#warning small menu font size not working...
#if 0
    [self setMenuRepresentation: [[[NSMenuView alloc] initWithFrame: NSZeroRect] autorelease]];
    if([[NSUserDefaults standardUserDefaults] boolForKey: iTMListMenuSmallSizeKey])
        [[self menuRepresentation] setFont: [NSFont menuFontOfSize: [NSFont smallSystemFontSize]]];
#endif
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= updateMenu:
- (void) updateMenu: (iTMListMenu *) aMenu;
/*"If the menu has no items, fills it using #{insertItemsAtIndex:}."*/
{
    if(([aMenu numberOfItems]<1))
        [aMenu insertItemsAtIndex: 0];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= update
- (void) update;
/*"Asks the controller to update the receiver, then calls the inherited method. More precisely, if the receiver is not a root menu (has a supermenu), performs various tests to ensure that the menu font size is the same in both menus. If it is not, it removes all the items of the receiver to make a clean update. If the receiver is a root menu, its menu font size is set according to the standard user defaults database. In both cases, an #{-updateMenu:} message is sent to the controller if it responds to, which allows to make further customizations."*/
{
    if(![[[self menuRepresentation] window] isVisible])
    {
        if([self supermenu]!=nil)
        {
            int pointSize = [[[[self supermenu] menuRepresentation] font] pointSize];
            if([[[self menuRepresentation] font] pointSize] != pointSize)
            {
                [self removeAllItems];
                if(pointSize == [NSFont systemFontSize])
                    [[self menuRepresentation] setFont: [NSFont menuFontOfSize: [NSFont systemFontSize]]];
                else
                    [[self menuRepresentation] setFont: [NSFont menuFontOfSize: [NSFont smallSystemFontSize]]];
            }
            if([[self supermenu] respondsToSelector: @selector(acceptsAlternate)])
            {
                [self setAcceptsAlternate: [(id)[self supermenu] acceptsAlternate]];
                if([[self supermenu] respondsToSelector: @selector(isAlternate)])
                {
                    BOOL isAlternateKeyDown = [(id)[self supermenu] isAlternate];
                    if(isAlternateKeyDown != [self isAlternate])
                    {
                        [self setAlternate: isAlternateKeyDown];
                        [self removeAllItems];
                    }
                }
            }
            else
                [self setAcceptsAlternate: NO];
        }
        else
        {
            BOOL hasSmallMenuSize = [[NSUserDefaults standardUserDefaults] boolForKey: iTMListMenuSmallSizeKey];
            int pointSize = hasSmallMenuSize? [NSFont smallSystemFontSize]: [NSFont systemFontSize];
            if([[[self menuRepresentation] font] pointSize] != pointSize)
            {
                [self removeAllItems];
                if(hasSmallMenuSize)
                    [[self menuRepresentation] setFont: [NSFont menuFontOfSize: [NSFont smallSystemFontSize]]];
                else
                    [[self menuRepresentation] setFont: [NSFont menuFontOfSize: [NSFont systemFontSize]]];
            }
            {
                BOOL isAlternateKeyDown = (([[NSApp currentEvent] modifierFlags] & NSAlternateKeyMask) > 0);//[iTMEventObserver isAlternateKeyDown];
                if(isAlternateKeyDown != [self isAlternate])
                {
                    [self setAlternate: isAlternateKeyDown];
                    [self removeAllItems];
                }
            }
        }
        {
            SEL selector = @selector(updateMenu:);
            if([[self controller] respondsToSelector: selector])
                [[self controller] performSelector: selector withObject: self];
            else
                [self updateMenu: self];
        }
    }
    [super update];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= description
- (NSString *) description;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if([self controller])
        return [NSString stringWithFormat: @"<%@\nController: %@>",
                            [super description], [[self controller] description]];
    else
        return [super description];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= INSERTING  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= insertItem:atIndex:
- (void) insertItem: (NSMenuItem *) aMenuItem atIndex: (int) anIndex;
/*"It inserts the item at the specified location. There is some preliminary treatment of the index to avoid range checking. Send #{insertItem:atIndex:} to super after testing the menuItem existence. Then sets the menu item cell to display the appropriate size. Uses iTMListMenuSmallSizeKey, could be avoided, needs some more thinking. The target of the menu item is set to the target already declared for the receiver (nil if no target hads been set for the receiver yet). Similarly, the action of the menu item is the one of the receiver, unless it has none: in that case the default action selector is #{listMenuItemAction:}."*/
{
    if(aMenuItem)
    {
        anIndex = MIN(MAX(anIndex, 0),[self numberOfItems]);
        [super insertItem: aMenuItem atIndex: anIndex];
        if([[[self menuRepresentation] font] pointSize] != [NSFont systemFontSize])
        {
            NSMenuView * menuView = [self menuRepresentation];
            iTMSmallMenuItemCell * mic = [[[iTMSmallMenuItemCell alloc] init] autorelease];
            [mic setFont: [menuView font]];
            [menuView setMenuItemCell: mic forItemAtIndex: anIndex];
        }
        if(![aMenuItem isEqual: [NSMenuItem separatorItem]] && ([aMenuItem action] == NULL))
        {
            if([self action] != NULL)
                [aMenuItem setAction: [self action]];
            else
                [aMenuItem setAction: @selector(listMenuItemAction:)];
            [aMenuItem setTarget: [self target]];
        }
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= insertSeparatorAtIndex:
- (int) insertSeparatorItemAtIndex: (int) itemIndex;
/*"It adds a separator item at the itemIndex location of the receiver, except if the receiver already
has such an item there.
The controller can implement the method #{¬±insertSeparatorItemInMenu:atIndex:}, it will take precedence
over the present method. But if a subclass implements #{-insertSeparatorItemInMenu:atIndex:},
it will take precedence over all others.

The return value is the number of items of the sender, once a separator item has been eventually added.
"*/
{
    if([self numberOfItems])
        if(itemIndex>=[self numberOfItems])
        {
            if(![[[self itemArray] lastObject] isSeparatorItem])
                [self addItem: [NSMenuItem separatorItem]];
        }
        else if(itemIndex > 0)
        {
            if(![[self itemAtIndex: itemIndex] isSeparatorItem] && ![[self itemAtIndex: itemIndex-1] isSeparatorItem])
                [self insertItem: [NSMenuItem separatorItem] atIndex: itemIndex];
        }
    return [self numberOfItems];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= removeAllItems
- (void) removeAllItems;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self menuRepresentation] detachSubmenu];
    while([self numberOfItems]>0)
        [self removeItemAtIndex: 0];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= insertItemsAtIndex:
- (int) insertItemsAtIndex: (int) itemIndex;
/*"Tries to insert a PList. If it fails, inserts files then folders."*/
{
    int numberOfItems = [self numberOfItems];
    if(([self insertPListItemsAtIndex: itemIndex]==numberOfItems))
    {
        int separatorIndex = [self insertRegularItemsAtIndex: itemIndex filtered: YES];
        if([self insertDirectoryItemsAtIndex: separatorIndex filtered: YES]>separatorIndex)
            [self insertSeparatorItemAtIndex: separatorIndex];
    }
    return [self numberOfItems];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= insertPListItemsAtIndex:
- (int) insertPListItemsAtIndex: (int) itemIndex;
/*"Simply lists the content of (List Menu).plist" file given by iTMFilePathFilter's method #{+listMenuArrayAtPath}. Does nothing if this file is void. If the controller responds to #{-filePathFilter} the answer is used instead of iTMFilePathFilter."*/
{
    SEL filePathFilter = @selector(filePathFilter);
    NSEnumerator * enumerator = [[self controller] respondsToSelector: filePathFilter]?
            [[[[self controller] performSelector: filePathFilter] listMenuArrayAtPath: [self title]] objectEnumerator]:
            [[iTMFilePathFilter listMenuArrayAtPath: [self title]] objectEnumerator];
    if(enumerator != nil)
    {
        int itemIndex = [self numberOfItems];
        NSString *lastPathComponent;
        BOOL canInsertSeparatorItem = ![[[self itemArray] lastObject] isEqual: [NSMenuItem separatorItem]];
        while(lastPathComponent = [enumerator nextObject])
        {
            if([lastPathComponent length])
            {
                NSString * file = [[[self title] stringByAppendingPathComponent: lastPathComponent] stringByStandardizingPath];
                NSString * fileType = [[[NSFileManager defaultManager]
                                            fileAttributesAtPath: file traverseLink: YES] fileType];
                if([fileType isEqualToString: NSFileTypeRegular] &&
                        ![file isFinderAliasTraverseLink: NO isDirectory: nil])
                {
                    NSMenuItem * menuItem = [[[NSMenuItem allocWithZone: [NSMenu menuZone]]	
                            initWithTitle: lastPathComponent
                                    action: NULL keyEquivalent: @""] autorelease];
                    [self insertItem: menuItem atIndex: itemIndex++];
                    canInsertSeparatorItem = YES;
                }
                else if([fileType isEqualToString: NSFileTypeDirectory])
                {
                    NSMenuItem * menuItem = [[[NSMenuItem allocWithZone: [NSMenu menuZone]]
                            initWithTitle: [file lastPathComponent]
                                    action: @selector(_SubmenuAction:) keyEquivalent: @""] autorelease];
                    [menuItem setTarget: self];
                    [self insertItem: menuItem atIndex: itemIndex++];
                    canInsertSeparatorItem = YES;
                }
                else
                    NSLog(@"-[iTMListMenu insertPListItemsAtIndex:] refused path: %@, fileType: %@", lastPathComponent, fileType);
            }
            else if(canInsertSeparatorItem)
            {
                [self insertItem: [NSMenuItem separatorItem] atIndex: itemIndex++];
                canInsertSeparatorItem = NO;
            }
            else
                NSLog(@"-[iTMListMenu insertPListItemsAtIndex:] illegal separator item.");
        }// while
        if(!canInsertSeparatorItem)
            [self removeItemAtIndex: --itemIndex];
    }// enumerator != nil
    return [self numberOfItems];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= insertRegularItemsAtIndex:filtered:
- (int) insertRegularItemsAtIndex: (int) itemIndex filtered: (BOOL) aFlag;
/*"Inserts all the file items at path the title of the receiver. If aFlag is YES the files are filtered by a iTMFilePathFilter instance. If the controller responds to #{-filePathFilter}, the answer is used instead of iTMFilePathFilter."*/
{
    NSString * path = [[self title] stringByStandardizingPath];
    SEL filePathFilter = @selector(filePathFilter);
    id filter = aFlag?([[self controller] respondsToSelector: filePathFilter]?
            [[[self controller] performSelector: filePathFilter] filterAtPath: path]:
            [iTMFilePathFilter filterAtPath: path]): nil;
    NSFileWrapper * FW = [[[NSFileWrapper alloc] initWithPath: path] autorelease];
    if([FW isDirectory])
    {
        NSDictionary * fileWrappers = [FW fileWrappers];
        NSEnumerator * enumerator = [fileWrappers keyEnumerator];
        while(FW = [fileWrappers objectForKey: [enumerator nextObject]])
        {
            if([FW isSymbolicLink])
                FW = [[[NSFileWrapper alloc] initWithPath: [FW symbolicLinkDestination]] autorelease];
            if([FW isRegularFile])
            {
                NSString * filename = [FW filename];
                if(!aFlag || ([filter isValidFileName: filename]))
                {
                    NSMenuItem * menuItem = [[[NSMenuItem allocWithZone: [NSMenu menuZone]]
                            initWithTitle: filename
                                    action: NULL keyEquivalent: @""] autorelease];
                    [self insertItem: menuItem atIndex: itemIndex++];
                }
            }
        }
    }
#if 0
    NSDirectoryEnumerator * enumerator =
                    [[NSFileManager defaultManager] enumeratorAtPath: [[self title] stringByStandardizingPath]];
    NSString *file;
    while (file = [enumerator nextObject])
    {
        NSString * lastPathComponent = [file lastPathComponent];
        if((!aFlag || ([filter isValidFileName: lastPathComponent] &&
                                    ![file isFinderAliasTraverseLink: NO isDirectory: nil])) &&
                        [[[enumerator fileAttributes] fileType] isEqualToString: NSFileTypeRegular])
        {
            NSMenuItem * menuItem = [[[NSMenuItem allocWithZone: [NSMenu menuZone]] initWithTitle: lastPathComponent
                            action: NULL keyEquivalent: @""] autorelease];
            [self insertItem: menuItem atIndex: itemIndex++];
        }
//        else if([[[enumerator fileAttributes] fileType] isEqualToString: NSFileTypeDirectory])
        [enumerator skipDescendents];
    }
#endif
    return itemIndex;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= insertDirectoryItemsAtIndex:filtered:
- (int) insertDirectoryItemsAtIndex: (int) itemIndex filtered: (BOOL) aFlag;
/*"See #{-insertRegularItemsAtIndex:withTarget:filtered:}. Here the target is the receiver. The items inserted in the menu only concern folders, but no submenus are set, instead their action is #{-_submenuAction}. When the menu will be sent an #{-update} message just before it is displayed on screen, it validates all its items. Then if the controller, which is the target of all menu items with a #{_SubmenuAction} action, does implement the #{-_submenuAction}, it will update the content of the submenu in its #{validateMenuItem} method, just before the menu is displayed on screen."*/
{
    NSString * path = [[self title] stringByStandardizingPath];
    SEL filePathFilter = @selector(filePathFilter);
    id filter = aFlag?([[self controller] respondsToSelector: filePathFilter]?
            [[[self controller] performSelector: filePathFilter] filterAtPath: path]:
            [iTMFilePathFilter filterAtPath: path]): nil;
    NSFileWrapper * FW = [[[NSFileWrapper alloc] initWithPath: path] autorelease];
    if([FW isDirectory])
    {
        NSDictionary * fileWrappers = [FW fileWrappers];
        NSEnumerator * enumerator = [fileWrappers keyEnumerator];
        while(FW = [fileWrappers objectForKey: [enumerator nextObject]])
        {
            if([FW isSymbolicLink])
                FW = [[[NSFileWrapper alloc] initWithPath: [FW symbolicLinkDestination]] autorelease];
            if([FW isDirectory])
            {
                NSString * filename = [FW filename];
                if(!aFlag || ([filter isValidFileName: filename]))
                {
                    NSMenuItem * menuItem = [[[NSMenuItem allocWithZone: [NSMenu menuZone]]
                            initWithTitle: filename
                                    action: @selector(_SubmenuAction:) keyEquivalent: @""] autorelease];
                    [menuItem setTarget: self];
                    [self insertItem: menuItem atIndex: itemIndex++];
                }
            }
        }
    }
#if 0
    NSDirectoryEnumerator * enumerator =
                    [[NSFileManager defaultManager] enumeratorAtPath: [[self title] stringByStandardizingPath]];
    NSString *file;
    while (file = [enumerator nextObject])
    {
        NSString * lastPathComponent = [file lastPathComponent];
        if((!aFlag || ([filter isValidFileName: lastPathComponent] &&
                                    ![file isFinderAliasTraverseLink: NO isDirectory: nil])) &&
                        [[[enumerator fileAttributes] fileType] isEqualToString: NSFileTypeDirectory])
        {
            NSMenuItem * menuItem = [[[NSMenuItem allocWithZone: [NSMenu menuZone]]
                    initWithTitle: lastPathComponent
                            action: @selector(_SubmenuAction:) keyEquivalent: @""] autorelease];
            [menuItem setTarget: self];
            [self insertItem: menuItem atIndex: itemIndex++];
        }
        #if 0
        else if ([[[enumerator fileAttributes] fileType] isEqualToString: NSFileTypeRegular] &&
                        ![file isFinderAliasTraverseLink: YES isDirectory: nil])
        #endif
        [enumerator skipDescendents];
    }
#endif
    return itemIndex;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= action
- (SEL) action;
/*"Description forthcoming."*/
{
    return _Action;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setAction:
- (void) setAction: (SEL) aSelector;
/*"Description forthcoming."*/
{
    _Action = aSelector;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= target
- (id) target;
/*"Description forthcoming."*/
{
    return _Target;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setTarget:
- (void) setTarget: (id) aTarget;
/*"Description forthcoming."*/
{
    if(![aTarget isEqual: _Target])
    {
        NSAssert2(!aTarget || [aTarget respondsToSelector: [self action]],
                                @"-[iTMListMenu setTarget:] %@ does not respond to %@",
                                    [aTarget description], NSStringFromSelector([self action]));
        [_Target autorelease];
        _Target = [aTarget retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= _SubmenuAction:
- (void) _SubmenuAction: (id) aMenuItem;
/*"Description Forthcoming.*/
{
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= validateMenuItem:
- (BOOL) validateMenuItem: (id) aMenuItem;
/*"Description forthcoming."*/
{
    if(@selector(_SubmenuAction:)==[aMenuItem action])
    {
        id menu = [aMenuItem menu];
        Class myClass = [menu isKindOfClass: [iTMListMenu class]]? [menu class]: [iTMListMenu class];
        id submenu = [[[myClass allocWithZone: [NSMenu menuZone]]
                initWithTitle: [[menu title] stringByAppendingPathComponent: [aMenuItem title]]
                        controller: [menu controller] target: [menu target] action: [menu action]] autorelease];
        [aMenuItem setSubmenu: submenu];
//        NSLog(@"How does it work ? %@; %@", [submenu description], NSStringFromSelector([aMenuItem action]));
        return YES;
    }
    else
        return NO;// Necessary ?
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= didUpdateListMenu
- (BOOL) didUpdateListMenu;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if([self acceptsAlternate])
        return _iTMLMFlags.isAlternate>0;
    else
        return NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setDidUpdateListMenu:
- (void) setDidUpdateListMenu: (BOOL) aFlag;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if([self isAlternate] != (aFlag != NO))
    {
        _iTMLMFlags.isAlternate = aFlag ? 1: 0;
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= isAlternate
- (BOOL) isAlternate;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if([self acceptsAlternate])
        return _iTMLMFlags.isAlternate>0;
    else
        return NO;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setIsAlternateListMenu:
- (void) setAlternate: (BOOL) aFlag;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if([self isAlternate] != (aFlag != NO))
    {
        _iTMLMFlags.isAlternate = aFlag ? 1: 0;
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= acceptsAlternate
- (BOOL) acceptsAlternate;
/*"Default is NO."*/
{
    return _iTMLMFlags.acceptsAlternate>0;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setAcceptsAlternate:
- (void) setAcceptsAlternate: (BOOL) aFlag;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if([self acceptsAlternate] != (aFlag != NO))
    {
        _iTMLMFlags.acceptsAlternate = aFlag ? 1: 0;
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= Controlling  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= controller
- (id) controller;
/*"Description forthcoming."*/
{
    return _Controller;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setController:
- (void) setController: (id) aController;
/*"Description Forthcoming. So I found a shortcut for Description forthcoming. Nice.
I should ask for copyright ar maybe a patent."*/
{
    if(![aController isEqual: _Controller] && ([self isValidController: aController]))
    {
        [_Controller autorelease];
        _Controller = [aController retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= isValidController:
- (BOOL) isValidController: (id) aController;
/*"Returns YES if a controller responds to all messages listed in #{-requiredStringSelectors}."*/
{
    BOOL result = YES;
    NSEnumerator * enumerator = [[self requiredStringSelectors] objectEnumerator];
    id stringSelector;
    while(stringSelector=[enumerator nextObject])
    {
        result = [aController respondsToSelector: NSSelectorFromString(stringSelector)];
        NSAssert2(result, @"Bad controller: %@ does not respond to %@.", [aController description], stringSelector);
    }
    return result;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= requiredStringSelectors
- (NSArray *) requiredStringSelectors;
/*"While overriding this method, subclasses will not forget to mention the inherited list of required string selectors. This root implementation simply declares no required method."*/
{
    return nil;
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMListMenu
