/*
//  iTMTextFinder.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Sep 03 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/NSString.h>
#import <Foundation/NSNotification.h>
#import <Foundation/NSArray.h>
#import <Foundation/NSAttributedString.h>
#import <AppKit/NSTextStorage.h>
#import <AppKit/NSPasteboard.h>
#import <AppKit/NSWindow.h>
#import <AppKit/NSApplication.h>
#import <AppKit/NSTextView.h>
#import "NSControl_iTeXMac.h"
#import "NSResponder(iTeXMac).h"
#import "iTMTextFinder.h"
#import "iTMStatusNotification.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMTextFinder
/*"It is very very very closely based on the text finder sample provided by apple‚Ñ¢. 
Fortunately, improvements have been made. However, I removed what concerns the attributes...
and added a validation process."*/
@implementation iTMTextFinder
static id _iTMTextFinder = nil;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  sharedTextFinder
+ (id) sharedTextFinder;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- 1.1: 03/10/2002
To Do List:
"*/
{
    if(!_iTMTextFinder)
    {
        _iTMTextFinder = [[self allocWithZone: [NSApp zone]] initWithWindowNibName: NSStringFromClass([self class])];
        [_iTMTextFinder enterFindPboardSelection: self];
    }
    return _iTMTextFinder;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithWindowNibName:owner:
- (id) initWithWindowNibName: (NSString *) aNibName owner: (id) object;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if(_iTMTextFinder)
    {
        if(![self isEqual: _iTMTextFinder])
            [self release];
        return [_iTMTextFinder retain];
    }
    else
    {
        if(self = [super initWithWindowNibName: aNibName owner: object])
        {
            [self setWrapFlag: YES];
            [self window];
        }
        return _iTMTextFinder = self;
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithCoder
- (id) initWithCoder: (NSCoder *) aDecoder;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List: TEST
"*/
{
    if(_iTMTextFinder)
    {
        if(![self isEqual: _iTMTextFinder])
            [self release];
        return [_iTMTextFinder retain];
    }
    else
    {
        if(self = [super initWithCoder: aDecoder])
            [self window];
        return _iTMTextFinder = self;
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithTextView:
- (id) initWithTextView: (NSTextView *) TV;
/*"The only way to create an unshared instance. With no UI.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List: TEST
"*/
{
    if(self = [super init])
    {
        [_TextView autorelease];
        _TextView = [TV retain];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"No dealloc at all.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self cleanOutlets];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  cleanOutlets
- (void) cleanOutlets;
/*"No dealloc at all.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self setFindString: nil];
    [self setReplaceString: nil];
    [_TextView autorelease];
    _TextView = nil;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  windowDidLoad
- (void) windowDidLoad;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    #warning use the defaults here
    NS_DURING
    findStringChangedSinceLastPasteboardUpdate = YES;
    [[self window] setFrameAutosaveName: [[self class] description]];
    [self validateUserInterfaceItems];
    NS_HANDLER
    [NSApp reportException: localException];
    NS_ENDHANDLER
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateUserInterfaceItems
- (void) validateUserInterfaceItems;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [findTextField validateWindowContent];
    #warning VERY BAD DESIGN
    [replaceAllScopeMatrix setEnabled: ([self textViewToSearchIn] != nil)];
    [ignoreCaseButton setEnabled: ([self textViewToSearchIn] != nil)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  applicationWillResignActive:
- (void) applicationWillResignActive: (NSNotification *) aNotification;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSString * findString = [self findString];
    if([findString length]>0)
    {
        NSPasteboard *pasteboard = [NSPasteboard pasteboardWithName: NSFindPboard];
        [pasteboard declareTypes: [NSArray arrayWithObject: NSStringPboardType] owner: nil];
        [pasteboard setString: [self findString] forType: NSStringPboardType];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  installFindResponderForWindow:
- (void) installFindResponderForWindow: (NSWindow *) aWindow;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [iTMFindResponder installResponderForWindow: aWindow];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  enterFindPboardSelection:
- (void) enterFindPboardSelection: (id) irrelevant;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSPasteboard *pasteboard = [NSPasteboard pasteboardWithName: NSFindPboard];
    if ([[pasteboard types] containsObject: NSStringPboardType])
    {
        NSString *string = [pasteboard stringForType: NSStringPboardType];
        if ([string length])
        {
            [self setFindString: string];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  findString
- (NSString *) findString;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _FindString? _FindString: [NSString string];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setFindString:
- (void) setFindString: (NSString *) aString;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if(![aString isEqualToString: _FindString])
    {
        findStringChangedSinceLastPasteboardUpdate = YES;
        [_FindString autorelease];
        _FindString = [aString copy];
        _NumberOfOps = 0;
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replaceString
- (NSString *) replaceString;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _ReplaceString? _ReplaceString: [NSString string];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setReplaceString:
- (void) setReplaceString: (NSString *) aString;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [_ReplaceString autorelease];
    _ReplaceString = [aString copy];
    _NumberOfOps = 0;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setMute:
- (void) setMute: (BOOL) flag;
/*"Description Forthcoming. Selection vs entire
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- 1.2: 07/18/2002
To Do List: Collect the flags in a struct...
"*/
{
    _Mute = flag;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  isMute
- (BOOL) isMute;
/*"Description Forthcoming. Selection vs entire
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- 1.2: 07/18/2002
To Do List: Collect the flags in a struct...
"*/
{
    return _Mute;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  entireFileFlag
- (BOOL) entireFileFlag;
/*"Description Forthcoming. Selection vs entire
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List: Collect the flags in a struct...
"*/
{
    return _EntireFileFlag;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setEntireFileFlag:
- (void) setEntireFileFlag: (BOOL) aFlag;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    _EntireFileFlag = aFlag;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  caseInsensitiveFlag
- (BOOL) caseInsensitiveFlag;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _CaseInsensitiveFlag;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setCaseInsensitiveFlag:
- (void) setCaseInsensitiveFlag: (BOOL) aFlag;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    _CaseInsensitiveFlag = aFlag;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  wrapFlag
- (BOOL) wrapFlag;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- 1.1: 03/10/2002
To Do List:
"*/
{
    return _WrapFlag;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setWrapFlag:
- (void) setWrapFlag: (BOOL) aFlag;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- 1.1: 03/10/2002
To Do List:
"*/
{
    _WrapFlag = aFlag;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  textViewToSearchIn:
- (NSTextView *) textViewToSearchIn;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if(_TextView)
        return _TextView;
    else
    {
        id textViewToSearchIn = [[NSApp mainWindow] firstResponder];
        id result = ([textViewToSearchIn isKindOfClass: [NSTextView class]]) ? textViewToSearchIn: nil;
//        NSLog(@"%@, %@", textViewToSearchIn, result);
        return result;    
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  find:
- (BOOL) find: (BOOL) direction;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSTextView * textView = [self textViewToSearchIn];
    NSString * textString = [textView string];
    NSString * findString = [self findString];
    _NumberOfOps = 0;
    if ([textString length] > 0)
    {
        if ([findString length] > 0)
        {
            NSRange range;
            unsigned options = 0;
            if (direction == Backward)
                options |= NSBackwardsSearch;
            if (_CaseInsensitiveFlag)
                options |= NSCaseInsensitiveSearch;
            range = [textString rangeOfString: findString
                            selectedRange: [textView selectedRange] options: options wrap: [self wrapFlag]];
            if (range.length)
            {
                [textView setSelectedRange: range];
                [textView scrollRangeToVisible: range];
                _NumberOfOps = 1;
            }
        }
        else
        {
            if(_Mute) NSBeep();
            [self postNotificationWithStatus:
                NSLocalizedStringFromTableInBundle(@"No textView found.", [[self class] description],
                    [NSBundle bundleForClass: [self class]], nil)];
        }
    }
    else
    {
        if(_Mute) NSBeep();
        [self postNotificationWithStatus:
            NSLocalizedStringFromTableInBundle(@"No textView to search in.", [[self class] description],
                [NSBundle bundleForClass: [self class]], nil)];
    }
    if (![self lastFindWasSuccessful])
    {
        if(_Mute) NSBeep();
        [self postNotificationWithStatus:
                NSLocalizedStringFromTableInBundle(@"Not found", [[self class] description],
                    [NSBundle bundleForClass: [self class]],
                        @"Status displayed in find panel when the find string is not found.")];
    }
    else
    {
        [self postNotificationWithStatus: @"OK"];
    }
    return [self lastFindWasSuccessful];
}
/**** Action methods for gadgets in the find panel; these should all end up setting or clearing the status field ****/
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showFindPanel:
- (void) showFindPanel: (id) irrelevant;
/*"Description Forthcoming and avalidates the user interface.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [self window];// loads the window if necessary
    [self validateUserInterfaceItems];
    [[self window] makeKeyAndOrderFront: nil];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  Actions sent by widgets:
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  findStringEdited:
- (void) findStringEdited: (id) sender;
/*"Description Forthcoming. USEFULL ???
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self findNext: sender];
    if ([self lastFindWasSuccessful])
        [[self window] orderOut: sender];
    else
	[findTextField selectText: nil];
    [self validateUserInterfaceItems];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateFindStringEdited:
- (void) validateFindStringEdited: (id) sender;
/*"Description Forthcoming. USEFULL ???
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [sender setStringValue: [self findString]];
    [sender setEnabled: ([self textViewToSearchIn] != nil)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replaceStringEdited:
- (void) replaceStringEdited: (id) sender;
/*"Description Forthcoming. USEFULL ???
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self findNext: sender];
    [self replace: sender];
    if ([self lastFindWasSuccessful])
        [[self window] orderOut: sender];
    else
	[findTextField selectText: nil];
    [self validateUserInterfaceItems];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateReplaceStringEdited:
- (void) validateReplaceStringEdited: (id) sender;
/*"Description Forthcoming. USEFULL ???
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [sender setStringValue: [self replaceString]];
    [sender setEnabled: ([self textViewToSearchIn] != nil)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  synchronizeFromUserInterface
- (void) synchronizeFromUserInterface;
/*"Description Forthcoming. Tag = position in the matrix
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if(findTextField) [self setFindString: [findTextField stringValue]];
    if(replaceTextField) [self setReplaceString: [replaceTextField stringValue]];
    [findTextField selectText: nil];
    [replaceTextField selectText: nil];
    if(ignoreCaseButton) [self setCaseInsensitiveFlag: ([ignoreCaseButton state] != NSOffState)];
    if(replaceAllScopeMatrix) [self setEntireFileFlag: ([replaceAllScopeMatrix selectedTag] == 0)];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  findNext:
- (void) findNext: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self synchronizeFromUserInterface];
    [self find: Forward];
    [self validateUserInterfaceItems];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateFindNext:
- (void) validateFindNext: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [sender setEnabled: ([self textViewToSearchIn] != nil)];
//    [sender setEnabled: ([[self findString] length] >0) && ([self textViewToSearchIn])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  findPrevious:
- (void) findPrevious: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self synchronizeFromUserInterface];
    [self find: Backward];
    [self validateUserInterfaceItems];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateFindPrevious:
- (void) validateFindPrevious: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [sender setEnabled: ([self textViewToSearchIn] != nil)];
//    [sender setEnabled: ([[self findString] length] >0) && ([self textViewToSearchIn])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replace:
- (void) replace: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self synchronizeFromUserInterface];
    [[self textViewToSearchIn] insertText: [self replaceString]];
    [self validateUserInterfaceItems];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateReplace:
- (void) validateReplace: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [sender setEnabled: [self lastFindWasSuccessful] && ([self textViewToSearchIn])];
//    [sender setEnabled: ([[self findString] length] >0) && [self lastFindWasSuccessful] && ([self textViewToSearchIn])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replaceAndFind:
- (void) replaceAndFind: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self synchronizeFromUserInterface];
    [self replace: sender];
    [self findNext: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateReplaceAndFind:
- (void) validateReplaceAndFind: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [sender setEnabled: [self lastFindWasSuccessful] && ([self textViewToSearchIn])];
//    [sender setEnabled: ([[self findString] length] >0) && [self lastFindWasSuccessful] && ([self textViewToSearchIn])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replaceAll:
- (void) replaceAll: (id) sender;
/*" The replaceAll: code is somewhat complex, and more complex than it used to be in DR1.  The main reason for this is to support undo. To play along with the undo mechanism in the textView object, this method goes through the shouldChangeTextInRange:replacementString: mechanism. In order to do that, it precomputes the section of the string that is being updated. An alternative would be for this guy to handle the undo for the replaceAll: operation itself, and register the appropriate changes. However, this is simpler...

Turns out this approach of building the new string and inserting it at the appropriate place in the actual textView storage also has an added benefit performance; it avoids copying the contents of the string around on every replace, which is significant in large files with many replacements. Of course there is the added cost of the temporary replacement string, but we try to compute that as tightly as possible beforehand to reduce the memory requirements.
Version History: Apple
- < 1.1: 03/10/2002
To Do List: rewrite this to replace all in range...
"*/
{
    NSTextView * textView = [self textViewToSearchIn];
    _NumberOfOps = 0;
    if (!textView)
    {
        if (_Mute) NSBeep();
        NSLog(@"No text view to search in found.");
        return;
    }
    [self synchronizeFromUserInterface];
    NSString *findString = [self findString];
    if([findString length])
    {
        NSTextStorage *textStorage = [textView textStorage];
        NSString *textString = [textView string];
        NSRange replaceRange = [self entireFileFlag] ? NSMakeRange(0, [textStorage length]) : [textView selectedRange];
        unsigned searchOption = ([self caseInsensitiveFlag] ? NSCaseInsensitiveSearch : 0);
        NSRange firstOccurence;
        
        // Find the first occurence of the string being replaced; if not found, we're done!
        firstOccurence = [textString rangeOfString:findString options:searchOption range:replaceRange];
        if (firstOccurence.length > 0)
        {
	    NSAutoreleasePool *pool;
	    NSString *targetString = findString;
	    NSString *replaceString = [self replaceString];
            NSMutableAttributedString *temp;	/* This is the temporary work string in which we will do the replacements... */
            NSRange rangeInOriginalString;	/* Range in the original string where we do the searches */

	    // Find the last occurence of the string and union it with the first occurence to compute the tightest range...
            rangeInOriginalString = replaceRange = NSUnionRange(firstOccurence, [textString rangeOfString:targetString options:NSBackwardsSearch|searchOption range:replaceRange]);

            temp = [[NSMutableAttributedString alloc] init];

            [temp beginEditing];

	    // The following loop can execute an unlimited number of times, and it could have autorelease activity.
	    // To keep things under control, we use a pool, but to be a bit efficient, instead of emptying everytime through
	    // the loop, we do it every so often. We can only do this as long as autoreleased items are not supposed to
	    // survive between the invocations of the pool!

    	    pool = [[NSAutoreleasePool alloc] init];

            while (rangeInOriginalString.length > 0) {
                NSRange foundRange = [textString rangeOfString:targetString options:searchOption range:rangeInOriginalString];
		// Because we computed the tightest range above, foundRange should always be valid.
		NSRange rangeToCopy = NSMakeRange(rangeInOriginalString.location, foundRange.location - rangeInOriginalString.location + 1);	// Copy upto the start of the found range plus one char (to maintain attributes with the overlap)...
                [temp appendAttributedString:[textStorage attributedSubstringFromRange:rangeToCopy]];
                [temp replaceCharactersInRange:NSMakeRange([temp length] - 1, 1) withString:replaceString];
                rangeInOriginalString.length -= NSMaxRange(foundRange) - rangeInOriginalString.location;
                rangeInOriginalString.location = NSMaxRange(foundRange);
                _NumberOfOps++;
	  	if (_NumberOfOps % 100 == 0) {	// Refresh the pool... See warning above!
		    [pool release];
		    pool = [[NSAutoreleasePool alloc] init];
		}
            }

	    [pool release];

            [temp endEditing];

	    // Now modify the original string
            if ([textView shouldChangeTextInRange:replaceRange replacementString:[temp string]]) {
                [textStorage replaceCharactersInRange:replaceRange withAttributedString:temp];
                [textView didChangeText];
//                [textView replaceCharactersInRange:replaceRange withAttributedString:temp];
            } else {	// For some reason the string didn't want to be modified. Bizarre...
                _NumberOfOps = 0;
            }

            [temp autorelease];
        }
        if ([self lastFindWasSuccessful])
        {
            [self postNotificationWithStatus:
                [NSString localizedStringWithFormat:NSLocalizedStringFromTableInBundle(@"%d replaced",
                    [[self class] description], [NSBundle bundleForClass: [self class]],
                        @"Status displayed in find panel when indicated number of matches are replaced."),
                            _NumberOfOps]];
        }
        else
        {
            if (_Mute) NSBeep();
            [self postNotificationWithStatus:
                NSLocalizedStringFromTableInBundle(@"Not found",
                    [[self class] description], [NSBundle bundleForClass: [self class]],
                        @"Status displayed in find panel when the find string is not found.")];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateReplaceAll:
- (void) validateReplaceAll: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [sender setEnabled: ([self textViewToSearchIn] != nil)];
//    [sender setEnabled: ([[self findString] length] >0) && ([self textViewToSearchIn])];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  enterSelection:
- (void) enterSelection: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSTextView * textView = [NSApp targetForAction: @selector(selectedRange)];
    NSRange selectedRange = [textView selectedRange];
    if((selectedRange.length > 0) && [textView respondsToSelector: @selector(string)])
    {
        NSString * S = [[textView string] substringWithRange: [textView selectedRange]];
        [self setFindString: S];
        [findTextField setStringValue: S];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  lastFindWasSuccessful
- (BOOL) lastFindWasSuccessful;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _NumberOfOps > 0;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  numberOfOps
- (unsigned) numberOfOps;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _NumberOfOps;
}
@end


@implementation NSString (iTMTextFinder)

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  rangeOfString:selectedRange:options:wrap:
- (NSRange) rangeOfString: (NSString *) aString selectedRange: (NSRange) aSelectedRange options: (unsigned) options wrap: (BOOL) wrap;
/*"Description Forthcoming.
Version History: Apple, jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    BOOL forwards = (options & NSBackwardsSearch) == 0;
    unsigned length = [self length];
    NSRange searchRange, range;
    if (forwards)
    {
	searchRange.location = NSMaxRange(aSelectedRange);
	searchRange.length = length - searchRange.location;
	range = [self rangeOfString: aString options: options range: searchRange];
        if ((range.length == 0) && wrap)
        {	/* If not found look at the first part of the string */
	    searchRange.location = 0;
            searchRange.length = aSelectedRange.location;
            range = [self rangeOfString: aString options: options range: searchRange];
        }
    }
    else
    {
	searchRange.location = 0;
	searchRange.length = aSelectedRange.location;
        range = [self rangeOfString: aString options: options range: searchRange];
//        NSLog(NSStringFromRange(searchRange));
//        NSLog(NSStringFromRange(range));
        if ((range.length == 0) && wrap)
        {
            searchRange.location = NSMaxRange(aSelectedRange);
            searchRange.length = length - searchRange.location;
            range = [self rangeOfString: aString options: options range: searchRange];
        }
//        NSLog(@"DOUBLE");
//        NSLog(NSStringFromRange(range));
    }
    return range;
}        
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMFindResponder
/*"Description forthcoming."*/
@implementation iTMFindResponder
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  textFinder
- (id) textFinder;
/*"Defaults implementation returns the iTMTextFinder defaults instance.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return [iTMTextFinder sharedTextFinder];//[[[[NSApp mainWindow] windowController] document] textFinder];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  findNext
- (void) findNext: (id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  findPrevious:
- (void) findPrevious: (id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replace:
- (void) replace: (id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replaceAndFind:
- (void) replaceAndFind:(id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  enterSelection:
- (void) enterSelection: (id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  enterFindPboardSelection:
- (void) enterFindPboardSelection: (id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  centerSelectionInVisibleArea:
- (void) centerSelectionInVisibleArea: (id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSTextView * textView = [[self textFinder] textViewToSearchIn];
    [textView scrollRangeToVisible: [textView selectedRange]];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  replaceAll:
- (void) replaceAll: (id) sender;
/*"Action forwarded the self's textFinder.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  showFindPanel:
- (void) showFindPanel: (id) sender;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self postNotificationWithStatus: @""];
    [[self textFinder] performSelector: _cmd withObject: sender];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  validateMenuItem:
- (BOOL) validateMenuItem: (NSMenuItem *) anItem;
/*"Example. the object is not in the responder chain.
Version history: jlaurens@users.sourceforge.net
first version Richard Koch
Version History: jlaurens@users.sourceforge.net (09/02/2001)
- < 1.1: 03/10/2002
To Do List:
"*/
{
    SEL selector = [anItem action];
    if (selector == @selector(showFindPanel:))
        return YES;
    else
    {
        id target = [[self textFinder] textViewToSearchIn];
        if(target)
        {
            return YES;
            if (selector == @selector(findNext:))
                return ([[[self textFinder] findString] length]>0) &&([[target string] length]>0);
            else if (selector == @selector(findPrevious:))
                return ([[[self textFinder] findString] length]>0) &&([[target string] length]>0);
            else if (selector == @selector(enterSelection:))
                return [target selectedRange].length > 0;
            else if (selector == @selector(enterFindPboardSelection:))
                return [[[NSPasteboard pasteboardWithName: NSFindPboard] types] containsObject: NSStringPboardType];
            else if (selector == @selector(centerSelectionInVisibleArea:))
                return [target selectedRange].length >= 0;
            else
                return NO;
        }
        else
            return NO;
    }
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMTextFinder

