/*
//  iTMExtensionManager.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Thu Jun 13 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/NSBundle.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/Foundation.h>
#import <AppKit/NSMenu.h>
#import <AppKit/AppKit.h>
#import "NSMenu(iTeXMac).h"
#import "iTMExtensionManager.h"
#import "iTMAppleScriptLauncher.h"


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMExtensionManager
/*"This is a semi abstract class."*/
@implementation iTMExtensionManager
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  init
- (id) init;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(self = [super init])
    {
        [_ExtensionDictionary autorelease];
        _ExtensionDictionary = [[NSMutableDictionary dictionary] retain];
        [self setMenu: nil];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  dealloc
- (void) dealloc;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [_ExtensionDictionary autorelease];
    _ExtensionDictionary = nil;
    [self setMenu: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  extensionDictionary
- (id) extensionDictionary;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return _ExtensionDictionary;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  registerExtension:forKey:
- (void) registerExtension: (id) object forKey: (NSString *) aKey;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(object && [aKey length])
    {
        [_ExtensionDictionary setObject: object forKey: aKey];
        NSLog(@"Assistant registered: %@", aKey);
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  relativePath
- (NSString *) relativePath;
/*"Subclasses will override this.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return @"Application Support/iTeXMac/Extensions";
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  setMenu:
- (id) menu;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(!_Menu) [self loadTheExtension: self];
    return _Menu;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  setMenu:
- (void) setMenu: (NSMenu *) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [NSMenu class]])
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSMenu argument expected: %@.",
            [self class], NSStringFromSelector(_cmd), argument];
    else if(argument != _Menu)
    {
        [_Menu autorelease];
        _Menu = [argument retain];
        [_Menu deepMakeCellSizeSmall];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  extensionMenuItemAtPath:
- (NSMenuItem *) extensionMenuItemAtPath: (NSString *) path;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    NSBundle * B = [NSBundle bundleWithPath: path];
    NSString * className = [[B infoDictionary] objectForKey: @"NSPrincipalClass"];
    if(NSClassFromString(className))
        NSLog(@"-[%@ %@] Assistant at path %@ ignored (Duplicate class name)",
            NSStringFromClass([self class]), NSStringFromSelector(_cmd), path);
    else
    {
        Class C = [B principalClass];
        id O = [[[C allocWithZone: [self zone]] init] autorelease];
        if([O respondsToSelector: @selector(menuItem)])
        {
            id MI = [O menuItem];
            if(MI)
            {
                [MI setRepresentedObject: path];
                [self registerExtension: O forKey: path];
                return MI;
            }
        }
        else
            NSLog(@"-[%@ %@] Assistant at path %@ ignored (no menu item available)",
                NSStringFromClass([self class]), NSStringFromSelector(_cmd), path);
    }
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  extensionMenuAtLibraryPath:
- (NSMenu *) extensionMenuAtLibraryPath: (NSString *) libraryPath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    NSString * assistantsPath = [[libraryPath stringByAppendingPathComponent:
        [self relativePath]] stringByStandardizingPath];
    NSMenu * M = [[NSMenu allocWithZone: [NSMenu menuZone]] initWithTitle: assistantsPath];
    NSEnumerator * E = [[[NSFileManager defaultManager] directoryContentsAtPath: assistantsPath] objectEnumerator];
    NSString * P;
    while(P = [E nextObject])
    {
        if(![P hasPrefix: @"."])
        {
            id MI = [self extensionMenuItemAtPath: [assistantsPath stringByAppendingPathComponent: P]];
            if(MI)
                [M addItem: MI];
        }
    }
    return [M autorelease];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  loadTheExtension:
- (void) loadTheExtension: (id) irrelevant;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    NSMenu * networkMenu, * localMenu, * userMenu;
    // we begin by loading the assistants defined in the network area.
    {
        NSArray * Ps = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSNetworkDomainMask, YES);
        NSString * path = [Ps count]? [Ps objectAtIndex: 0]: @"";
        networkMenu = [self extensionMenuAtLibraryPath: path];
        [networkMenu setTitle: NSLocalizedStringFromTableInBundle (@"Network", @"TeX",
                                            [NSBundle bundleForClass: [self class]], "Menu Item Title")];
        [networkMenu setTitle: NSLocalizedStringFromTableInBundle (@"Network", @"TeX",
                                            [NSBundle bundleForClass: [self class]], "Menu Item Title")];
    }
    {
        NSArray * Ps = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSLocalDomainMask, YES);
        NSString * path = [Ps count]? [Ps objectAtIndex: 0]: @"";
        localMenu = [self extensionMenuAtLibraryPath: path];
        [localMenu setTitle: NSLocalizedStringFromTableInBundle (@"Local", @"TeX",
                                            [NSBundle bundleForClass: [self class]], "Menu Item Title")];
    }
    {
        NSArray * Ps = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
        NSString * path = [Ps count]? [Ps objectAtIndex: 0]: @"";
        userMenu = [self extensionMenuAtLibraryPath: path];
        [userMenu setTitle: NSLocalizedStringFromTableInBundle (@"User", @"TeX",
                                            [NSBundle bundleForClass: [self class]], "Menu Item Title")];
    }
    if([[userMenu itemArray] count])
    {
        if([[localMenu itemArray] count])
        {
            [userMenu addItemWithTitle: [localMenu title] action: NULL keyEquivalent: [NSString string]];
            [[[userMenu itemArray] lastObject] setSubmenu: localMenu];
        }
        if([[networkMenu itemArray] count])
        {
            [userMenu addItemWithTitle: [networkMenu title] action: NULL keyEquivalent: [NSString string]];
            [[[userMenu itemArray] lastObject] setSubmenu: networkMenu];
        }
        [self setMenu: userMenu];
    }
    else if([[localMenu itemArray] count])
    {
        if([[networkMenu itemArray] count])
        {
            [localMenu addItemWithTitle: [networkMenu title] action: NULL keyEquivalent: [NSString string]];
            [[[localMenu itemArray] lastObject] setSubmenu: networkMenu];
        }
        [self setMenu: localMenu];
    }
    else if([[networkMenu itemArray] count])
    {
        [self setMenu: networkMenu];
    }
    else
    {
        NSString * title = NSLocalizedStringFromTableInBundle (@"No Plug In", @"TeX",
                [NSBundle bundleForClass: [self class]], "Menu Item Title");
        id M = [[[NSMenu alloc] initWithTitle: title] autorelease];
        [M addItemWithTitle: title action: NULL keyEquivalent: @""];
        [self setMenu: M];
    }
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAssistantManager
/*"Description forthcoming."*/
@implementation iTMAssistantManager
static iTMAssistantManager * _iTMAssistantManager;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  sharedAssistantManager
+ (id) sharedAssistantManager;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return _iTMAssistantManager? _iTMAssistantManager: (_iTMAssistantManager = [[self alloc] init]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  relativePath
- (NSString *) relativePath;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return @"Application Support/iTeXMac/Assistants";
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAssistantButton
/*"Description forthcoming."*/
@implementation iTMAssistantButton
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  awakeFromNib
- (void) awakeFromNib;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [super awakeFromNib];
    [self setMenu: [[iTMAssistantManager sharedAssistantManager] menu]];
    [self setTarget: self];
    [self setAction: NULL];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMScriptExtensionManager
/*"This is a semi abstract class."*/
@implementation iTMScriptExtensionManager
static iTMScriptExtensionManager * _iTMScriptExtensionManager;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  sharedAssistantManager
+ (id) sharedScriptExtensionManager;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return _iTMScriptExtensionManager? _iTMScriptExtensionManager: (_iTMScriptExtensionManager = [[self alloc] init]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  relativePath
- (NSString *) relativePath;
/*"Subclasses will override this.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return @"Application Support/iTeXMac/Scripts";
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  extensionMenuItemAtPath:
- (NSMenuItem *) extensionMenuItemAtPath: (NSString *) path;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if([[NSFileManager defaultManager] isReadableFileAtPath: path])
    {
        NSMenuItem * MI = [[NSMenuItem allocWithZone: [NSMenu menuZone]]
            initWithTitle: [[path lastPathComponent] stringByDeletingPathExtension]
                action: @selector(executeScriptExtension:)
                    keyEquivalent: [NSString string]];
        [MI setTarget: self];
        [MI setRepresentedObject: path];
//NSLog(@"Script registered: %@", path);
        return [MI autorelease];
    }
    else
        NSLog(@"-[%@ %@] No readable file at path %@",
            NSStringFromClass([self class]), NSStringFromSelector(_cmd), path);
    return nil;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  executeScriptExtension:
- (IBAction) executeScriptExtension: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [iTMAppleScriptLauncher
        performSelector: @selector(executeAppleScriptAtPath:)
            withObject: [sender representedObject]
                afterDelay: 0];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMScriptExtensionButton
/*"Description forthcoming."*/
@implementation iTMScriptExtensionButton
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  awakeFromNib
- (void) awakeFromNib;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [super awakeFromNib];
    [self setMenu: [[iTMScriptExtensionManager sharedScriptExtensionManager] menu]];
    [self setTarget: self];
    [self setAction: NULL];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAssistantManager

