/*
//  iTMAppleScriptLauncher.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Jun 10 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/NSPathUtilities.h>
#import <Foundation/NSFileManager.h>
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import "iTMAppleScriptLauncher.h"
#import "NDAppleScriptObject.h"
#import "iTMResourcesController.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAppleScriptLauncher
/*"Description forthcoming."*/
@implementation iTMAppleScriptLauncher
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  executeAppleScriptAtPath:
+ (IBAction) executeAppleScriptAtPath: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.1: 06/10/2002
To Do List:
"*/
{
//    NSLog(@"trying to launch a script %@", sender);
#if 1
    if([sender isKindOfClass: [NSString class]])
    {
        NSString * path = [([sender hasPrefix: @"~"] || [sender hasPrefix: @"/"]? sender: nil) stringByStandardizingPath];
        if(!path)
        {
            NSEnumerator * E =
                [NSSearchPathForDirectoriesInDomains( NSAllLibrariesDirectory, NSAllDomainsMask, YES) objectEnumerator];
            NSString * S;
            while(S = [E nextObject])
            {
                path = [[[S stringByAppendingPathComponent: @"Application Support/iTeXMac/Scripts"]
                                    stringByAppendingPathComponent: sender] stringByStandardizingPath];
                if([[NSFileManager defaultManager] isReadableFileAtPath: path])
                    break;
                path = nil;
             }
        }
        if(path)
        {
            BOOL compiled = [[[path pathExtension] lowercaseString] isEqualToString: @"scpt"];
            NDAppleScriptObject * ASO = nil;
            NSWindow * kW = [NSApp keyWindow];
            NSWindow * mW = [NSApp mainWindow];
            NSResponder * R = [kW firstResponder];
            BOOL YON = [NSApp isActive];
        NS_DURING
            if(compiled)
            {
        //                NSLog(@"OK");
                ASO = [NDAppleScriptObject appleScriptObjectWithContentsOfFile: path];
        //                NSLog(@"ASO: %@", ASO);
                // 'iTMx' is the creator code of iTeXMac
        //                [ASO setDefaultTargetAsCreator: 'iTMx'];
            }
            else
            {
                ASO = [NDAppleScriptObject appleScriptObjectWithString: [NSString stringWithContentsOfFile: path]];
            }
            NSLog(@"Executing apple script at path: %@", path);
            {
            #if 1
//                [kW resignKeyWindow];
//                [mW resignMainWindow];
                [NSApp deactivate];
            #endif
                [ASO setExecutionModeFlags: kAEAlwaysInteract];
                [ASO execute];
                {
                    id theResult = [ASO resultObject];
                    if([theResult isKindOfClass: [NDAppleScriptObject class]])
                    {
                        [theResult execute];
                    }
                }
                if(compiled)
                        [ASO writeToFile: path];
            }
        NS_HANDLER
            NSLog(@"-[%@ %@] Big problem with script at path %@",
                NSStringFromClass([self class]), NSStringFromSelector(_cmd), path);
            NSBeep();
        NS_ENDHANDLER
        #if 1
            [NSApp activateIgnoringOtherApps: YON];
            [mW makeMainWindow];
            [kW makeKeyAndOrderFront: self];
            [kW makeFirstResponder: R];
            #if 0
            {
                NSPoint P = [kW frame].origin;
                P.x += 100;
                P.y += 100;
                
                [NSApp postEvent: [NSEvent
                    mouseEventWithType: NSLeftMouseDown
                        location: NSMakePoint(200, 200)
                            modifierFlags: 0
                                timestamp: [[NSDate date] timeIntervalSinceNow]
                                    windowNumber: [kW windowNumber]
                                        context: [NSApp context]
                                            eventNumber: 0
                                                clickCount: 1
                                                    pressure: 1.0] atStart: NO];
            }
            #endif
        #endif
            return;
        }
    }
#endif
    NSLog(@"-[%@ %@] Problem with %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), sender);
    NSBeep();
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  executeAppleScript:
+ (IBAction) executeAppleScript: (id) sender;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- 1.1: 06/10/2002
To Do List:
"*/
{
#if 1
//    NSLog(@"trying to launch a script %@", sender);
    if([sender isKindOfClass: [NSString class]])
    {
        NS_DURING
        NDAppleScriptObject * ASO = [NDAppleScriptObject appleScriptObjectWithString: sender];
	[ASO execute];
        NS_HANDLER
            NSLog(@"-[%@ %@] Big problem with script %@",
                NSStringFromClass([self class]), NSStringFromSelector(_cmd), sender);
            NSBeep();
        NS_ENDHANDLER
	return;
    }
#endif
    NSLog(@"-[%@ %@] NSString expected, got %@", NSStringFromClass([self class]), NSStringFromSelector(_cmd), sender);
    NSBeep();
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAppleScriptLauncher

