/*
//  iTMStatusNotification.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Dec 03 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/NSString.h>
#import <Foundation/NSNotification.h>
#import <Foundation/NSUserDefaults.h>
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import "iTMStatusNotification.h"

NSString * const iTMStatusTimeOutKey = @"iTMStatusTimeOut";
NSString * const iTMStatusNotificationName = @"iTMStatusNotificationName";
NSString * const iTMSNStatusKey = @"status";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMStatusNotificationCenter
/*"Description forthcoming."*/
@implementation iTMStatusNotificationCenter
static id _iTMStatusNotificationCenter;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  defaultCenter
+ (void) initialize;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    NSDictionary * factoryDefaults = [NSDictionary dictionaryWithObjectsAndKeys: 
        [NSNumber numberWithFloat: 180],  iTMStatusTimeOutKey,
            nil];
    [[NSUserDefaults standardUserDefaults] registerDefaults: factoryDefaults];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  defaultCenter
+ (id) defaultCenter;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return _iTMStatusNotificationCenter? _iTMStatusNotificationCenter:
                            (_iTMStatusNotificationCenter = [[self allocWithZone: [NSApp zone]] init]);
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  init
- (id) init;
/*"The first object inited is the shared one.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(_iTMStatusNotificationCenter)
    {
        if(![self isEqual: _iTMStatusNotificationCenter])
            [self release];
        return [_iTMStatusNotificationCenter retain];
    }
    else
    {
//        NSLog(@"status notification center has been inited");
        return _iTMStatusNotificationCenter = [super init];
    }
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"Description Forhcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [self setCurrentStatus: nil];
    [self setCurrentToolTip: nil];
    [self setTimer: nil];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  timer
- (NSTimer *) timer;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return _Timer;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setTimer:
- (void) setTimer: (NSTimer *) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [NSTimer class]])
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSTimer argument expected: %@.",
            [self class], NSStringFromSelector(_cmd), argument];
    else
    {
        [_Timer invalidate];
        [_Timer autorelease];
        _Timer = [argument retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  currentStatus
- (NSString *) currentStatus;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return [_CurrentStatus length]? [[_CurrentStatus copy] autorelease]: [NSString string];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setCurrentStatus:
- (void) setCurrentStatus: (NSString *) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [NSString class]])
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSString argument expected: got %@.",
            [self class], NSStringFromSelector(_cmd), argument];
    else if(_CurrentStatus != argument)
    {
        [_CurrentStatus autorelease];
        _CurrentStatus = [argument copy];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  currentToolTip
- (NSString *) currentToolTip;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.2: 09/20/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    return [_CurrentToolTip length]? [[_CurrentToolTip copy] autorelease]: [NSString string];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setCurrentToolTip:
- (void) setCurrentToolTip: (NSString *) argument;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.2: 09/20/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(argument && ![argument isKindOfClass: [NSString class]])
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSString argument expected: got %@.",
            [self class], NSStringFromSelector(_cmd), argument];
    else if(_CurrentToolTip != argument)
    {
        [_CurrentToolTip autorelease];
        _CurrentToolTip = [argument copy];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  addObserver:
- (void) addObserver: (id) observer;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    SEL statusNotified = @selector(statusNotified:);
    NSAssert1([observer respondsToSelector: statusNotified], @"%@ must respond to statusNotified: message.", observer);
    [self addObserver: observer selector: statusNotified name: iTMStatusNotificationName object: nil];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  postNotificationWithStatus:
- (void) postNotificationWithStatus: (NSString *) aStatus;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    int length = [aStatus length];
    [self setCurrentStatus: (length? aStatus: nil)];
    if(![[self currentToolTip] length])
    {
        [self postNotificationName: iTMStatusNotificationName
            object: nil
                userInfo: [NSDictionary dictionaryWithObject: [self currentStatus] forKey: iTMSNStatusKey]];
        if(length)
            [self setTimer: [NSTimer scheduledTimerWithTimeInterval:
                                [[NSUserDefaults standardUserDefaults] floatForKey: iTMStatusTimeOutKey]
                target: self
                    selector: @selector(cleanStatusNotified:)
                        userInfo: nil
                            repeats: NO]];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  postNotificationWithToolTip:
- (void) postNotificationWithToolTip: (NSString *) aToolTip;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    int length = [aToolTip length];
    [self setCurrentToolTip: (length? aToolTip: nil)];
    [self postNotificationName: iTMStatusNotificationName
        object: nil
            userInfo: [NSDictionary dictionaryWithObject: [self currentToolTip] forKey: iTMSNStatusKey]];
    if(length)
        [self setTimer: [NSTimer scheduledTimerWithTimeInterval:
                            [[NSUserDefaults standardUserDefaults] floatForKey: iTMStatusTimeOutKey]
            target: self
                selector: @selector(cleanToolTipNotified:)
                    userInfo: nil
                        repeats: NO]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  cleanStatusNotified:
- (void) cleanStatusNotified: (NSNotification *) aNotification;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [self setTimer: nil];
    [self postNotificationWithStatus: nil];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  cleanToolTipNotified:
- (void) cleanToolTipNotified: (NSNotification *) aNotification;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [self setTimer: nil];
    [self postNotificationWithToolTip: nil];
    [self postNotificationWithStatus: [self currentStatus]];
    return;
}
@end

@implementation iTMStatusTextField
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithFrame:
- (id) initWithFrame: (NSRect) aFrame;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(self = [super initWithFrame: aFrame])
    {
        [[iTMStatusNotificationCenter defaultCenter] addObserver: self];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initWithCoder:
- (id) initWithCoder: (NSCoder *) decoder;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if(self = [super initWithCoder: decoder])
    {
        [[iTMStatusNotificationCenter defaultCenter] addObserver: self];
        [self setStringValue: [[iTMStatusNotificationCenter defaultCenter] currentStatus]];
    }
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (void) dealloc;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [[iTMStatusNotificationCenter defaultCenter] removeObserver: self];
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  statusNotified:
- (void) statusNotified: (NSNotification *) aNotification;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    NS_DURING
//    NSLog(@"statusNotified: %@", [[aNotification userInfo] objectForKey: iTMSNStatusKey]);
    [self setStringValue: [[aNotification userInfo] objectForKey: iTMSNStatusKey]];
    NS_HANDLER
    NSLog(@"-[iTMStatusTextField statusNotified:]: Bad user info.");
    NS_ENDHANDLER
    [self display];
    return;
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMStatusNotificationCenter

@implementation NSObject(iTMStatus)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  postNotificationWithStatus:
+ (void) postNotificationWithStatus: (NSString *) aStatus;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [[iTMStatusNotificationCenter defaultCenter] postNotificationWithStatus: aStatus];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  postNotificationWithStatus:
- (void) postNotificationWithStatus: (NSString *) aStatus;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [[iTMStatusNotificationCenter defaultCenter] postNotificationWithStatus: aStatus];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  postNotificationWithToolTip:
+ (void) postNotificationWithToolTip: (NSString *) aStatus;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [[iTMStatusNotificationCenter defaultCenter] postNotificationWithToolTip: aStatus];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  postNotificationWithToolTip:
- (void) postNotificationWithToolTip: (NSString *) aStatus;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [[iTMStatusNotificationCenter defaultCenter] postNotificationWithToolTip: aStatus];
    return;
}
@end
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  NSNotificationCenter(iTMStatus)

