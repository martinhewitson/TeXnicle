/*
//  iTMAutoSaveController.m
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Sun Mar 17 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/NSUserDefaults.h>
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import "iTMAutoSaveController.h"
#import "iTMStatusNotification.h"

NSString * const iTMUDAutoSaveOnKey = @"iTMUDAutoSaveOn";
NSString * const iTMUDAutoSaveIntervalKey = @"iTMUDAutoSaveInterval";

@interface iTMAutoSaveController(Private)
- (void) _UserDefaultsDidChange: (id) sender;
- (void) _TimedSaveAllDocuments: (id) sender;
- (void) setTimer: (NSTimer *) argument;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMAutoSaveController
/*"Automatic save of files."*/
@implementation iTMAutoSaveController
static id _iTMAutoSaveController = nil;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initialize
+ (void) initialize;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    [super initialize];
    [[NSUserDefaults standardUserDefaults] registerDefaults: [NSDictionary dictionaryWithObjectsAndKeys:
            [NSNumber numberWithBool: NO], iTMUDAutoSaveOnKey,
            [NSNumber numberWithFloat: 15.0], iTMUDAutoSaveIntervalKey,// in minutes
                    nil]];
    [self sharedAutoSaveController];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  sharedAutoSaveController
+ (id) sharedAutoSaveController;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    return _iTMAutoSaveController? _iTMAutoSaveController: [[self alloc] init];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  init
- (id) init;
/*"Designated initializer. The first object inited is the shared instance.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    if(_iTMAutoSaveController)
    {
        if(self != _iTMAutoSaveController)
            [self release];
        return [_iTMAutoSaveController retain];
    }
    else if(self = [super init])
    {
        [[NSNotificationCenter defaultCenter] removeObserver: self];
        [[NSNotificationCenter defaultCenter] addObserver: self
            selector: @selector(_UserDefaultsDidChange:)
                name: NSUserDefaultsDidChangeNotification
                    object: [NSUserDefaults standardUserDefaults]];
        [self _UserDefaultsDidChange: nil];
    }
    return _iTMAutoSaveController = self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  dealloc
- (id) dealloc;
/*"Designated initializer. The first object inited is the shared instance.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    [[NSNotificationCenter defaultCenter] removeObserver: self];
    [self setTimer: nil];
    [super dealloc];
    return _iTMAutoSaveController = self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _UserDefaultsDidChange:
- (void) _UserDefaultsDidChange: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    NSTimeInterval newTimeInterval = [[NSUserDefaults standardUserDefaults] floatForKey: iTMUDAutoSaveIntervalKey]; 
    if(newTimeInterval != _TimeInterval)
    {
        _TimeInterval = newTimeInterval;
        [self setTimer: ([[NSUserDefaults standardUserDefaults] boolForKey: iTMUDAutoSaveOnKey]?
            [NSTimer scheduledTimerWithTimeInterval: _TimeInterval * 60
            target: self selector: @selector(_TimedSaveAllDocuments:) userInfo: nil repeats: YES]:
            nil)];
    }
    else if([[NSUserDefaults standardUserDefaults] boolForKey: iTMUDAutoSaveOnKey])
    {
        if(!_Timer)
            [self setTimer: [NSTimer scheduledTimerWithTimeInterval: _TimeInterval
                target: self selector: @selector(_TimedSaveAllDocuments:) userInfo: nil repeats: YES]];
    }
    else if(_Timer)
    {
        [self setTimer: nil];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  _TimedSaveAllDocuments:
- (void) _TimedSaveAllDocuments: (id) sender;
/*"Description forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    NSEnumerator * E = [[[NSDocumentController sharedDocumentController] documents] objectEnumerator];
    NSDocument * D;
    [self postNotificationWithStatus: NSLocalizedStringFromTableInBundle
        (@"Auto saving the documents.", @"Basic", [NSBundle bundleForClass: [self class]], "Status")];
    while(D = [E nextObject])
        if([D canAutoSave])
            [D saveDocument: self];
    [self postNotificationWithStatus: NSLocalizedStringFromTableInBundle
        (@"Documents saved.", @"Basic", [NSBundle bundleForClass: [self class]], "Status")];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  setTimer:
- (void) setTimer: (NSTimer *) argument;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    if (argument && ![argument isKindOfClass: [NSTimer class]]) 
        [NSException raise: NSInvalidArgumentException format: @"-[%@ %@] NSTimer argument expected: %@.",
            [self class], NSStringFromSelector (_cmd) , argument];
    else if(_Timer != argument)
    {
        [_Timer invalidate];
        [_Timer autorelease];
        _Timer = [argument retain];
    }
    return;
}

@end

@implementation NSDocument(iTMAutoSaveController)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  canAutoSave
- (BOOL) canAutoSave;
/*"Subclasses will return YES if they want to be auto saved at regular intervals.
Version history: jlaurens@users.sourceforge.net
- 1.1: 05/04/2002
To Do List:
"*/
{
    return NO;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMAutoSaveController

