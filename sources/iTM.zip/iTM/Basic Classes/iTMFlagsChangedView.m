//
//  iTMFlagsChangedView.m
//  iTeXMac-iTM
//
//  Created by jeromelaurens@mac.com on Sun Feb 11 2001.
//  Copyright © 2001-2003 Laurens'Tribune. All rights reserved.
//  This piece of code is provided as is ... titati titata
//  under the GPL
//

#import <Foundation/NSGeometry.h>
#import "NSResponder(iTeXMac).h"
#import "iTMFlagsChangedView.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=  iTMFlagsChangedView  =-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
@implementation iTMFlagsChangedView
/*"This class implements the view changing with modifiers keys.
To use this class in Interface Builder, simply create a custom view, set its class
to iTMFlagsChangedView and drag some subviews in it. Then set the tags of these subviews
according to those simple rules.

- all subview with tag not in [0-15] are not affected and remain at any time at their initial positions.

- all the subviews with tags in [0-15] are treated with the next rules

- for each acceptable tag value, only the last one in the array of subviews is considered,
the previous ones remains at any time at their initial position.

- if there is no view with tag i, the subview with index 0 will replace it

In tags from [0-15], bits correspond to shift, control, alternate, command keys. More precisely,
0 means no modifier keys, 1 means only shift key, 2 means only control key, 4 means only alternate key, and 8 means only command key. This is for macintosh like endian story only.

Message to change the subviews are sent by an instance of the
iTMFlagsChangedResponder class."*/
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-= awakeFromNib
- (void) awakeFromNib
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    _SubFrames = nil;
//NSLog(@"in awakeFromNib, _SubFrames isEqual to 0x%x", _SubFrames);
    [self computeIndexFromTag];
    [iTMFlagsChangedResponder installResponderForWindow: [self window]];
    return;
} 
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-= computeIndexFromTag
- (void) computeIndexFromTag;
/*"Records the partial tags of subviews of the receiver and stores the index in the 
table %{_IndexFromTag[]}. If two views have the same partial tag, only the last one is
taken into account. The tags accepted are those between 0 and 15 (included) which corresponds to 4 modifiers key flags. One view can have at most seven different tags like this each of them corresponds to a combination of modifier keys assuming that we cannot have more than 3 modifier key at a time. Those tags are part of the NSView tag code, more
precisely we have -[NSView tag] -> tag_0+16*(tag_1+16*(...*(tag_7))), with some elementary rules.

Index for those tags are taken to be 0 by default. Last null partial tags tag_? are ignored except 0.

First we look for the first subview with tag 0, recording its index as the default index
for tags not associated with any views. If we don't find such a subview, we take 0 as default index (and the first subview will be displayed for any key combination not explicitly specified by the coder). Then we init table %{_IndexFromTag[]} with the previously found index. Next,
we loop over all the subviews of the receiver to replace the default index with a real one, if an appropriate tagged subview is found. Finally, we move away all subviews except the last one tagged 0, and the ones with tags not in [0-15].

If two view share the same partial tag, the second one overrides what was set according to the first one.
Quite nice, isn't it?
"*/
{
//NSLog(@"in computeIndexFromTag, _SubFrames isEqual to 0x%x", _SubFrames);
    int indexFromTag0 = 0;
//    iTMDEBUGLog1(5000,@"BEGINNING... %@", [self description]);
    
    {
        NSEnumerator * enumerator = [[self subviews] objectEnumerator];
        NSView * subview;
        while (subview = [enumerator nextObject])
        {
            int tag = [subview tag];
            if(!tag)
                break;
            else
            {
                BOOL keepOn = YES;
                while (tag>0 && keepOn)
                {
                    int partialTag = tag & 15;
                    tag /=16;
                    keepOn = (partialTag != 0);
                }
                if (keepOn)
                    indexFromTag0++;
                else
                    break;
            }
        }
    }

//NSLog(@"in computeIndexFromTag, _SubFrames isEqual to 0x%x", _SubFrames);

    if (indexFromTag0>=[[self subviews] count])
        indexFromTag0 = 0;
        
//    iTMDEBUGLog1(5000,@"CONTINUE, indexFromTag 0: %d", indexFromTag0);
    {
        int partialTag;
        for (partialTag=0; partialTag<16; partialTag++)
            _IndexFromTag[partialTag] = indexFromTag0;
    }

//NSLog(@"in computeIndexFromTag, _SubFrames isEqual to 0x%x", _SubFrames);

    NSMutableArray * frames = [NSMutableArray array];
    {
        NSEnumerator * enumerator = [[self subviews] objectEnumerator];
        NSView * subview;
        int subviewIndex = 0;

        while (subview = [enumerator nextObject])
        {
            [frames addObject: [NSValue valueWithRect: [subview frame]]];
            int tag = [subview tag];
//            NSLog(@"subview: %@, %d", [subview description], [subview tag]);
            while (tag>0)
            {
                int partialTag = tag % 16;
                if (partialTag)
                    _IndexFromTag[partialTag] = subviewIndex;
                tag /=16;
//                iTMDEBUGLog2(5000,@"partialTag: %d, tag: %d", partialTag, tag);
            }
            subviewIndex ++;
//            iTMDEBUGLog3(5000,@"subviewIndex: %d, %d, %@", subviewIndex, [subview tag], [subview description]);
        }
    }
//NSLog(@"The current value of _SubFrames is 0x%x", _SubFrames);
    [_SubFrames autorelease];
    _SubFrames = [frames copy];
//    iTMDEBUGLog(5000,@"MOVING...");
    {
        NSEnumerator * enumerator = [[self subviews] objectEnumerator];
        NSView * subview;
        while (subview = [enumerator nextObject])
            [subview setFrameOrigin: NSMakePoint(10000, 10000)];
        [self moveCloserSubviewAtIndex: _IndexFromTag[0]];
        _VisibleSubviewIndex = _IndexFromTag[0];
    }
//    NSLog(@"Notification observation");
    [[NSNotificationCenter defaultCenter] removeObserver: self
                name: iTMFlagsDidChangeNotification
                            object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self
            selector: @selector(flagsDidChange:)
                    name: iTMFlagsDidChangeNotification
                            object: nil];
//    NSLog(@"%d, %d, %d, %d",_IndexFromTag[0], _IndexFromTag[1], _IndexFromTag[2], _IndexFromTag[3]);
//    NSLog(@"%d, %d, %d, %d",_IndexFromTag[4], _IndexFromTag[5], _IndexFromTag[6], _IndexFromTag[7]);
//    NSLog(@"%d, %d, %d, %d",_IndexFromTag[8], _IndexFromTag[9], _IndexFromTag[10], _IndexFromTag[11]);
//    NSLog(@"%d, %d, %d, %d",_IndexFromTag[12], _IndexFromTag[13], _IndexFromTag[14], _IndexFromTag[15]);
//    iTMDEBUGLog(5000,@"END... ");
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= dealloc =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
- (void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver: self];
    [_SubFrames autorelease];
    _SubFrames = nil;
    [super dealloc];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-= acceptsFirstResponder =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
- (BOOL) acceptsFirstResponder
/*"Overriden to always return  YES to allow event messages to go through the responder chain
down to the receiver. We only need one such view in the window, the receiver can play this role."*/
{
    return YES;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-= flagsDidChange:... =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
- (void) flagsDidChange: (NSNotification *) aNotification;
/*" The subview which tag corresponds to the combination of modifier keys is moved to the origin while the subview that was previously there is moved away."*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    if([[aNotification object] isEqual: [self window]])
    {
        unsigned int flags = [[[self window] currentEvent] modifierFlags];
        int newVisibleSubviewIndex = _IndexFromTag[[self tagFromMask: flags]];
        if(_VisibleSubviewIndex != newVisibleSubviewIndex)
        {
            [self moveAwaySubviewAtIndex: _VisibleSubviewIndex];
            [self moveCloserSubviewAtIndex: newVisibleSubviewIndex];
            _VisibleSubviewIndex = newVisibleSubviewIndex;
            [self setNeedsDisplay: YES];
        }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-= tagFromMask: =-=-=-=-=-=-=-=-=-=-=-=-
- (int) tagFromMask: (int) aMask;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    int result = 0;
    result += aMask & NSCommandKeyMask ? 1: 0;
    result *=2;
    result += aMask & NSAlternateKeyMask ? 1: 0;
    result *=2;
    result += aMask & NSControlKeyMask ? 1: 0;
    result *=2;
    result += aMask & NSShiftKeyMask ? 1: 0;
//    NSLog(@"tagFromMask: %d -> %d", aMask, result);
    return result;
}
//=-=-=-=-=-=-=-=-=-=-= moveCloserSubviewAtIndex:... =-=-=-=-=-=-=-=-=-=-=-=-
- (void) moveAwaySubviewAtIndex: (int) index
/*"Sets the origin of this subview at point (10000, 10000)."*/
{
    [[[self subviews] objectAtIndex: index] setFrameOrigin: NSMakePoint(10000, 10000)];
}
//=-=-=-=-=-=-=-=-=-=-= moveCloserSubviewAtIndex:... =-=-=-=-=-=-=-=-=-=-=-=-
- (void) moveCloserSubviewAtIndex: (int) index
/*"Sets the origin of this subview at point (0, 0)."*/
{
    if(index<[_SubFrames count])
        [[[self subviews] objectAtIndex: index] setFrame: [[_SubFrames objectAtIndex: index] rectValue]];
    else
        [[[self subviews] objectAtIndex: index] setFrameOrigin: NSZeroPoint];
    return;
}
@end

#import <Foundation/NSNotification.h>
#import <AppKit/NSResponder.h>
#import <AppKit/NSWindow.h>
#import <AppKit/NSView.h>
#import <AppKit/NSEvent.h>
#import "NSResponder(iTeXMac).h"

NSString * const iTMFlagsDidChangeNotification = @"iTMFlagsDidChangeNotification";

@implementation iTMFlagsChangedResponder
/*"Description Forthcoming."*/
//=-=-=-=-=-=-=-=-=-=-=-=-=-= flagsChanged:
- (void) flagsChanged: (NSEvent *) theEvent
/*"The receiver posts a iTMFlagsChangedNotification with its window as an object."*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [[NSNotificationCenter defaultCenter]
        postNotificationName: iTMFlagsDidChangeNotification
            object: [self window]
                userInfo: nil];
    [super flagsChanged: theEvent];
}
//=-=-=-=-=-=-=-=-=-=-=-=-= window
- (NSWindow *) window;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _Window;
}
//=-=-=-=-=-=-=-=-=-=-=-=-= setWindow:
- (void) setWindow: (NSWindow *) aWindow;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if(![aWindow isEqual: _Window])
    {
        if(_Window)
        {
            // cleaning the responder chain:
            // looking for the responder just before the receiver in the responder chain
            NSResponder * responder = nil;
            NSResponder * nextResponder = [_Window contentView];
            theMarket:
            responder = nextResponder;
            nextResponder = [responder nextResponder];
            if([nextResponder isEqual: self])
                // responder is the one we were looking for
                [responder setNextResponder: [self nextResponder]];
            else if (nextResponder)
                goto theMarket;
            // we suppose that this responder has been inserted in the responder chain only once.
        }
        [_Window release];
        _Window = [aWindow retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=  insertInResponderChainAfter:
- (void) insertInResponderChainAfter: (NSView *) aResponder;
/*"Inserts the receiver in the responder chain just after aResponder, if it is not already there.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [super insertInResponderChainAfter: aResponder];
    if([aResponder isKindOfClass: [NSView class]])
        [self setWindow: [aResponder window]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-= dealloc
- (void) dealloc;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    NSNotificationCenter * defaultCenter = [NSNotificationCenter defaultCenter];
    [defaultCenter removeObserver: nil name: nil object: self];
    [self setWindow: nil];
    [super dealloc];
    return;
}
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=  iTMFlagsChangedView  =-=-=-=-=-=-=-=-=-=-=-=-=-=
