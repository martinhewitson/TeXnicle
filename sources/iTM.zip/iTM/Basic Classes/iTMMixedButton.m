/*
//  iTMMixedButton.m
//  LMS Tutorial
//
//  Created by jlaurens@users.sourceforge.net on Sun Apr 01 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history:
//  07/10/2001: first release 1.0
*/

#import <AppKit/AppKit.h>
#import "NSControl_iTeXMac.h"
#import "NSView(iTeXMac).h"
#import "iTMMixedButton.h"

NSString * const iTMUDMixedButtonDelayKey = @"iTMUDMixedButtonDelay";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMMixedButton
/*"Mixed buttons are used in two ways.
- 1: they act like internet explorer, netscape's history buttons (a short click
displayed the previous visited page, a long one displays a menu with all previously visited pages).
Such button #{isMixedEnabled}.
- 2: if the button has a menu, it displays the menu like any pop up button. The difference is that submenus are allowed...
if no menu is associate with that button, it behaves quite like any standard button. This case does not have any interest.
"*/
@implementation iTMMixedButton
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  initialize
+ (void) initialize;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [super initialize];
    [[NSUserDefaults standardUserDefaults] registerDefaults:
        [NSDictionary dictionaryWithObjectsAndKeys:
            [NSNumber numberWithFloat: 0.25], iTMUDMixedButtonDelayKey,
                nil]];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= initWithFrame:
- (id) initWithFrame: (NSRect) aRect;
/*"One button, one target. No border."*/
{
    self = [super initWithFrame: aRect];
    [self awakeFromNib];
    [self setMixedEnabled: NO];
    return self;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= awakeFromNib
- (void) awakeFromNib;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [[self cell] setHighlightsBy: NSContentsCellMask];
//    [self setBordered: NO];
    [self setCenteredArrow: NO];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= timer
- (NSTimer *) timer;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _Timer;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setTimer:
- (void) setTimer: (NSTimer *) aTimer;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    if(![aTimer isEqual: _Timer])
    {
        [_Timer invalidate];
        [_Timer autorelease];
        _Timer = [aTimer retain];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= isCenteredArrow
- (BOOL) isCenteredArrow;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _CenteredArrow;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setCenteredArrow:
- (void) setCenteredArrow: (BOOL) aFlag;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    _CenteredArrow = aFlag;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= isMixedEnabled
- (BOOL) isMixedEnabled;
/*"The receiver is enabled either in a normal fashion, id est when its target authorizes it, or in a menu driven way. If the menu has items to display, the receiver is definitely enabled.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    return _MixedEnabled;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setMixedEnabled:
- (void) setMixedEnabled: (BOOL) aFlag;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    _MixedEnabled = aFlag;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= mixedAction
- (SEL) mixedAction;
/*"#{-action} corresponds to the button's normal mode whereas #{-mixedAction} corresponds to the button's pull down mode. This message is sent when the timer has fired. It is used for example for templates buttons: the help menu stores an invocation and the %mixedAction invokes it once the menu is totally dismissed to avoid weird window positions. The %mixedAction and the %action do not participate to any validating procedure, but subclasses will certainly use them."*/
{
    return _MixedAction;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= setMixedAction:
- (void) setMixedAction: (SEL) anAction;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    _MixedAction = anAction;
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= mouseDown:
- (void) mouseDown: (NSEvent *) theEvent;
/*"If the receiver has no menu, it forwards the message to super, otherwise it creates a timer to see if the mouse is down a long time to display a submenu. If the receiver #{isMixedEnabled}, it has a mixed behaviour acting as a standard button when short clicking and as a pull down when long clicking.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List: 
"*/
{
    if([theEvent clickCount] == 1)
    {
        [self willPopUp];
        if([self isEnabled])
            if([[self menu] numberOfItems] > 0)
            {
                NSTimeInterval timeInterval = [self isMixedEnabled] ? 0.5: 0;
                [self highlight: YES];
                [[self cell] setState: NSOnState];
                [self display];
                [self setTimer: [NSTimer scheduledTimerWithTimeInterval: timeInterval
                                    target: self selector: @selector(timerHasFired:) userInfo: theEvent repeats: NO]];
            }
            else if(![self isMixedEnabled])
            {
                NSLog(@"no menu in iTMMixedButton: %@, %@", self, [self menu]);
                [super mouseDown: theEvent];
            }
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= timerHasFired:
- (void) timerHasFired: (NSTimer *) aTimer;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self popUpContextMenuWithEvent: [aTimer userInfo]];
    [self setTimer: nil];
    [self highlight: NO];
    [[self cell] setState: NSOffState];
#if 0
    // crash here, don't know why
    [[self target] performSelector: [self mixedAction] withObject: self afterDelay: 0];
#else
    [self sendAction: [self mixedAction] to: [self target]];
#endif
    [[self window] update];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= popUpContextMenuWithEvent:
- (void) popUpContextMenuWithEvent: (NSEvent *) theEvent;
/*"Use #{-popUpContextMenu:withEvent:forView:} to display the menu."*/
{
    [NSMenu popUpContextMenu: [self menu]
            withEvent: [NSEvent mouseEventWithType: [theEvent type]
                                location: NSMakePoint([theEvent locationInWindow].x-10, [theEvent locationInWindow].y)
                                modifierFlags: [theEvent modifierFlags]
                                timestamp: [theEvent timestamp]
                                windowNumber: [theEvent windowNumber]
                                context: [theEvent context]
                                eventNumber: [theEvent eventNumber]
                                clickCount: [theEvent clickCount]
                                pressure: [theEvent pressure]]
                        forView: self];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= mouseUp:
- (void) mouseUp: (NSEvent *) theEvent;
/*"Description forthcoming.
Version History: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
    [self setTimer: nil];
    if([self isMixedEnabled])
        [super mouseDown: theEvent];
    [super mouseUp: theEvent];
    [self highlight: NO];
    [[self cell] setState: NSOffState];
    [self display];
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= willPopUp
- (BOOL) willPopUp;
/*"The receiver is always enabled. The validator is the target of its action. The receiver is continuous according to the answer of the validator through the #{isValid} message. The menu of the receiver is also updated."*/
{
    NSString * SS = NSStringFromSelector([self action]);
    if([SS length])
    {
        SEL S = NSSelectorFromString([[SS substringWithRange: NSMakeRange(0, [SS length]-1)] stringByAppendingString: @"WillPopUp:"]);
        id T = [self target];
        if([T respondsToSelector: S])
            [T performSelector: S withObject: self];
    }
    [self setEnabled: ([self isValid] || ![self isMixedEnabled] || ([[self menu] numberOfItems] > 0))];
    [[self menu] update];
    return YES;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= dealloc:
- (void) dealloc;
/*"Cleans the timer."*/
{
    [self setTimer: nil];
    [super dealloc];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= drawRect
- (void) drawRect: (NSRect) aRect;
/*"Adding a small rectangle drawn when the receiver is ON to indicate that there is a menu to pull down."*/
{
    [super drawRect: aRect];
    if(([[self menu] numberOfItems] > 0) && (([self action] == NULL) || ([[self cell] state]==NSOnState)))
    {
        NSBezierPath * path = [NSBezierPath bezierPath];
        if([self isCenteredArrow])
        {
            [path moveToPoint: NSMakePoint(NSMidX(aRect), NSMidY(aRect))];
            [path relativeMoveToPoint: NSMakePoint(-4.5,-2.5)];
            [path relativeLineToPoint: NSMakePoint(+4.5,+7.5)];
            [path relativeLineToPoint: NSMakePoint(+4.5,-7.5)];
        }
        else
        {
            [path moveToPoint: NSMakePoint(25,26)];
            [path relativeLineToPoint: NSMakePoint(+3,+5.1)];
            [path relativeLineToPoint: NSMakePoint(+3,-5.1)];
        }
        [path closePath];
        [NSColor setIgnoresAlpha: NO];
        [[[NSColor blackColor] colorWithAlphaComponent: 0.66] set];
        [path fill];
    }
    return;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  performKeyEquivalent:
- (BOOL) performKeyEquivalent: (NSEvent *) theEvent;
/*"Description Forthcoming.
Version History: jlaurens@users.sourceforge.net (11/10/2001).
To do list: problem when more than one key is pressed.
"*/
{
    if([theEvent type] == NSKeyDown)
    {
        if([[self window] firstResponder] == self)
        {
            NSString * CIM = [theEvent charactersIgnoringModifiers];
            if([CIM length] && [CIM characterAtIndex: 0] == ' ')
            {
                [self mouseDown: [NSEvent mouseEventWithType: NSLeftMouseDown
                                    location: [self convertPoint: [self frameCenter] toView: nil]
                                    modifierFlags: [theEvent modifierFlags]
                                    timestamp: [theEvent timestamp]
                                    windowNumber: [theEvent windowNumber]
                                    context: [theEvent context]
                                    eventNumber: [theEvent eventNumber]
                                    clickCount: 1
                                    pressure: 1.0]];
                return YES;
            }
        }
    }
    return [super performKeyEquivalent: theEvent];
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  isValidInOtherWindow
- (BOOL) isValidInOtherWindow;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [self setEnabled: NO];
    return YES;
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  isValidInMainOrKeyWindow
- (BOOL) isValidInMainOrKeyWindow;
/*"Description Forthcoming.
Version history: jlaurens@users.sourceforge.net
- < 1.1: 03/10/2002
To Do List:
"*/
{
//NSLog(@"-[%@ %@] 0x%x", NSStringFromClass([self class]), NSStringFromSelector(_cmd), self);
    [self setEnabled: YES];
    return YES;
}
@end
