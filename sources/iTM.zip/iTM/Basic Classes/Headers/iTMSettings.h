/*
//  iTMSettings.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Tue Mar 26 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>

extern NSString * const iTMSettingsDidChangeNotification;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMSettings

@interface iTMSettings : NSObject
{
@private
    NSMutableDictionary * _DR;
    id _BaseSettings;
}
/*"Class methods"*/
/*"Setters and Getters"*/
- (NSMutableDictionary *) dictionaryRepresentation;
- (void) setDictionaryRepresentation: (NSDictionary *) argument;
- (id) baseSettings;
- (void) setBaseSettings: (id) argument;
- (id) objectForKey: (NSString *) key;
- (void) setObject: (id) value forKey: (NSString *) key;
- (void) removeObjectForKey: (NSString *) key;
- (NSString *) stringForKey: (NSString *) key;
- (NSArray *) arrayForKey: (NSString *) key;
- (NSDictionary *) dictionaryForKey: (NSString *) key;
- (NSData *) dataForKey: (NSString *) key;
- (NSArray *) stringArrayForKey: (NSString *) key;
- (int) integerForKey: (NSString *) key; 
- (float) floatForKey: (NSString *) key; 
- (BOOL) boolForKey: (NSString *) key;  
- (void) setInteger: (int) value forKey: (NSString *) key;
- (void) setFloat: (float) value forKey: (NSString *) key;
- (void) setBool: (BOOL) value forKey: (NSString *) key;
- (NSFont *) fontForKey: (NSString *) aKey;
- (void) setFont: (NSFont *) aFont forKey: (NSString *) aKey;
- (NSColor *) colorForKey: (NSString *) aKey;
- (void) setColor: (NSColor *) aColor forKey: (NSString *) aKey;
/*"Main methods"*/
- (void) notifyChangeNow;
/*"Overriden methods"*/
- (void) dealloc;
@end

@interface NSObject(iTMSettings)
- (id) settings;
- (void) settingsDidChange;
@end

@interface NSWindowController(iTMSettings)
- (id) settings;
@end

@interface NSWindow(iTMSettings)
- (id) settings;
@end

@interface NSView(iTMSettings)
- (id) settings;
@end

@interface NSTextStorage(iTMSettings)
- (id) settings;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMSettings
