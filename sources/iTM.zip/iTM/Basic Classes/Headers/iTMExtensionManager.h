/*
//  iTMExtensionManager.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Thu Jun 13 2002.
//  Copyright (c) 2001 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import "iTMMixedButton.h"


//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMExtensionManager

@interface iTMExtensionManager : NSObject
{
@private
    NSMutableDictionary * _ExtensionDictionary;
    NSMenu * _Menu;
}
/*"Class methods"*/
+ (id) sharedAssistantManager;
/*"Setters and Getters"*/
- (NSString *) relativePath;
- (id) extensionDictionary;
- (id) menu;
- (void) setMenu: (NSMenu *) argument;
- (NSMenuItem *) extensionMenuItemAtPath: (NSString *) path;
- (NSMenu *) extensionMenuAtLibraryPath: (NSString *) libraryPath;
/*"Main methods"*/
- (void) loadTheAssistant: (id) irrelevant;
- (void) registerExtension: (id) object forKey: (NSString *) aKey;
/*"Overriden methods"*/
- (id) init;
- (void) dealloc;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAssistantManager

@interface iTMAssistantManager : iTMExtensionManager
/*"Class methods"*/
+ (id) sharedAssistantManager;
/*"Setters and Getters"*/
/*"Main methods"*/
/*"Overriden methods"*/
- (NSString *) relativePath;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAssistantButton

@interface iTMAssistantButton : iTMMixedButton
/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
/*"Overriden methods"*/
- (void) awakeFromNib;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMAssistantManager

@interface iTMScriptExtensionManager : iTMExtensionManager
/*"Class methods"*/
+ (id) sharedScriptExtensionManager;
/*"Setters and Getters"*/
/*"Main methods"*/
- (IBAction) executeScriptExtension: (id) sender;
/*"Overriden methods"*/
- (NSMenuItem *) extensionMenuItemAtPath: (NSString *) path;
- (NSString *) relativePath;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMScriptExtensionButton

@interface iTMScriptExtensionButton : iTMMixedButton
/*"Class methods"*/
/*"Setters and Getters"*/
/*"Main methods"*/
/*"Overriden methods"*/
- (void) awakeFromNib;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-  iTMExtensionManager
