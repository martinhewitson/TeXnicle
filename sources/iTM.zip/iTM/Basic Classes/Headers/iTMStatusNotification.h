/*
//  iTMStatusNotification.h
//  iTeXMac
//
//  Created by jlaurens@users.sourceforge.net on Mon Dec 03 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version, modified by the addendum below.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
//
//  Version history: (format "- date:contribution(contributor)") 
//  To Do List: (format "- proposition(percentage actually done)")
*/

#import "iTeXMac.h"

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>

extern NSString * const iTMStatusNotificationName;
extern NSString * const iTMStatusKey;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMStatusNotificationCenter

@interface iTMStatusNotificationCenter : NSNotificationCenter
{
@private
    NSString * _CurrentStatus;
    NSString * _CurrentToolTip;
    NSTimer * _Timer;
}
/*"Class methods"*/
+ (id) defaultCenter;
/*"Setters and Getters"*/
- (NSString *) currentStatus;
- (void) setCurrentStatus: (NSString *) argument;
- (NSString *) currentToolTip;
- (void) setCurrentToolTip: (NSString *) argument;
- (NSTimer *) timer;
- (void) setTimer: (NSTimer *) argument;
/*"Main methods"*/
- (void) addObserver: (id) observer;
- (void) postNotificationWithStatus: (NSString *) aStatus;
- (void) cleanStatusNotified: (NSNotification *) aNotification;
- (void) cleanToolTipNotified: (NSNotification *) aNotification;
/*"Overriden methods"*/
- (id) init;
- (void) dealloc;
@end

@interface iTMStatusTextField: NSTextField
/*"Main methods"*/
- (void) statusNotified: (NSNotification *) aNotification;
/*"Overriden methods"*/
- (id) initWithFrame: (NSRect) aFrame;
- (id) initWithCoder: (NSCoder *) decoder;
- (void) dealloc;
@end

@interface NSObject(iTMStatus)
/*"Main methods"*/
+ (void) postNotificationWithStatus: (NSString *) aStatus;
+ (void) postNotificationWithToolTip: (NSString *) aStatus;
- (void) postNotificationWithStatus: (NSString *) aStatus;
- (void) postNotificationWithToolTip: (NSString *) aStatus;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMStatusNotificationCenter
