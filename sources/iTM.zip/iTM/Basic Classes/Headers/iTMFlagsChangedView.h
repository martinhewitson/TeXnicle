//
//  iTMFlagsChangedView.h
//  iTeXMac-PDF
//
//  Created by jeromelaurens@mac.com on Sun Feb 11 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//  This piece of code is provided as is ... titati titata
//  under the GPL
//

#import <AppKit/AppKit.h>

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=  iTMFlagsChangedView  =-=-=-=-=-=-=-=-=-=-=-=-=-=
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

@interface iTMFlagsChangedView : NSView
{
@private
    int _VisibleSubviewIndex;/*"Actual visible view"*/
    int _IndexFromTag[16];/*"Index subview <-> Tag correspondance."*/
    NSArray * _SubFrames;
}
/*"Private use only."*/
- (void) moveAwaySubviewAtIndex: (int) index;
- (void) moveCloserSubviewAtIndex: (int) index;
- (void) flagsDidChange: (NSNotification *) notification;
- (void) computeIndexFromTag;
- (int) tagFromMask: (int) aMask;
/*"Overriden methods"*/
- (void) awakeFromNib;
- (BOOL) acceptsFirstResponder;
- (void) dealloc;
@end

/*"iTMFlagsChangedNotification with a iTMFlagsChangedResponder instance as an object. See below."*/
extern NSString * const iTMFlagsDidChangeNotification;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=  iTMFlagsChangedResponder  =-=-=-=-=-=-=-=-=-=-=-=-=-

@interface iTMFlagsChangedResponder: NSResponder
{
    NSWindow * _Window;
}
- (NSWindow *) window;
- (void) setWindow: (NSWindow *) aWindow;
/*"Overriden method."*/
- (void) flagsChanged: (NSEvent *) theEvent;
- (void) insertInResponderChainAfter: (NSView *) aResponder;
- (void) dealloc;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=  iTMFlagsChangedView  =-=-=-=-=-=-=-=-=-=-=-=-=-=
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
