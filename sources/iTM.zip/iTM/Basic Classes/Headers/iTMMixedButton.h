/*
//  iTMMixedButton.h
//  LMS Tutorial
//
//  Created by jlaurens@users.sourceforge.net on Sun Apr 01 2001.
//  Copyright © 2001-2002 Laurens'Tribune. All rights reserved.
//
//  This program is free software; you can redistribute it and/or modify it under the terms
//  of the GNU General Public License as published by the Free Software Foundation; either
//  version 2 of the License, or any later version.
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details. You should have received a copy
//  of the GNU General Public License along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//  GPL addendum: Any simple modification of the present code which purpose is to remove bug,
//  improve efficiency in both code execution and code reading or writing should be addressed
//  to the actual developper team.
*/

#import "iTeXMac.h"

#import <Foundation/NSGeometry.h>
#import <AppKit/NSButton.h>

@class NSString, NSTimer, NSEvent;
extern NSString * const iTMUDMixedButtonDelayKey;

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMMixedButton

@interface iTMMixedButton : NSButton
{
@private
    NSTimer * _Timer;
    SEL _MixedAction;
    BOOL _CenteredArrow;
    BOOL _MixedEnabled;
}
/*"Class methods."*/
/*"Setters and getters."*/
- (NSTimer *) timer;
- (void) setTimer: (NSTimer *) aTimer;
- (BOOL) isCenteredArrow;
- (void) setCenteredArrow: (BOOL) aFlag;
- (BOOL) isMixedEnabled;
- (void) setMixedEnabled: (BOOL) aFlag;
- (SEL) mixedAction;
- (void) setMixedAction: (SEL) anAction;
/*"Main methods."*/
- (void) popUpContextMenuWithEvent: (NSEvent *) theEvent;
- (BOOL) willPopUp;
/*"Overriden methods."*/
- (void) drawRect: (NSRect) aRect;
- (void) mouseDown: (NSEvent *)theEvent;
- (void) mouseUp: (NSEvent *) theEvent;
- (void) dealloc;
- (void) awakeFromNib;
@end

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= iTMMixedButton
