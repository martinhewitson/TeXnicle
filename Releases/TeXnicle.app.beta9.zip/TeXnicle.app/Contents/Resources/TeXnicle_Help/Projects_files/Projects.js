// Created by iWeb 3.0.3 local-build-20110605

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWStrokeParts([{rect:new IWRect(-1,1,2,259),url:'Projects_files/stroke.png'},{rect:new IWRect(-1,-1,2,2),url:'Projects_files/stroke_1.png'},{rect:new IWRect(1,-1,320,2),url:'Projects_files/stroke_2.png'},{rect:new IWRect(321,-1,2,2),url:'Projects_files/stroke_3.png'},{rect:new IWRect(321,1,2,259),url:'Projects_files/stroke_4.png'},{rect:new IWRect(321,260,2,2),url:'Projects_files/stroke_5.png'},{rect:new IWRect(1,260,320,2),url:'Projects_files/stroke_6.png'},{rect:new IWRect(-1,260,2,2),url:'Projects_files/stroke_7.png'}],new IWSize(322,261)),shadow_1:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_3:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_2:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_0:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Projects_files/ProjectsMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');Widget.onload();fixAllIEPNGs('Media/transparent.gif');applyEffects()}
function onPageUnload()
{Widget.onunload();}
