// Created by iWeb 3.0.4 local-build-20111225

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({shadow_7:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_0:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_5:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_2:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_3:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_1:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_4:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),stroke_0:new IWStrokeParts([{rect:new IWRect(-1,1,2,596),url:'Project_Search_files/stroke.png'},{rect:new IWRect(-1,-1,2,2),url:'Project_Search_files/stroke_1.png'},{rect:new IWRect(1,-1,231,2),url:'Project_Search_files/stroke_2.png'},{rect:new IWRect(232,-1,2,2),url:'Project_Search_files/stroke_3.png'},{rect:new IWRect(232,1,2,596),url:'Project_Search_files/stroke_4.png'},{rect:new IWRect(232,597,2,2),url:'Project_Search_files/stroke_5.png'},{rect:new IWRect(1,597,231,2),url:'Project_Search_files/stroke_6.png'},{rect:new IWRect(-1,597,2,2),url:'Project_Search_files/stroke_7.png'}],new IWSize(233,598)),shadow_6:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Project_Search_files/Project_SearchMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');Widget.onload();fixAllIEPNGs('Media/transparent.gif');applyEffects()}
function onPageUnload()
{Widget.onunload();}
